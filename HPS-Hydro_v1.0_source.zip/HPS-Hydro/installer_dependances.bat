@echo off
chcp 65001 >nul
title HPS-Hydro - installation des dependances
cd /d "%~dp0"
echo Installation des bibliotheques Python necessaires a HPS-Hydro...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ECHEC : verifiez que Python 3.11 ou plus recent est installe et accessible ^(commande python^).
  pause
  exit /b 1
)
echo.
echo Installation terminee. Lancez HPS-Hydro avec lancer.bat
pause
