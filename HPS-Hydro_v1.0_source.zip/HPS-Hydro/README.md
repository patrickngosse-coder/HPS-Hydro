# HPS-Hydro

**Calage multi-source des courbes de tarage et validation hydrologique pour les bassins pauvres en stations.**

HPS-Hydro reprend la méthode développée pour la rivière Inkisi (RDC) : quand les stations hydrométriques ont disparu, le débit est reconstitué à partir de plusieurs sources, puis fusionné par le modèle **HPS-Hydro** (Hybride à Pondération Sigmoïdale) :

| Source | Contenu | Exemple Inkisi |
|---|---|---|
| **Q_hist** | Débits mesurés in situ, jaugeages historiques | SNEL 1950-1969, Borgerhout 1948-1951 |
| **Q_ML** | Débits reconstitués par apprentissage automatique | XGBoost 1970-2022 |
| **Q_SWOT** | Stations virtuelles SWOT, débit de Manning | 2023-2025 |
| **Q_ref** | Modèle empirique de référence | Thys : Q = 94,510 − 78,571 H + 15,624 H² |

Le logiciel joue aussi un **rôle de validation** : il contrôle la cohérence des données et des modèles, mesure la performance de chaque source de façon indépendante et produit un rapport Word à joindre à la thèse.

---

## 1. Installation (Windows)

1. Installez **Python 3.11 ou plus récent** depuis python.org (cochez « Add python.exe to PATH »).
2. Double-cliquez sur **`installer_dependances.bat`**.
3. Double-cliquez sur **`lancer.bat`** pour ouvrir le logiciel.
   Si rien ne s'affiche, ouvrez une invite de commandes dans le dossier et tapez `python -m hpshydro` pour voir le message d'erreur.

## 2. Ouvrir le projet dans Visual Studio 2026

1. Dans Visual Studio Installer, vérifiez que la charge de travail **« Développement Python »** est installée.
2. Ouvrez **`HPS-Hydro.sln`**.
3. Dans l'Explorateur de solutions, clic droit sur **Environnements Python** → choisissez votre Python 3.11+ ; puis clic droit sur `requirements.txt` → **Installer à partir de requirements.txt**.
4. Appuyez sur **F5** : `lancer_hps_hydro.py` démarre l'application.
5. Les tests apparaissent dans l'**Explorateur de tests** (pytest).

## 3. Créer l'exécutable Windows (sans Python chez l'utilisateur)

Double-cliquez sur **`creer_executable.bat`**. Le logiciel est produit dans `dist\HPS-Hydro\HPS-Hydro.exe`.
Le script lance ensuite un auto-test (`HPS-Hydro.exe --autotest`) qui ouvre le projet démo, calcule la fusion, entraîne XGBoost et génère un rapport ; le résultat est écrit dans `HPS-Hydro_autotest.txt` de votre dossier personnel.

Pour le distribuer aux doctorants, copiez tout le dossier `dist\HPS-Hydro` (ou compressez-le en .zip). Aucune connexion internet n'est nécessaire à l'utilisation.

## 4. Déroulement d'une étude

| Étape (menu de gauche) | Ce que l'on fait |
|---|---|
| **Projet et bassin** | Titre, auteur, caractéristiques du bassin, répartition par pays, stations (coordonnées décimales ou DMS), calendrier des saisons. |
| **Jaugeages et tarage** | Ajuster les courbes de tarage par station : puissance Q = a(H − H₀)^b, puissance Q = aH^b, polynôme, linéaire. Un polynôme ajusté en H peut devenir le modèle de référence. |
| **Q_hist** | Importer les débits mesurés. Outil « zéro de l'échelle » : H = Niveau − Z₀. |
| **Q_ML** | Importer les niveaux de la période sans débit, entraîner XGBoost sur Q_hist, lire les scores **hors échantillon**, remplacer Q_ML par la prédiction. |
| **Q_SWOT** | Importer hauteur, largeur, pente, surface ; recalculer le débit de Manning (n, unité de pente, profondeur, section) ; ajuster le tarage Q = aH^b. |
| **Modèle de référence** | Coefficients de Thys (modifiables), domaine de validité, analyse de la monotonie. |
| **Fusion HPS-Hydro** | Choisir α, H₀, le mode de pondération et le traitement hors domaine ; graphiques Q̄(H), hydrogramme par saison, saisonnalité LOESS, σ ; export Excel/CSV. |
| **Validation** | Contrôles de cohérence, performance par rapport à Q̄, validation « une source exclue ». |
| **Rapport** | Rapport Word complet (logo facultatif) et classeur Excel de tous les résultats. |

Le **projet de démonstration Inkisi** (bouton de la page d'accueil, ou `donnees_demo/Inkisi_demo.hpsh`) contient les tableaux de la présentation des résultats (moyennes annuelles et mensuelles). Pour reproduire les résultats de la recherche, importez les séries journalières complètes.

## 5. Format des fichiers à importer

CSV (séparateur `;` ou `,`, virgule décimale acceptée) ou Excel. La boîte d'import associe chaque colonne du fichier à une grandeur ; les noms usuels sont reconnus automatiquement. Des modèles prêts à l'emploi se trouvent dans `donnees_demo/modeles_import/`.

| Source | Date | Colonnes |
|---|---|---|
| Q_hist | Date, ou Année (+ Mois, + Jour) | Niveau, H, **Q** |
| Q_ML | idem | Niveau, H (variables explicatives), Q facultatif |
| Q_SWOT | idem (mois en lettres acceptés : janvier…décembre) | Niveau, H, Pente, Largeur, Surface, Q facultatif |
| Jaugeages | — | Station, Niveau et/ou H, **Q** |

Une moyenne annuelle est datée au 1er juillet, une valeur mensuelle au 15 du mois.

## 6. Méthode

**Fusion HPS-Hydro (mode « hauteur »)**

    Q̄(t) = σ(H(t)) · [Q_hist(t) + Q_ML(t) + Q_SWOT(t)] / n_dispo(t) + (1 − σ(H(t))) · Q_ref(t)
    σ(H) = 1 / (1 + exp(−α (H − H₀)))

En étiage σ → 0 et Q̄ → Q_ref ; en crue σ → 1 et Q̄ → moyenne des sources disponibles.

**Mode « écart »** (pondération par source) : σᵢ = 1 / (1 + exp(−α (Qᵢ − Q_ref))), puis Q̄ = moyenne de σᵢ·Qᵢ + (1 − σᵢ)·Q_ref.

**Incertitude ±1σ** : écart-type des estimations disponibles au pas de temps.

**Manning** : Q = (1/n) · A · R^(2/3) · S^(1/2), section rectangulaire (R = A/P) ou large (R ≈ y).

**Critères** : erreur moyenne, écart-type des erreurs, RMSE, r, NSE (Nash & Sutcliffe, 1970), KGE (Gupta et al., 2009), PBIAS.

## 7. Contrôles de validation

| Contrôle | Ce qu'il détecte |
|---|---|
| Superficies, pente moyenne | Incohérences entre la superficie totale et la somme par pays ; pente ≠ (Alt. max − Alt. min) / longueur |
| Coordonnées | Minutes ou secondes ≥ 60, valeurs hors bornes |
| Zéro de l'échelle | Lignes où Niveau − H s'écarte de la valeur habituelle (erreur de saisie) ; H calculé comme \|Niveau − Z₀\| |
| Niveaux SWOT | Variations peu plausibles entre observations, amplitude très supérieure aux mesures in situ |
| Loi de Manning | Le débit fourni ne dépend pas de la pente comme S^0,5 |
| Modèle de référence | Branche décroissante, débits négatifs, extrapolation hors du domaine, confrontation aux mesures |
| Apprentissage automatique | Sur-apprentissage (scores d'entraînement ≫ scores hors échantillon), extrapolation hors de la gamme d'entraînement |
| Fusion | Débits négatifs, pondération quasi constante, comparaisons non indépendantes |

La **validation « une source exclue »** compare chaque source au débit fusionné recalculé sans elle : c'est la mesure de performance indépendante à présenter au jury (la comparaison d'une source à Q̄ est circulaire, puisque Q̄ est construit à partir d'elle).

## 8. Organisation du code

```
hpshydro/
  core/            moteur de calcul, sans interface (utilisable dans un script ou un notebook)
    projet.py      données du projet, enregistrement .hpsh, projet démo Inkisi
    rating.py      courbes de tarage, modèle de référence (Thys)
    manning.py     débit de Manning, élasticités
    ml.py          XGBoost, validation croisée par blocs
    hps.py         fusion HPS-Hydro, performance, validation « une source exclue », saisonnalité
    validation.py  contrôles de cohérence
    metrics.py     NSE, KGE, RMSE, PBIAS…
    plots.py       graphiques
    report.py      rapport Word
  ui/              interface PySide6
tests/             tests du moteur (python -m pytest -q)
```

Exemple d'utilisation du moteur sans interface :

```python
from hpshydro.core.projet import Projet
from hpshydro.core import hps, validation

p = Projet.ouvrir("donnees_demo/Inkisi_demo.hpsh")
res = hps.fusionner(p)
print(hps.performance(res))
for c in validation.tout_controler(p, res):
    print(c.niveau, c.titre, c.detail)
```

## 9. Contact et retours

**Patrick Ngosse** — Université Pédagogique Nationale (UPN), Département de Physique et Sciences Appliquées
Courriel : patrick.ngosse@upn.ac.cd — Téléphone : +243 810 905 156

Vos retours sont précieux : bassin étudié, données utilisées, difficultés rencontrées, résultats obtenus, fonctions souhaitées. Dans le logiciel : menu **Aide → Envoyer un retour à l'auteur**.
