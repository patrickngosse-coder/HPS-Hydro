"""Interface graphique (PySide6)."""
