"""Pages des sources de débit : jaugeages, Q_hist, Q_ML, Q_SWOT, modèle de référence."""

from __future__ import annotations

import numpy as np
import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QHBoxLayout, QLabel, QLineEdit, QSpinBox, QTabWidget,
    QVBoxLayout, QWidget,
)

from ..core import manning, ml, plots, rating
from ..core.hps import domaine_reference
from ..core.projet import SOURCES, SOURCES_COURT
from .pages_projet import Page
from .widgets import (
    DialogueImport, Graphique, TableEditable, bouton, defilant, entete, formater, groupe, lire_nombre,
    message, vue_tableau,
)


def _spin(mini, maxi, valeur, pas=0.1, dec=3):
    s = QDoubleSpinBox()
    s.setRange(mini, maxi)
    s.setDecimals(dec)
    s.setSingleStep(pas)
    s.setValue(valeur)
    return s


def _label_info(texte=""):
    l = QLabel(texte)
    l.setWordWrap(True)
    l.setObjectName("aide")
    l.setTextFormat(Qt.RichText)
    l.setTextInteractionFlags(Qt.TextSelectableByMouse)
    return l


class _PageDeuxColonnes(Page):
    """Colonne de commandes à gauche, onglets de résultats à droite."""

    def __init__(self, fenetre, titre, sous_titre):
        super().__init__(fenetre)
        racine = QVBoxLayout(self)
        racine.addWidget(entete(titre, sous_titre))
        corps = QHBoxLayout()
        self.gauche = QWidget()
        self.gauche_lay = QVBoxLayout(self.gauche)
        self.gauche_lay.setContentsMargins(0, 0, 6, 0)
        zone = defilant(self.gauche)
        zone.setFixedWidth(440)
        zone.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        corps.addWidget(zone)
        self.onglets = QTabWidget()
        corps.addWidget(self.onglets, 1)
        racine.addLayout(corps, 1)

    def finir_gauche(self):
        self.gauche_lay.addStretch()
        from PySide6.QtWidgets import QSizePolicy
        for cb in self.gauche.findChildren(QComboBox):
            cb.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(12)
            cb.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


# ======================================================================= Jaugeages
class PageJaugeages(_PageDeuxColonnes):
    titre_nav = "Jaugeages et tarage"

    def __init__(self, fenetre):
        super().__init__(fenetre, "Jaugeages et courbes de tarage",
                         "Ajustement des courbes de tarage station par station à partir des jaugeages "
                         "historiques (couples hauteur ou niveau / débit).")
        g, f = groupe("Ajustement")
        self.station = QComboBox()
        self.variable = QComboBox()
        self.variable.addItem("Niveau (m)", "niveau")
        self.variable.addItem("Hauteur H (m)", "H")
        f.addRow("Station", self.station)
        f.addRow("Variable", self.variable)
        self.formes = {}
        for k, lib in rating.FORMES.items():
            cb = QCheckBox(lib)
            cb.setChecked(k in ("puissance", "polynome2"))
            self.formes[k] = cb
            f.addRow(cb)
        f.addRow(bouton("Ajuster les courbes", self.ajuster))
        self.gauche_lay.addWidget(g)
        g2, f2 = groupe("Résultat")
        self.vue_res, self.mod_res = vue_tableau(decimales=4)
        self.vue_res.setMinimumHeight(150)
        f2.addRow(self.vue_res)
        self.bt_ref = bouton("Utiliser le polynôme comme modèle de référence", self.vers_reference, True)
        self.bt_ref.setEnabled(False)
        f2.addRow(self.bt_ref)
        self.gauche_lay.addWidget(g2)
        g3, f3 = groupe("Données")
        f3.addRow(bouton("Importer des jaugeages…", self.importer, True))
        f3.addRow(_label_info("Colonnes attendues : Station, Niveau et/ou H, Q (Date facultative). "
                              "Le tableau de l'onglet « Jaugeages » est modifiable."))
        self.gauche_lay.addWidget(g3)
        self.finir_gauche()

        self.graph = Graphique()
        self.onglets.addTab(self.graph, "Courbes")
        self.table = TableEditable({"station": "Station", "date": "Date", "niveau": "Niveau (m)",
                                    "H": "H (m)", "Q": "Q (m³/s)", "remarque": "Remarque"},
                                   numeriques=("niveau", "H", "Q"))
        self.table.modifie.connect(self._table_modifiee)
        self.onglets.addTab(self.table, "Jaugeages")
        self.station.currentIndexChanged.connect(lambda *_: self.ajuster(silencieux=True))
        self.variable.currentIndexChanged.connect(lambda *_: self.ajuster(silencieux=True))
        self.ajustements = []

    def _table_modifiee(self):
        self._sauver_table()
        self.f.modifie(recalcul=False)

    def _sauver_table(self):
        df = self.table.valeur()
        df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=False)
        self.projet.jaugeages = df

    def rafraichir(self):
        j = self.projet.jaugeages
        self.table.definir(j)
        courant = self.station.currentText()
        self.station.blockSignals(True)
        self.station.clear()
        noms = [s for s in j["station"].dropna().unique()] if not j.empty else []
        self.station.addItems([str(s) for s in noms])
        if courant in noms:
            self.station.setCurrentText(courant)
        self.station.blockSignals(False)
        self.ajuster(silencieux=True)

    def _donnees(self):
        j = self.projet.jaugeages
        var = self.variable.currentData()
        d = j[j["station"] == self.station.currentText()][[var, "Q"]].dropna()
        return d[var].to_numpy(float), d["Q"].to_numpy(float), var

    def ajuster(self, silencieux=False):
        self.ajustements = []
        self.bt_ref.setEnabled(False)
        if self.projet.jaugeages.empty or not self.station.currentText():
            self.mod_res.definir(None)
            self.graph.dessiner(plots._vide, "Aucun jaugeage. Importez-en ou saisissez-les dans l'onglet « Jaugeages ».")
            return
        h, q, var = self._donnees()
        lignes = []
        for k, cb in self.formes.items():
            if not cb.isChecked():
                continue
            try:
                a = rating.ajuster(h, q, k)
            except Exception as exc:
                if not silencieux:
                    message(self, "Ajustement", f"{rating.FORMES[k]} : {exc}")
                continue
            self.ajustements.append(a)
            c = a.criteres
            lignes.append({"Forme": rating.FORMES[k].split(" ")[0], "Équation": a.formule(4), "n": c["n"],
                           "NSE": c["nse"], "RMSE (m³/s)": c["rmse"], "KGE": c["kge"]})
        self.mod_res.definir(pd.DataFrame(lignes))
        self.vue_res.resizeColumnsToContents()
        xl = "Niveau (m)" if var == "niveau" else "Hauteur H (m)"
        self.graph.dessiner(plots.tarage, h, q, self.ajustements,
                            f"Courbe de tarage — {self.station.currentText()} ({len(h)} jaugeages)", xl)
        self.bt_ref.setEnabled(any(a.forme == "polynome2" for a in self.ajustements) and var == "H")
        self.bt_ref.setToolTip("" if var == "H" else "Disponible quand la variable est la hauteur H "
                               "(le modèle de référence s'exprime en H).")

    def vers_reference(self):
        a = next(a for a in self.ajustements if a.forme == "polynome2")
        r = self.projet.reference
        r.nom = f"Polynôme {self.station.currentText()}"
        r.a0, r.a1, r.a2 = a.params["a0"], a.params["a1"], a.params["a2"]
        r.h_min, r.h_max = a.h_min, a.h_max
        r.description = f"Ajusté sur {a.criteres['n']} jaugeages de la station {self.station.currentText()}"
        self.f.modifie()
        message(self, "Modèle de référence", f"Le modèle de référence est maintenant :\n{r.formule()}\n"
                                             f"Domaine : {a.h_min:.2f} – {a.h_max:.2f} m.")

    def importer(self):
        d = DialogueImport(self, {"niveau": "Niveau (m)", "H": "Hauteur H (m)", "Q": "Débit Q (m³/s)"},
                           obligatoires=("Q",), avec_date=False, station=True)
        if d.exec() and d.resultat is not None:
            r = d.resultat
            if "station" not in r or r["station"].isna().all():
                r["station"] = "Station importée"
            r["date"], r["remarque"] = pd.NaT, "importé"
            self.projet.jaugeages = pd.concat([self.projet.jaugeages, r[["station", "date", "niveau", "H", "Q", "remarque"]]],
                                              ignore_index=True)
            self.f.modifie(recalcul=False)
            self.rafraichir()


# ======================================================================= Séries
class PageSerie(_PageDeuxColonnes):
    source = "hist"
    champs_import = {"niveau": "Niveau (m)", "H": "Hauteur H (m)", "Q": "Débit Q (m³/s)"}
    obligatoires = ("Q",)

    def __init__(self, fenetre, titre, sous_titre):
        super().__init__(fenetre, titre, sous_titre)
        g, f = groupe("Série")
        self.station = QLineEdit()
        self.description = QLineEdit()
        self.resume = _label_info()
        f.addRow("Station", self.station)
        f.addRow("Description", self.description)
        f.addRow(self.resume)
        ligne = QHBoxLayout()
        ligne.addWidget(bouton("Importer…", self.importer))
        ligne.addWidget(bouton("Vider", self.vider, True))
        f.addRow(ligne)
        self.gauche_lay.addWidget(g)
        self.station.textEdited.connect(self._meta)
        self.description.textEdited.connect(self._meta)

        g2, f2 = groupe("Zéro de l'échelle")
        self.z0 = _spin(-10000, 10000, 0.0, 0.01, 3)
        f2.addRow("Z₀ (m)", self.z0)
        f2.addRow(bouton("Recalculer H = Niveau − Z₀", self.recalculer_h, True))
        f2.addRow(_label_info("Utile pour rapporter les hauteurs de toutes les sources au même zéro "
                              "avant la fusion. Z₀ est initialisé à la médiane de Niveau − H."))
        self.gauche_lay.addWidget(g2)
        self.ajouter_commandes()
        self.finir_gauche()

        self.graph = Graphique()
        self.onglets.addTab(self.graph, "Graphique")
        self.vue, self.modele = vue_tableau(decimales=3)
        self.onglets.addTab(self.vue, "Tableau")
        self.ajouter_onglets()

    def ajouter_commandes(self):
        pass

    def ajouter_onglets(self):
        pass

    def _meta(self):
        s = self.projet.series[self.source]
        s.station = self.station.text()
        s.description = self.description.text()
        self.f.modifie(recalcul=False)

    def rafraichir(self):
        s = self.projet.series[self.source]
        self.station.setText(s.station)
        self.description.setText(s.description)
        self.station.setCursorPosition(0)
        self.description.setCursorPosition(0)
        df = s.donnees
        if s.vide():
            self.resume.setText("Aucune donnée. Importez un fichier CSV ou Excel.")
        else:
            q = df["Q"]
            self.resume.setText(
                f"<b>{len(df)}</b> lignes — période {s.periode()} — pas {s.pas_de_temps()}<br>"
                f"Q : min {formater(q.min(), 2)} ; moyen {formater(q.mean(), 2)} ; max {formater(q.max(), 2)} m³/s")
            off = (df["niveau"] - df["H"]).dropna()
            if len(off):
                self.z0.setValue(float(off.median()))
        self.modele.definir(df)
        self.vue.resizeColumnsToContents()
        self.graph.dessiner(plots.serie, df, self.source)

    def importer(self):
        d = DialogueImport(self, self.champs_import, obligatoires=self.obligatoires)
        if d.exec() and d.resultat is not None:
            r = d.resultat.dropna(subset=["date"])
            if "Q" in r:
                r["Q_importe"] = r["Q"]
            self.projet.definir_serie(self.source, r)
            self.f.modifie()
            self.rafraichir()
            self.f.statut(f"{len(r)} lignes importées dans {SOURCES_COURT[self.source]}.")

    def vider(self):
        self.projet.series[self.source].donnees = pd.DataFrame(columns=["date", "niveau", "H", "Q"])
        self.f.modifie()
        self.rafraichir()

    def recalculer_h(self):
        df = self.projet.serie(self.source)
        if df.empty or df["niveau"].isna().all():
            message(self, "Zéro de l'échelle", "Cette série ne contient pas de niveaux.")
            return
        df = df.copy()
        df["H"] = df["niveau"] - self.z0.value()
        self.projet.definir_serie(self.source, df)
        self.f.modifie()
        self.rafraichir()
        self.f.statut(f"H recalculé avec Z₀ = {self.z0.value():.3f} m.")


class PageHist(PageSerie):
    titre_nav = "Q_hist — mesures in situ"
    source = "hist"

    def __init__(self, fenetre):
        super().__init__(fenetre, "Q_hist — séries mesurées in situ",
                         "Débits mesurés aux stations physiques (par ex. SNEL 1950-1969). Ils servent de "
                         "référence pour entraîner le modèle d'apprentissage automatique.")


# ======================================================================= Q_ML
class PageML(PageSerie):
    titre_nav = "Q_ML — apprentissage automatique"
    source = "ml"
    obligatoires = ()

    def __init__(self, fenetre):
        super().__init__(fenetre, "Q_ML — reconstitution par apprentissage automatique",
                         "Le modèle apprend la relation niveau/hauteur → débit sur Q_hist puis prédit le débit "
                         "sur la période sans mesures. Importez ici les niveaux de cette période "
                         "(et, si vous l'avez déjà, le débit prédit).")
        self.resultat = None

    def ajouter_commandes(self):
        g, f = groupe(f"Modèle ({ml.moteur_disponible()})")
        self.vars = {}
        for k, lib in ml.VARIABLES.items():
            cb = QCheckBox(lib)
            self.vars[k] = cb
            f.addRow(cb)
        self.n_est = QSpinBox()
        self.n_est.setRange(10, 5000)
        self.prof = QSpinBox()
        self.prof.setRange(1, 12)
        self.lr = _spin(0.001, 1.0, 0.05, 0.01, 3)
        self.blocs = QSpinBox()
        self.blocs.setRange(2, 20)
        f.addRow("Nombre d'arbres", self.n_est)
        f.addRow("Profondeur maximale", self.prof)
        f.addRow("Taux d'apprentissage", self.lr)
        f.addRow("Blocs de validation croisée", self.blocs)
        f.addRow(bouton("Entraîner sur Q_hist et valider", self.entrainer))
        self.msg = _label_info()
        f.addRow(self.msg)
        self.bt_appl = bouton("Remplacer Q_ML par la prédiction", self.appliquer, True)
        self.bt_appl.setEnabled(False)
        f.addRow(self.bt_appl)
        f.addRow(bouton("Rétablir le Q_ML importé", self.retablir, True))
        self.gauche_lay.addWidget(g)

    def ajouter_onglets(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.vue_ml, self.mod_ml = vue_tableau(decimales=3, index=True)
        self.vue_ml.setMaximumHeight(130)
        l.addWidget(self.vue_ml)
        self.graph_ml = Graphique()
        l.addWidget(self.graph_ml, 1)
        self.onglets.addTab(w, "Validation du modèle")

    def rafraichir(self):
        super().rafraichir()
        p = self.projet.ml
        for k, cb in self.vars.items():
            cb.setChecked(k in p.variables)
        self.n_est.setValue(p.n_estimators)
        self.prof.setValue(p.max_depth)
        self.lr.setValue(p.learning_rate)
        self.blocs.setValue(p.n_blocs)

    def _params(self):
        p = self.projet.ml
        p.variables = [k for k, cb in self.vars.items() if cb.isChecked()]
        p.n_estimators, p.max_depth = self.n_est.value(), self.prof.value()
        p.learning_rate, p.n_blocs = self.lr.value(), self.blocs.value()
        return p

    def entrainer(self):
        p = self._params()
        if not p.variables:
            message(self, "Apprentissage", "Cochez au moins une variable explicative.")
            return
        if self.projet.series["hist"].vide():
            message(self, "Apprentissage", "Importez d'abord les débits mesurés (Q_hist).")
            return
        with self.f.attente("Entraînement et validation du modèle…"):
            try:
                self.resultat = ml.entrainer(self.projet.serie("hist"), p)
            except Exception as exc:
                message(self, "Apprentissage", str(exc), erreur=True)
                return
        self.f.resultat_ml = self.resultat
        r = self.resultat
        couleur = "#b03a2e" if r.sur_apprentissage else "#2e7d32"
        self.msg.setText(
            f"<b>Validation croisée</b> : NSE {formater(r.validation_croisee['nse'], 3)}, "
            f"RMSE {formater(r.validation_croisee['rmse'], 2)} m³/s<br>"
            f"<b>Dernière période</b> : NSE {formater(r.validation_temporelle['nse'], 3)}<br>"
            f"<span style='color:{couleur}'>{r.message}</span>")
        self.mod_ml.definir(r.resume())
        self.vue_ml.resizeColumnsToContents()
        self.graph_ml.dessiner(plots.ml_validation, r)
        self.onglets.setCurrentIndex(2)
        self.bt_appl.setEnabled(not self.projet.series["ml"].vide())
        self.f.modifie(recalcul=False)

    def appliquer(self):
        df = self.projet.serie("ml").copy()
        q, hors = ml.predire(self.resultat, df, self.projet.serie("hist"))
        if "Q_importe" not in df.columns:
            df["Q_importe"] = df["Q"]
        df["Q"] = q
        self.projet.definir_serie("ml", df)
        self.f.modifie()
        self.rafraichir()
        txt = f"Q_ML remplacé par la prédiction ({q.notna().sum()} valeurs)."
        if hors:
            txt += (f"\n\n{hors} ligne(s) ont des niveaux hors de la gamme d'entraînement : les arbres de "
                    f"décision n'extrapolent pas, la prédiction y est plafonnée.")
        message(self, "Prédiction", txt)

    def retablir(self):
        df = self.projet.serie("ml").copy()
        if "Q_importe" not in df.columns:
            return
        df["Q"] = df["Q_importe"]
        self.projet.definir_serie("ml", df)
        self.f.modifie()
        self.rafraichir()


# ======================================================================= Q_SWOT
class PageSWOT(PageSerie):
    titre_nav = "Q_SWOT — Manning"
    source = "swot"
    champs_import = {"niveau": "Niveau / élévation de surface (m)", "H": "Hauteur H (m)",
                     "pente": "Pente", "largeur": "Largeur (m)", "surface": "Surface du tronçon (m²)",
                     "Q": "Débit Q (m³/s) — facultatif"}
    obligatoires = ()

    def __init__(self, fenetre):
        super().__init__(fenetre, "Q_SWOT — stations virtuelles et équation de Manning",
                         "Hauteur, largeur et pente mesurées par le satellite SWOT ; le débit est estimé par "
                         "Q = (1/n)·A·R^(2/3)·S^(1/2).")

    def ajouter_commandes(self):
        g, f = groupe("Équation de Manning")
        self.n = _spin(0.005, 0.3, 0.035, 0.001, 4)
        self.unite = QComboBox()
        for k in manning.UNITES_PENTE:
            self.unite.addItem(k, k)
        self.mode = QComboBox()
        for k, lib in manning.MODES_PROFONDEUR.items():
            self.mode.addItem(lib, k)
        self.zf = _spin(-1000, 10000, 0.0, 0.1, 3)
        self.long = _spin(1, 1e6, 10000, 100, 0)
        self.section = QComboBox()
        self.section.addItem("Rectangulaire (R = A/P)", "rectangulaire")
        self.section.addItem("Large (R ≈ profondeur)", "large")
        self.utiliser = QComboBox()
        self.utiliser.addItem("Débit importé", "fourni")
        self.utiliser.addItem("Débit recalculé par Manning", "calcule")
        f.addRow("n de Manning", self.n)
        f.addRow("Unité de la pente", self.unite)
        f.addRow("Profondeur", self.mode)
        f.addRow("Cote du fond (m)", self.zf)
        f.addRow("Longueur du tronçon (m)", self.long)
        f.addRow("Section", self.section)
        f.addRow("Débit utilisé pour la fusion", self.utiliser)
        f.addRow(bouton("Calculer", self.calculer))
        self.msg = _label_info()
        f.addRow(self.msg)
        self.gauche_lay.addWidget(g)
        g2, f2 = groupe("Tarage SWOT")
        f2.addRow(bouton("Ajuster Q = a·H^b", self.tarage, True))
        self.msg_t = _label_info()
        f2.addRow(self.msg_t)
        self.gauche_lay.addWidget(g2)

    def ajouter_onglets(self):
        self.graph_t = Graphique()
        self.onglets.addTab(self.graph_t, "Tarage SWOT")

    def rafraichir(self):
        super().rafraichir()
        m = self.projet.manning
        self.n.setValue(m.n)
        self.unite.setCurrentIndex(self.unite.findData(m.unite_pente))
        self.mode.setCurrentIndex(self.mode.findData(m.mode_profondeur))
        self.zf.setValue(m.z_fond)
        self.long.setValue(m.longueur_troncon)
        self.section.setCurrentIndex(self.section.findData(m.section))
        self.utiliser.setCurrentIndex(self.utiliser.findData(m.utiliser))

    def calculer(self):
        m = self.projet.manning
        m.n, m.unite_pente = self.n.value(), self.unite.currentData()
        m.mode_profondeur, m.z_fond = self.mode.currentData(), self.zf.value()
        m.longueur_troncon, m.section = self.long.value(), self.section.currentData()
        m.utiliser = self.utiliser.currentData()
        df = self.projet.serie("swot").copy()
        if df.empty:
            message(self, "Manning", "Importez d'abord les données SWOT.")
            return
        try:
            qm = manning.debit(df, m)
        except Exception as exc:
            message(self, "Manning", str(exc), erreur=True)
            return
        df["Q_manning"] = qm
        if "Q_importe" not in df.columns:
            df["Q_importe"] = df["Q"]
        df["Q"] = qm if m.utiliser == "calcule" else df["Q_importe"]
        self.projet.definir_serie("swot", df)
        self.f.modifie()
        self.rafraichir()
        from ..core import metrics
        txt = f"Q de Manning calculé pour {int(qm.notna().sum())} ligne(s) (moyenne {formater(qm.mean(), 1)} m³/s)."
        if df["Q_importe"].notna().sum() >= 3:
            c = metrics.tous(qm, df["Q_importe"])
            txt += (f"<br>Par rapport au débit importé : biais {formater(c['biais'], 1)} m³/s, "
                    f"r = {formater(c['r'], 3)}.")
        txt += f"<br>Débit retenu : <b>{self.utiliser.currentText().lower()}</b>."
        self.msg.setText(txt)

    def tarage(self):
        df = self.projet.serie("swot").dropna(subset=["H", "Q"])
        try:
            a = rating.ajuster(df["H"], df["Q"], "puissance0")
        except Exception as exc:
            message(self, "Tarage SWOT", str(exc), erreur=True)
            return
        self.msg_t.setText(f"<b>{a.formule(3)}</b><br>NSE = {formater(a.criteres['nse'], 3)} ; "
                           f"RMSE = {formater(a.criteres['rmse'], 1)} m³/s ; n = {a.criteres['n']}")
        self.graph_t.dessiner(plots.tarage, df["H"], df["Q"], [a], "Tarage H–Q des données SWOT",
                              etiquette="Observations SWOT")
        self.onglets.setCurrentWidget(self.graph_t)


# ======================================================================= Référence
class PageReference(_PageDeuxColonnes):
    titre_nav = "Modèle de référence"

    def __init__(self, fenetre):
        super().__init__(fenetre, "Modèle de référence (Q_ref)",
                         "Relation empirique Q = a₀ + a₁·H + a₂·H², par défaut le modèle de R. Thys "
                         "(19 jaugeages, 1910-1911). Elle domine la fusion en étiage.")
        g, f = groupe("Coefficients")
        self.nom = QLineEdit()
        self.a0, self.a1, self.a2 = QLineEdit(), QLineEdit(), QLineEdit()
        self.hmin, self.hmax = QLineEdit(), QLineEdit()
        self.desc = QLineEdit()
        f.addRow("Nom", self.nom)
        f.addRow("a₀", self.a0)
        f.addRow("a₁", self.a1)
        f.addRow("a₂", self.a2)
        f.addRow("H min de validité (m)", self.hmin)
        f.addRow("H max de validité (m)", self.hmax)
        f.addRow("Origine", self.desc)
        f.addRow(_label_info("Laissez H min / H max vides si le domaine des jaugeages d'origine est "
                             "inconnu : le logiciel utilisera alors l'étendue des hauteurs in situ."))
        f.addRow(bouton("Appliquer", self.appliquer))
        f.addRow(bouton("Rétablir le modèle de Thys", self.thys, True))
        self.gauche_lay.addWidget(g)
        g2, f2 = groupe("Analyse")
        self.analyse = _label_info()
        f2.addRow(self.analyse)
        self.gauche_lay.addWidget(g2)
        self.finir_gauche()
        self.graph = Graphique()
        self.onglets.addTab(self.graph, "Courbe")

    def rafraichir(self):
        r = self.projet.reference
        self.nom.setText(r.nom)
        for w, v in ((self.a0, r.a0), (self.a1, r.a1), (self.a2, r.a2), (self.hmin, r.h_min), (self.hmax, r.h_max)):
            w.setText("" if v is None else np.format_float_positional(float(v), trim="-").replace(".", ","))
        self.desc.setText(r.description)
        a = r.analyse()
        lignes = [f"<b>{r.formule()}</b>"]
        if r.a2 > 0 and a["h_sommet"] is not None and a["h_sommet"] > 0:
            lignes.append(f"<span style='color:#b03a2e'>Branche décroissante pour H &lt; "
                          f"{formater(a['h_sommet'], 2)} m (Q min = {formater(a['q_sommet'], 2)} m³/s).</span>")
            if a["racines"] and a["q_sommet"] < 0:
                lignes.append(f"<span style='color:#b03a2e'>Débit négatif entre {formater(a['racines'][0], 2)} "
                              f"et {formater(a['racines'][1], 2)} m.</span>")
        else:
            lignes.append("Courbe croissante pour H &gt; 0.")
        dom, orig = domaine_reference(self.projet)
        lignes.append(f"Domaine utilisé : {formater(dom[0], 2)} – {formater(dom[1], 2)} m ({orig}).")
        self.analyse.setText("<br>".join(lignes))
        pts = [self.projet.serie(s)[["H", "Q"]].assign(source=s) for s in SOURCES
               if not self.projet.series[s].vide()]
        pts = pd.concat(pts).dropna() if pts else None
        self.graph.dessiner(plots.reference, r, dom, pts)

    def appliquer(self):
        r = self.projet.reference
        vals = [lire_nombre(w.text()) for w in (self.a0, self.a1, self.a2)]
        if any(np.isnan(v) for v in vals):
            message(self, "Modèle de référence", "Les coefficients a₀, a₁ et a₂ doivent être des nombres.")
            return
        r.a0, r.a1, r.a2 = vals
        hmin, hmax = lire_nombre(self.hmin.text()), lire_nombre(self.hmax.text())
        r.h_min = None if np.isnan(hmin) else hmin
        r.h_max = None if np.isnan(hmax) else hmax
        r.nom = self.nom.text().strip() or "Modèle de référence"
        r.description = self.desc.text().strip()
        self.f.modifie()
        self.rafraichir()

    def thys(self):
        from ..core.rating import ModeleReference
        self.projet.reference = ModeleReference()
        self.f.modifie()
        self.rafraichir()
