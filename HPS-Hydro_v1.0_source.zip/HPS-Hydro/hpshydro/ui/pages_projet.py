"""Pages Accueil et Projet & bassin."""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QVBoxLayout, QWidget,
)

from ..core.projet import Bassin
from .widgets import TableEditable, bouton, defilant, entete, groupe, lire_nombre


class Page(QWidget):
    """Classe de base : chaque page lit et écrit le projet de la fenêtre principale."""

    titre_nav = ""

    def __init__(self, fenetre):
        super().__init__()
        self.f = fenetre

    @property
    def projet(self):
        return self.f.projet

    def rafraichir(self):
        pass

    def quitter(self):
        """Appelée avant de changer de page : enregistre les saisies en cours."""
        pass


class PageAccueil(Page):
    titre_nav = "Accueil"

    def __init__(self, fenetre):
        super().__init__(fenetre)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(40, 30, 40, 30)
        t = QLabel("HPS-Hydro")
        t.setObjectName("titreAccueil")
        lay.addWidget(t)
        s = QLabel("Calage multi-source des courbes de tarage et validation hydrologique "
                   "pour les bassins pauvres en stations")
        s.setObjectName("sousTitreAccueil")
        s.setWordWrap(True)
        lay.addWidget(s)
        lay.addSpacing(18)
        txt = QLabel(
            "Le logiciel reprend la méthode développée pour la rivière Inkisi : lorsque les stations "
            "hydrométriques ont disparu, le débit est reconstitué en combinant plusieurs sources, puis "
            "fusionné par le modèle <b>HPS-Hydro</b> (Hybride à Pondération Sigmoïdale)."
        )
        txt.setWordWrap(True)
        txt.setTextFormat(Qt.RichText)
        lay.addWidget(txt)
        lay.addSpacing(10)

        grille = QGridLayout()
        etapes = [
            ("1", "Mesures in situ", "Jaugeages historiques et séries mesurées (Q_hist), courbes de tarage."),
            ("2", "Apprentissage automatique", "Reconstitution des débits sur la période sans mesures (Q_ML), "
                                              "avec validation hors échantillon."),
            ("3", "Altimétrie SWOT", "Débit des stations virtuelles par l'équation de Manning (Q_SWOT)."),
            ("4", "Modèle de référence", "Relation empirique de Thys, valable en étiage (Q_ref)."),
            ("5", "Fusion HPS-Hydro", "Q̄ = σ(H)·moyenne des sources + (1 − σ(H))·Q_ref, avec incertitude ±1σ."),
            ("6", "Validation", "Contrôles de cohérence, validation « une source exclue », rapport Word."),
        ]
        for i, (n, titre, desc) in enumerate(etapes):
            carte = QWidget()
            carte.setObjectName("carte")
            cl = QVBoxLayout(carte)
            a = QLabel(f"<span style='color:#6a3d9a;font-size:20px;font-weight:700'>{n}</span>"
                       f"&nbsp;&nbsp;<b>{titre}</b>")
            a.setTextFormat(Qt.RichText)
            b = QLabel(desc)
            b.setWordWrap(True)
            b.setObjectName("aide")
            cl.addWidget(a)
            cl.addWidget(b)
            grille.addWidget(carte, i // 3, i % 3)
        lay.addLayout(grille)
        lay.addSpacing(18)
        boutons = QHBoxLayout()
        boutons.addWidget(bouton("Ouvrir le projet de démonstration (Inkisi)", self.f.ouvrir_demo))
        boutons.addWidget(bouton("Nouveau projet", self.f.nouveau, secondaire=True))
        boutons.addWidget(bouton("Ouvrir un projet…", self.f.ouvrir, secondaire=True))
        boutons.addStretch()
        lay.addLayout(boutons)
        lay.addStretch()
        from .. import AUTEUR, COURRIEL, INSTITUTION, TELEPHONE
        contact = QLabel(f"<b>{AUTEUR}</b> — {INSTITUTION}<br>Vos retours sont les bienvenus : "
                         f"<a href='mailto:{COURRIEL}'>{COURRIEL}</a> — {TELEPHONE}")
        contact.setTextFormat(Qt.RichText)
        contact.setOpenExternalLinks(True)
        contact.setObjectName("aide")
        lay.addWidget(contact)


class PageProjet(Page):
    titre_nav = "Projet et bassin"

    CHAMPS_BASSIN = [
        ("riviere", "Rivière", False),
        ("superficie_km2", "Superficie totale (km²)", True),
        ("longueur_m", "Longueur du cours d'eau principal (m)", True),
        ("pente_pct", "Pente moyenne (%)", True),
        ("alt_min_m", "Altitude minimale (m)", True),
        ("alt_max_m", "Altitude maximale (m)", True),
        ("exutoire_lat", "Exutoire — latitude (°)", True),
        ("exutoire_lon", "Exutoire — longitude (°)", True),
    ]

    def __init__(self, fenetre):
        super().__init__(fenetre)
        contenu = QWidget()
        lay = QVBoxLayout(contenu)
        lay.addWidget(entete("Projet et bassin versant",
                             "Identification du projet, caractéristiques du bassin, stations et calendrier "
                             "des saisons hydrologiques."))
        haut = QHBoxLayout()
        g1, f1 = groupe("Projet")
        self.titre = QLineEdit()
        self.auteur = QLineEdit()
        self.institution = QLineEdit()
        self.notes = QPlainTextEdit()
        self.notes.setMaximumHeight(90)
        f1.addRow("Titre", self.titre)
        f1.addRow("Auteur", self.auteur)
        f1.addRow("Institution", self.institution)
        f1.addRow("Notes", self.notes)
        haut.addWidget(g1, 1)
        g2, f2 = groupe("Bassin versant")
        self.bassin = {}
        for k, lib, _ in self.CHAMPS_BASSIN:
            e = QLineEdit()
            self.bassin[k] = e
            f2.addRow(lib, e)
        haut.addWidget(g2, 1)
        lay.addLayout(haut)

        g3, f3 = groupe("Répartition du bassin par pays")
        self.pays = TableEditable({"pays": "Pays", "superficie_km2": "Superficie (km²)",
                                   "pourcentage": "Part du bassin (%)"},
                                  numeriques=("superficie_km2", "pourcentage"))
        self.pays.setMinimumHeight(130)
        f3.addRow(self.pays)
        lay.addWidget(g3)

        g4, f4 = groupe("Stations hydrométriques (coordonnées en degrés décimaux ou en DMS, ex. 5°08'38\"S)")
        self.stations = TableEditable({"nom": "Station", "latitude": "Latitude", "longitude": "Longitude",
                                       "nature": "Nature", "etat": "État actuel"})
        self.stations.setMinimumHeight(210)
        f4.addRow(self.stations)
        lay.addWidget(g4)

        g5, f5 = groupe("Saisons hydrologiques (utilisées pour colorer les hydrogrammes)")
        grille = QGridLayout()
        mois = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août",
                "Septembre", "Octobre", "Novembre", "Décembre"]
        self.saisons = {}
        for i, m in enumerate(mois, start=1):
            cb = QComboBox()
            cb.setEditable(True)
            cb.addItems(["Saison des pluies", "Petite saison sèche", "Saison sèche"])
            self.saisons[i] = cb
            grille.addWidget(QLabel(m), (i - 1) // 4, 2 * ((i - 1) % 4))
            grille.addWidget(cb, (i - 1) // 4, 2 * ((i - 1) % 4) + 1)
        f5.addRow(grille)
        lay.addWidget(g5)
        lay.addStretch()

        racine = QVBoxLayout(self)
        racine.setContentsMargins(0, 0, 0, 0)
        racine.addWidget(defilant(contenu))

        for w in [self.titre, self.auteur, self.institution, *self.bassin.values()]:
            w.textEdited.connect(lambda *_: self.f.modifie(recalcul=False))
        self.notes.textChanged.connect(lambda: self.f.modifie(recalcul=False) if self.notes.hasFocus() else None)
        self.pays.modifie.connect(lambda: self.f.modifie(recalcul=False))
        self.stations.modifie.connect(lambda: self.f.modifie(recalcul=False))
        for cb in self.saisons.values():
            cb.currentTextChanged.connect(lambda *_: self.f.modifie() if self.isVisible() else None)

    def rafraichir(self):
        p = self.projet
        self.titre.setText(p.titre)
        self.auteur.setText(p.auteur)
        self.institution.setText(p.institution)
        self.notes.blockSignals(True)
        self.notes.setPlainText(p.notes)
        self.notes.blockSignals(False)
        for k, _, num in self.CHAMPS_BASSIN:
            v = getattr(p.bassin, k)
            if v is None or (isinstance(v, float) and np.isnan(v)):
                self.bassin[k].setText("")
            else:
                self.bassin[k].setText(np.format_float_positional(float(v), trim="-").replace(".", ",")
                                       if num else str(v))
        self.pays.definir(p.pays)
        self.stations.definir(p.stations)
        for m, cb in self.saisons.items():
            cb.blockSignals(True)
            cb.setCurrentText(p.saisons.get(m, ""))
            cb.blockSignals(False)

    def quitter(self):
        p = self.projet
        p.titre = self.titre.text().strip() or p.titre
        p.auteur = self.auteur.text().strip()
        p.institution = self.institution.text().strip()
        p.notes = self.notes.toPlainText()
        valeurs = {}
        for k, _, num in self.CHAMPS_BASSIN:
            t = self.bassin[k].text().strip()
            if num:
                x = lire_nombre(t)
                valeurs[k] = None if np.isnan(x) else x
            else:
                valeurs[k] = t
        valeurs["description"] = p.bassin.description
        p.bassin = Bassin(**valeurs)
        p.pays = self.pays.valeur()
        p.stations = self.stations.valeur()
        p.saisons = {m: cb.currentText().strip() for m, cb in self.saisons.items()}
