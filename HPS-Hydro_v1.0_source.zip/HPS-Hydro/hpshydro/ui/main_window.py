"""Fenêtre principale de HPS-Hydro."""

from __future__ import annotations

import sys
import traceback
from contextlib import contextmanager
from pathlib import Path

from PySide6.QtCore import QLocale, QSize, Qt, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QFont, QIcon, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QStackedWidget, QVBoxLayout, QWidget,
)

from .. import APP_NAME, APP_TITLE, AUTEUR, COURRIEL, INSTITUTION, TELEPHONE, __version__
from ..core import hps
from ..core.projet import Projet, projet_demo_inkisi
from .pages_projet import PageAccueil, PageProjet
from .pages_resultats import PageFusion, PageRapport, PageValidation
from .pages_sources import PageHist, PageJaugeages, PageML, PageReference, PageSWOT

RESSOURCES = Path(__file__).resolve().parent.parent / "resources"


def ressource(nom: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", RESSOURCES.parent.parent))
    p = base / "hpshydro" / "resources" / nom
    return p if p.exists() else RESSOURCES / nom


class FenetrePrincipale(QMainWindow):
    def __init__(self):
        super().__init__()
        self.projet = Projet()
        self._res = None
        self._res_erreur = None
        self.resultat_ml = None
        self.sale = False
        self.resize(1360, 860)
        self.setMinimumSize(1100, 700)
        icone = ressource("icone.png")
        if icone.exists():
            self.setWindowIcon(QIcon(str(icone)))

        central = QWidget()
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        cote = QWidget()
        cote.setObjectName("navigation")
        cl = QVBoxLayout(cote)
        cl.setContentsMargins(0, 18, 0, 12)
        marque = QLabel("HPS-Hydro")
        marque.setObjectName("marque")
        cl.addWidget(marque)
        sous = QLabel("Calage multi-source\net validation")
        sous.setObjectName("marqueSous")
        cl.addWidget(sous)
        cl.addSpacing(14)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        cl.addWidget(self.nav, 1)
        version = QLabel(f"Version {__version__}")
        version.setObjectName("marqueSous")
        cl.addWidget(version)
        cote.setFixedWidth(250)
        lay.addWidget(cote)

        self.pile = QStackedWidget()
        self.pile.setObjectName("contenu")
        lay.addWidget(self.pile, 1)
        self.setCentralWidget(central)

        self.pages = []
        sections = [
            (None, PageAccueil),
            ("PROJET", PageProjet),
            ("SOURCES DE DÉBIT", PageJaugeages), (None, PageHist), (None, PageML), (None, PageSWOT),
            (None, PageReference),
            ("CALAGE ET VALIDATION", PageFusion), (None, PageValidation), (None, PageRapport),
        ]
        for section, cls in sections:
            if section:
                it = QListWidgetItem(section)
                it.setFlags(Qt.NoItemFlags)
                it.setData(Qt.UserRole, -1)
                it.setSizeHint(QSize(0, 36))
                it.setTextAlignment(Qt.AlignLeft | Qt.AlignBottom)
                f = it.font()
                f.setPointSize(8)
                f.setBold(True)
                it.setFont(f)
                self.nav.addItem(it)
            page = cls(self)
            page.setContentsMargins(18, 14, 18, 10)
            self.pages.append(page)
            self.pile.addWidget(page)
            it = QListWidgetItem(page.titre_nav)
            it.setData(Qt.UserRole, len(self.pages) - 1)
            it.setSizeHint(QSize(0, 34))
            self.nav.addItem(it)
        self.nav.currentItemChanged.connect(self._nav)
        self._page_courante = 0
        self.nav.setCurrentRow(0)

        self._menus()
        self.statusBar().showMessage("Prêt")
        self._titre()

    # ------------------------------------------------------------------ menus
    def _menus(self):
        m = self.menuBar().addMenu("&Fichier")
        for texte, action, raccourci in [
            ("Nouveau projet", self.nouveau, QKeySequence.New),
            ("Ouvrir…", self.ouvrir, QKeySequence.Open),
            ("Ouvrir le projet de démonstration (Inkisi)", self.ouvrir_demo, None),
            (None, None, None),
            ("Enregistrer", self.enregistrer, QKeySequence.Save),
            ("Enregistrer sous…", self.enregistrer_sous, QKeySequence.SaveAs),
            (None, None, None),
            ("Quitter", self.close, QKeySequence.Quit),
        ]:
            if texte is None:
                m.addSeparator()
                continue
            a = QAction(texte, self)
            a.triggered.connect(action)
            if raccourci:
                a.setShortcut(raccourci)
            m.addAction(a)
        aide = self.menuBar().addMenu("&Aide")
        a = QAction("Méthode HPS-Hydro", self)
        a.triggered.connect(self.methode)
        aide.addAction(a)
        a = QAction("Envoyer un retour à l'auteur…", self)
        a.triggered.connect(self.retour)
        aide.addAction(a)
        a = QAction("À propos", self)
        a.triggered.connect(self.a_propos)
        aide.addAction(a)

    # ------------------------------------------------------------ navigation
    def _nav(self, courant, precedent):
        if courant is None:
            return
        i = courant.data(Qt.UserRole)
        if i is None or i < 0:
            return
        self.pages[self._page_courante].quitter()
        self._page_courante = i
        self.pile.setCurrentIndex(i)
        try:
            self.pages[i].rafraichir()
        except Exception:
            self._erreur_inattendue()

    def aller(self, classe):
        for r in range(self.nav.count()):
            i = self.nav.item(r).data(Qt.UserRole)
            if i is not None and i >= 0 and isinstance(self.pages[i], classe):
                self.nav.setCurrentRow(r)
                return

    # --------------------------------------------------------------- état
    def modifie(self, recalcul: bool = True):
        self.sale = True
        if recalcul:
            self._res = None
            self._res_erreur = None
            self.pages_a_relire = True
            for p in self.pages:
                if isinstance(p, PageValidation):
                    p.constats = []
        self._titre()

    def _titre(self):
        nom = self.projet.chemin.name if self.projet.chemin else "sans nom"
        self.setWindowTitle(f"{'• ' if self.sale else ''}{nom} — {APP_TITLE}")

    def statut(self, texte: str):
        self.statusBar().showMessage(texte, 8000)

    @contextmanager
    def attente(self, texte="Calcul en cours…"):
        self.statusBar().showMessage(texte)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        QApplication.processEvents()
        try:
            yield
        finally:
            QApplication.restoreOverrideCursor()
            self.statusBar().showMessage("Prêt", 3000)

    def resultat_hps(self, silencieux=False):
        if self._res is None and self._res_erreur is None:
            try:
                self._res = hps.fusionner(self.projet)
            except Exception as exc:
                self._res_erreur = str(exc)
        if self._res is None and not silencieux:
            QMessageBox.warning(self, "Fusion HPS-Hydro", f"Calcul impossible : {self._res_erreur}")
        return self._res

    # ------------------------------------------------------------ fichiers
    def _confirmer_abandon(self) -> bool:
        if not self.sale:
            return True
        r = QMessageBox.question(self, APP_NAME, "Le projet a été modifié. L'enregistrer ?",
                                 QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        if r == QMessageBox.Save:
            return self.enregistrer()
        return r == QMessageBox.Discard

    def _charger(self, projet: Projet):
        self.projet = projet
        self._res = None
        self._res_erreur = None
        self.resultat_ml = None
        self.sale = False
        for p in self.pages:
            if isinstance(p, PageValidation):
                p.constats = []
        self._titre()
        self.pages[self._page_courante].rafraichir()

    def nouveau(self):
        if self._confirmer_abandon():
            self._charger(Projet())
            self.aller(PageProjet)

    def ouvrir_demo(self):
        if self._confirmer_abandon():
            self._charger(projet_demo_inkisi())
            self.sale = True
            self._titre()
            self.aller(PageFusion)
            self.statut("Projet de démonstration Inkisi chargé (données des tableaux de la présentation).")

    def ouvrir(self, chemin=None):
        if not self._confirmer_abandon():
            return
        if not chemin:
            chemin, _ = QFileDialog.getOpenFileName(self, "Ouvrir un projet", "", "Projets HPS-Hydro (*.hpsh)")
        if not chemin:
            return
        try:
            p = Projet.ouvrir(chemin)
        except Exception as exc:
            QMessageBox.critical(self, "Ouverture", f"Impossible d'ouvrir le projet :\n{exc}")
            return
        self._charger(p)
        self.aller(PageProjet)

    def enregistrer(self) -> bool:
        if self.projet.chemin is None:
            return self.enregistrer_sous()
        self.pages[self._page_courante].quitter()
        try:
            self.projet.enregistrer(self.projet.chemin)
        except Exception as exc:
            QMessageBox.critical(self, "Enregistrement", str(exc))
            return False
        self.sale = False
        self._titre()
        self.statut(f"Projet enregistré : {self.projet.chemin}")
        return True

    def enregistrer_sous(self) -> bool:
        nom = (self.projet.titre.split("—")[0].strip().replace(" ", "_") or "projet") + ".hpsh"
        chemin, _ = QFileDialog.getSaveFileName(self, "Enregistrer le projet", nom, "Projets HPS-Hydro (*.hpsh)")
        if not chemin:
            return False
        if not chemin.lower().endswith(".hpsh"):
            chemin += ".hpsh"
        self.projet.chemin = Path(chemin)
        return self.enregistrer()

    def closeEvent(self, e):
        self.pages[self._page_courante].quitter()
        if self._confirmer_abandon():
            e.accept()
        else:
            e.ignore()

    # ---------------------------------------------------------------- aide
    def methode(self):
        QMessageBox.information(self, "Méthode HPS-Hydro", (
            "Modèle Hybride à Pondération Sigmoïdale pour un calage multi-station.\n\n"
            "Q̄(t) = σ(H(t)) · [Q_hist(t) + Q_ML(t) + Q_SWOT(t)] / n_dispo(t) + (1 − σ(H(t))) · Q_Thys(t)\n\n"
            "σ(H) = 1 / (1 + exp(−α (H − H₀)))\n\n"
            "• Faibles hauteurs (étiage) : σ → 0, Q̄ ≈ Q_Thys (référence physique).\n"
            "• Hauteurs élevées (crue) : σ → 1, Q̄ ≈ moyenne des sources disponibles.\n\n"
            "Variante par source : σᵢ = 1 / (1 + exp(−α (Qᵢ − Q_Thys))).\n\n"
            "Q_Thys(H) = 94,510 − 78,571 H + 15,624 H² (R. Thys, 19 jaugeages, 1910-1911)."))

    def retour(self):
        from urllib.parse import quote
        sujet = quote(f"Retour sur {APP_NAME} {__version__}")
        corps = quote("Bonjour,\n\nBassin étudié :\nCe qui fonctionne bien :\nDifficultés rencontrées :\n"
                      "Fonctions souhaitées :\n\nCordialement,")
        QDesktopServices.openUrl(QUrl(f"mailto:{COURRIEL}?subject={sujet}&body={corps}"))

    def a_propos(self):
        QMessageBox.about(self, "À propos", (
            f"<b>{APP_NAME} {__version__}</b><br><br>"
            f"Auteur : <b>{AUTEUR}</b><br>{INSTITUTION}<br>"
            f"Courriel : <a href='mailto:{COURRIEL}'>{COURRIEL}</a> — Tél. : {TELEPHONE}<br><br>"
            "Vos retours (bassin étudié, difficultés, fonctions souhaitées) sont les bienvenus : "
            "menu Aide → Envoyer un retour à l'auteur.<br><br>"
            "Logiciel de calage multi-source des courbes de tarage et de validation hydrologique, fondé sur "
            "la méthode développée pour la rivière Inkisi (RDC) : mesures historiques, apprentissage "
            "automatique, altimétrie SWOT (Manning) et modèle de Thys, fusionnés par le modèle HPS-Hydro.<br><br>"
            "Bibliothèques : Python, PySide6 (Qt), pandas, NumPy, SciPy, scikit-learn, XGBoost, "
            "matplotlib, python-docx."))

    def _erreur_inattendue(self):
        QMessageBox.critical(self, "Erreur", "Une erreur inattendue est survenue :\n\n" + traceback.format_exc(limit=3))


def run(argv=None) -> int:
    argv = argv or sys.argv
    QLocale.setDefault(QLocale(QLocale.French, QLocale.France))
    app = QApplication.instance() or QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    police = QFont("Segoe UI", 10)
    app.setFont(police)
    qss = ressource("style.qss")
    if qss.exists():
        dossier = qss.parent.as_posix()
        app.setStyleSheet(qss.read_text(encoding="utf-8").replace("{RES}", dossier))
    icone = ressource("icone.png")
    if icone.exists():
        app.setWindowIcon(QIcon(str(icone)))

    def crochet(t, v, tb):
        if sys.stderr is not None:  # absent dans l'exécutable Windows sans console
            try:
                traceback.print_exception(t, v, tb)
            except Exception:
                pass
        QMessageBox.critical(None, "Erreur", "".join(traceback.format_exception_only(t, v)))
    sys.excepthook = crochet

    if "--autotest" in argv:
        return autotest()

    w = FenetrePrincipale()
    w.show()
    fichiers = [a for a in argv[1:] if a.lower().endswith(".hpsh")]
    if fichiers:
        w.ouvrir(fichiers[0])
    return app.exec()


def autotest() -> int:
    """Vérifie une installation : HPS-Hydro.exe --autotest écrit HPS-Hydro_autotest.txt dans le dossier personnel."""
    import tempfile
    from ..core import ml, report, validation
    journal = Path.home() / "HPS-Hydro_autotest.txt"
    lignes, ok = [f"{APP_NAME} {__version__} — auto-test"], True
    try:
        w = FenetrePrincipale()
        w.show()
        QApplication.processEvents()
        w._charger(projet_demo_inkisi())
        for p in w.pages:
            w.pile.setCurrentWidget(p)
            p.rafraichir()
            QApplication.processEvents()
        lignes.append(f"Pages affichées : {len(w.pages)}")
        res = w.resultat_hps(silencieux=True)
        lignes.append(f"Fusion : {res.table['Q_global'].notna().sum()} pas de temps, "
                      f"débit moyen {res.table['Q_global'].mean():.2f} m³/s")
        r = ml.entrainer(w.projet.serie("hist"), w.projet.ml)
        lignes.append(f"Apprentissage ({r.moteur}) : NSE validation croisée {r.validation_croisee['nse']:.3f}")
        c = validation.tout_controler(w.projet, res)
        lignes.append(f"Contrôles : {validation.bilan(c)}")
        with tempfile.TemporaryDirectory() as d:
            f = report.generer(w.projet, res, Path(d) / "test.docx", resultat_ml=r)
            lignes.append(f"Rapport Word : {f.stat().st_size // 1024} Ko")
        w.sale = False
        w.close()
    except Exception:
        ok = False
        lignes.append(traceback.format_exc())
    lignes.append("RÉSULTAT : " + ("SUCCÈS" if ok else "ÉCHEC"))
    journal.write_text("\n".join(lignes), encoding="utf-8")
    if sys.stdout is not None:  # console Windows : encodage limité, on remplace l'inconnu
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        texte = "\n".join(lignes).encode(enc, errors="replace").decode(enc, errors="replace")
        try:
            print(texte)
        except Exception:
            pass
    return 0 if ok else 1
