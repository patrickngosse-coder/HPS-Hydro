"""Composants réutilisables de l'interface."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure
from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QFrame, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QMessageBox, QPushButton, QScrollArea, QSizePolicy,
    QTableView, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)


# ------------------------------------------------------------------ tableaux
class ModelePandas(QAbstractTableModel):
    """Affichage en lecture seule d'un DataFrame, avec format numérique français."""

    def __init__(self, df: pd.DataFrame | None = None, decimales: int = 3, index: bool = False):
        super().__init__()
        self._index = index
        self.decimales = decimales
        self.couleurs_lignes: dict[int, str] = {}
        self.definir(df)

    def definir(self, df):
        self.beginResetModel()
        df = pd.DataFrame() if df is None else df
        if self._index:
            nom = df.index.name if df.index.name not in (None, "index") else " "
            self.df = df.rename_axis(nom).reset_index()
        else:
            self.df = df.reset_index(drop=True)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return len(self.df)

    def columnCount(self, parent=QModelIndex()):
        return len(self.df.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        v = self.df.iat[index.row(), index.column()]
        if role == Qt.DisplayRole:
            return formater(v, self.decimales)
        if role == Qt.TextAlignmentRole:
            if isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool):
                return int(Qt.AlignRight | Qt.AlignVCenter)
            return int(Qt.AlignLeft | Qt.AlignVCenter)
        if role == Qt.BackgroundRole and index.row() in self.couleurs_lignes:
            return QColor(self.couleurs_lignes[index.row()])
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return str(self.df.columns[section])
        return str(section + 1)


def formater(v, decimales=3) -> str:
    if v is None:
        return ""
    if isinstance(v, pd.Timestamp):
        return "" if pd.isna(v) else v.strftime("%Y-%m-%d")
    if isinstance(v, (bool, np.bool_)):
        return "oui" if v else "non"
    if isinstance(v, (int, np.integer)):
        return f"{v:,}".replace(",", " ")
    if isinstance(v, (float, np.floating)):
        if not np.isfinite(v):
            return ""
        if abs(v - round(v)) < 1e-12 and abs(v) < 1e7:
            return f"{int(round(v)):,}".replace(",", " ")
        return f"{v:,.{decimales}f}".replace(",", " ").replace(".", ",")
    try:
        if pd.isna(v):
            return ""
    except (TypeError, ValueError):
        pass
    return str(v)


def vue_tableau(df=None, decimales=3, index=False) -> tuple[QTableView, ModelePandas]:
    vue = QTableView()
    modele = ModelePandas(df, decimales, index)
    vue.setModel(modele)
    vue.setAlternatingRowColors(True)
    vue.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    vue.horizontalHeader().setStretchLastSection(True)
    vue.verticalHeader().setDefaultSectionSize(22)
    vue.setSelectionBehavior(QTableView.SelectRows)
    return vue, modele


class TableEditable(QWidget):
    """Tableau modifiable relié à un DataFrame (bassin, stations, jaugeages)."""

    modifie = Signal()

    def __init__(self, colonnes: dict[str, str], numeriques=(), parent=None):
        super().__init__(parent)
        self.colonnes = colonnes  # nom interne -> libellé
        self.numeriques = set(numeriques)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, len(colonnes))
        self.table.setHorizontalHeaderLabels(list(colonnes.values()))
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setDefaultSectionSize(22)
        self.table.setAlternatingRowColors(True)
        self.table.itemChanged.connect(lambda *_: self.modifie.emit())
        lay.addWidget(self.table)
        barre = QHBoxLayout()
        b1, b2 = QPushButton("Ajouter une ligne"), QPushButton("Supprimer la ligne")
        b1.setProperty("secondaire", True)
        b2.setProperty("secondaire", True)
        b1.clicked.connect(self.ajouter)
        b2.clicked.connect(self.supprimer)
        barre.addWidget(b1)
        barre.addWidget(b2)
        barre.addStretch()
        lay.addLayout(barre)

    def definir(self, df: pd.DataFrame):
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        for _, r in df.iterrows():
            i = self.table.rowCount()
            self.table.insertRow(i)
            for j, c in enumerate(self.colonnes):
                v = r.get(c)
                if c in self.numeriques and isinstance(v, (int, float, np.integer, np.floating)):
                    txt = "" if pd.isna(v) else np.format_float_positional(float(v), trim="-").replace(".", ",")
                else:
                    txt = formater(v)
                self.table.setItem(i, j, QTableWidgetItem(txt))
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.blockSignals(False)

    def valeur(self) -> pd.DataFrame:
        lignes = []
        for i in range(self.table.rowCount()):
            d = {}
            for j, c in enumerate(self.colonnes):
                it = self.table.item(i, j)
                txt = it.text().strip() if it else ""
                if c in self.numeriques:
                    d[c] = lire_nombre(txt)
                else:
                    d[c] = txt or None
            if any(v is not None and not (isinstance(v, float) and np.isnan(v)) for v in d.values()):
                lignes.append(d)
        return pd.DataFrame(lignes, columns=list(self.colonnes))

    def ajouter(self):
        self.table.insertRow(self.table.rowCount())
        self.modifie.emit()

    def supprimer(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            self.table.removeRow(r)
        self.modifie.emit()


def lire_nombre(txt) -> float:
    if txt is None:
        return np.nan
    t = str(txt).strip().replace(" ", "").replace("\xa0", "").replace(" ", "").replace(",", ".")
    if t == "":
        return np.nan
    try:
        return float(t)
    except ValueError:
        return np.nan


# ------------------------------------------------------------------ graphiques
class Graphique(QWidget):
    def __init__(self, parent=None, hauteur=4.5):
        super().__init__(parent)
        self.figure = Figure(figsize=(8, hauteur), dpi=100)
        self.figure.patch.set_facecolor("white")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.barre = NavigationToolbar2QT(self.canvas, self)
        lay.addWidget(self.barre)
        lay.addWidget(self.canvas)

    def dessiner(self, fonction, *args, **kwargs):
        try:
            fonction(self.figure, *args, **kwargs)
        except Exception as exc:  # un graphique ne doit jamais faire planter l'application
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.axis("off")
            ax.text(0.5, 0.5, f"Graphique indisponible :\n{exc}", ha="center", va="center", color="#a33")
        self.canvas.draw_idle()


# ------------------------------------------------------------------ mise en page
def entete(titre: str, sous_titre: str = "") -> QWidget:
    w = QWidget()
    w.setObjectName("entete")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 6)
    t = QLabel(titre)
    t.setObjectName("titrePage")
    lay.addWidget(t)
    if sous_titre:
        s = QLabel(sous_titre)
        s.setObjectName("sousTitre")
        s.setWordWrap(True)
        lay.addWidget(s)
    return w


def groupe(titre: str, contenu=None) -> tuple[QGroupBox, QFormLayout]:
    g = QGroupBox(titre)
    f = QFormLayout(g)
    f.setLabelAlignment(Qt.AlignLeft)
    f.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
    return g, f


def defilant(widget: QWidget) -> QScrollArea:
    s = QScrollArea()
    s.setWidgetResizable(True)
    s.setFrameShape(QFrame.NoFrame)
    s.setWidget(widget)
    return s


def bouton(texte: str, action=None, secondaire=False) -> QPushButton:
    b = QPushButton(texte)
    if secondaire:
        b.setProperty("secondaire", True)
    if action:
        b.clicked.connect(action)
    return b


def message(parent, titre, texte, erreur=False):
    (QMessageBox.critical if erreur else QMessageBox.information)(parent, titre, texte)


# ------------------------------------------------------------------ import
def lire_fichier(chemin: str) -> pd.DataFrame:
    p = Path(chemin)
    if p.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(p)
    for enc in ("utf-8-sig", "latin-1"):
        try:
            df = pd.read_csv(p, sep=None, engine="python", encoding=enc)
            break
        except UnicodeDecodeError:
            continue
    # virgule décimale
    for c in df.columns:
        if not pd.api.types.is_numeric_dtype(df[c]) and not pd.api.types.is_datetime64_any_dtype(df[c]):
            conv = pd.to_numeric(df[c].astype(str).str.replace(" ", "").str.replace("\xa0", "")
                                 .str.replace(" ", "").str.replace(",", "."), errors="coerce")
            if conv.notna().sum() >= 0.8 * df[c].notna().sum() and df[c].notna().sum() > 0:
                df[c] = conv
    return df


MOIS_FR = {"janvier": 1, "fevrier": 2, "février": 2, "mars": 3, "avril": 4, "mai": 5, "juin": 6,
           "juillet": 7, "aout": 8, "août": 8, "septembre": 9, "octobre": 10, "novembre": 11,
           "decembre": 12, "décembre": 12}


class DialogueImport(QDialog):
    """Associe les colonnes d'un fichier CSV/Excel aux grandeurs attendues."""

    def __init__(self, parent, champs: dict[str, str], obligatoires=("Q",), avec_date=True, station=False):
        super().__init__(parent)
        self.setWindowTitle("Importer des données")
        self.resize(900, 560)
        self.champs = dict(champs)
        self.obligatoires = obligatoires
        self.avec_date = avec_date
        self.df_source = None
        self.resultat = None
        lay = QVBoxLayout(self)
        haut = QHBoxLayout()
        self.lbl = QLabel("Aucun fichier choisi")
        haut.addWidget(bouton("Choisir un fichier CSV ou Excel…", self.choisir))
        haut.addWidget(self.lbl, 1)
        lay.addLayout(haut)
        self.vue, self.modele = vue_tableau()
        self.vue.setMinimumHeight(220)
        lay.addWidget(self.vue)
        g, self.form = groupe("Correspondance des colonnes")
        self.combos = {}
        cles = []
        if avec_date:
            cles += [("date", "Date"), ("annee", "ou Année"), ("mois", "Mois"), ("jour", "Jour")]
        if station:
            cles += [("station", "Station")]
        cles += list(self.champs.items())
        for k, lib in cles:
            cb = QComboBox()
            cb.addItem("— aucune —")
            self.combos[k] = cb
            self.form.addRow(lib + (" *" if k in obligatoires else ""), cb)
        lay.addWidget(g)
        note = QLabel("Les dates peuvent être données dans une colonne « Date » ou par Année + Mois (+ Jour). "
                      "Les mois en toutes lettres (janvier…décembre) sont reconnus.")
        note.setWordWrap(True)
        note.setObjectName("aide")
        lay.addWidget(note)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Importer")
        bb.button(QDialogButtonBox.Cancel).setText("Annuler")
        bb.accepted.connect(self.valider)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def choisir(self):
        chemin, _ = QFileDialog.getOpenFileName(self, "Choisir un fichier", "",
                                                "Données (*.csv *.txt *.xlsx *.xls);;Tous (*.*)")
        if not chemin:
            return
        try:
            self.df_source = lire_fichier(chemin)
        except Exception as exc:
            message(self, "Lecture impossible", str(exc), erreur=True)
            return
        self.lbl.setText(f"{Path(chemin).name} — {len(self.df_source)} lignes")
        self.modele.definir(self.df_source.head(200))
        self.vue.resizeColumnsToContents()
        cols = [str(c) for c in self.df_source.columns]
        for k, cb in self.combos.items():
            cb.clear()
            cb.addItem("— aucune —")
            cb.addItems(cols)
            # correspondance automatique sur le nom
            for i, c in enumerate(cols):
                n = c.lower().replace("é", "e").replace("è", "e").strip()
                if n == k.lower() or n.startswith(k.lower()) or (k == "annee" and n in ("annee", "year", "an")) \
                        or (k == "H" and n in ("h", "hauteur", "h(m)")) or (k == "Q" and n.startswith("q")) \
                        or (k == "niveau" and n.startswith(("niveau", "n (m)", "n(m)", "wse"))):
                    cb.setCurrentIndex(i + 1)
                    break

    def _col(self, k):
        cb = self.combos.get(k)
        if cb is None or cb.currentIndex() <= 0:
            return None
        return self.df_source[cb.currentText()]

    def valider(self):
        if self.df_source is None:
            message(self, "Import", "Choisissez d'abord un fichier.")
            return
        out = pd.DataFrame(index=self.df_source.index)
        if self.avec_date:
            d = self._col("date")
            if d is not None:
                out["date"] = pd.to_datetime(d, errors="coerce", dayfirst=True)
            else:
                a = self._col("annee")
                if a is None:
                    message(self, "Import", "Indiquez la colonne Date, ou au moins la colonne Année.")
                    return
                m = self._col("mois")
                if m is None:
                    m = pd.Series(7, index=a.index)
                elif not pd.api.types.is_numeric_dtype(m):
                    m = m.astype(str).str.strip().str.lower().map(MOIS_FR).fillna(pd.to_numeric(m, errors="coerce"))
                j = self._col("jour")
                if j is None:
                    j = pd.Series(15 if self._col("mois") is not None else 1, index=a.index)
                out["date"] = pd.to_datetime(dict(year=pd.to_numeric(a, errors="coerce"),
                                                  month=pd.to_numeric(m, errors="coerce"),
                                                  day=pd.to_numeric(j, errors="coerce")), errors="coerce")
            if out["date"].isna().all():
                message(self, "Import", "Aucune date n'a pu être lue.")
                return
        if "station" in self.combos:
            s = self._col("station")
            out["station"] = s.astype(str) if s is not None else None
        for k in self.champs:
            c = self._col(k)
            out[k] = pd.to_numeric(c, errors="coerce") if c is not None else np.nan
        manquants = [self.champs[k] for k in self.obligatoires if k in self.champs and out[k].isna().all()]
        if manquants:
            message(self, "Import", "Colonne(s) obligatoire(s) non renseignée(s) : " + ", ".join(manquants))
            return
        self.resultat = out
        self.accept()
