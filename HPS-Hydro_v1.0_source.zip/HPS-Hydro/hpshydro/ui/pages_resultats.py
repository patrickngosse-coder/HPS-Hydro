"""Pages Fusion HPS-Hydro, Validation et Rapport."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QSplitter,
    QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from ..core import hps, metrics, plots, report, validation
from ..core.projet import SOURCES, SOURCES_COURT
from .pages_projet import Page
from .pages_sources import _PageDeuxColonnes, _label_info, _spin
from .widgets import Graphique, bouton, entete, formater, groupe, message, vue_tableau

COULEURS_NIVEAU = {"erreur": "#f4cccc", "attention": "#fce5cd", "info": "#ddebf7", "ok": "#d9ead3"}


# ======================================================================= Fusion
class PageFusion(_PageDeuxColonnes):
    titre_nav = "Fusion HPS-Hydro"

    def __init__(self, fenetre):
        super().__init__(fenetre, "Fusion HPS-Hydro",
                         "Q̄(t) = σ(H)·[Q_hist + Q_ML + Q_SWOT]/n_dispo + (1 − σ(H))·Q_ref — en étiage le "
                         "modèle de référence domine, en crue la moyenne des sources.")
        g, f = groupe("Pondération sigmoïdale")
        self.mode = QComboBox()
        self.mode.addItem("σ(H) — selon la hauteur d'eau", "H")
        self.mode.addItem("σᵢ — selon l'écart Qᵢ − Q_ref", "ecart")
        self.alpha_h = _spin(0.001, 100, 2.0, 0.1, 3)
        self.h0_auto = QCheckBox("H₀ = médiane des hauteurs")
        self.h0 = _spin(-1000, 10000, 5.0, 0.1, 3)
        self.alpha_q = _spin(0.00001, 10, 0.05, 0.005, 5)
        f.addRow("Mode", self.mode)
        f.addRow("α (m⁻¹)", self.alpha_h)
        f.addRow(self.h0_auto)
        f.addRow("H₀ (m)", self.h0)
        f.addRow("α écart ((m³/s)⁻¹)", self.alpha_q)
        self.hors = QComboBox()
        self.hors.addItem("Extrapoler Q_ref (méthode d'origine)", "extrapoler")
        self.hors.addItem("Exclure Q_ref (moyenne des sources)", "exclure")
        f.addRow("Hors domaine de Q_ref", self.hors)
        self.gauche_lay.addWidget(g)
        g2, f2 = groupe("Sources")
        self.sources = {}
        for s, lib in SOURCES.items():
            cb = QCheckBox(lib)
            self.sources[s] = cb
            f2.addRow(cb)
        f2.addRow(_label_info("La hauteur H(t) utilisée pour σ et Q_ref est prise dans l'ordre "
                              "Q_hist, Q_ML puis Q_SWOT."))
        self.gauche_lay.addWidget(g2)
        self.gauche_lay.addWidget(bouton("Calculer la fusion", self.calculer))
        g3, f3 = groupe("Résultat")
        self.resume = _label_info()
        f3.addRow(self.resume)
        f3.addRow(bouton("Exporter Q̄ (Excel ou CSV)…", self.exporter, True))
        self.gauche_lay.addWidget(g3)
        self.finir_gauche()
        self.mode.currentIndexChanged.connect(self._etat)
        self.h0_auto.toggled.connect(self._etat)

        self.g_hq, self.g_t, self.g_s, self.g_sig = Graphique(), Graphique(), Graphique(), Graphique()
        self.onglets.addTab(self.g_hq, "Q̄(H)")
        self.onglets.addTab(self.g_t, "Hydrogramme")
        self.onglets.addTab(self.g_s, "Saisonnalité")
        self.onglets.addTab(self.g_sig, "Pondération σ")
        self.vue, self.modele = vue_tableau(decimales=3, index=True)
        self.onglets.addTab(self.vue, "Tableau")

    def _etat(self):
        h = self.mode.currentData() == "H"
        self.alpha_h.setEnabled(h)
        self.h0_auto.setEnabled(h)
        self.h0.setEnabled(h and not self.h0_auto.isChecked())
        self.alpha_q.setEnabled(not h)

    def _lire(self):
        p = self.projet.hps
        p.mode = self.mode.currentData()
        p.alpha_h, p.alpha_q = self.alpha_h.value(), self.alpha_q.value()
        p.h0 = None if self.h0_auto.isChecked() else self.h0.value()
        p.hors_domaine = self.hors.currentData()
        p.sources = {s: cb.isChecked() for s, cb in self.sources.items()}

    def rafraichir(self):
        p = self.projet.hps
        self.mode.setCurrentIndex(self.mode.findData(p.mode))
        self.alpha_h.setValue(p.alpha_h)
        self.alpha_q.setValue(p.alpha_q)
        self.h0_auto.setChecked(p.h0 is None)
        if p.h0 is not None:
            self.h0.setValue(p.h0)
        self.hors.setCurrentIndex(self.hors.findData(p.hors_domaine))
        for s, cb in self.sources.items():
            cb.setChecked(p.sources.get(s, True))
            cb.setEnabled(not self.projet.series[s].vide())
        self._etat()
        self.afficher(self.f.resultat_hps(silencieux=True))

    def calculer(self):
        self._lire()
        self.f.modifie()
        res = self.f.resultat_hps()
        self.afficher(res)

    def afficher(self, res):
        if res is None:
            self.resume.setText("Aucun résultat : importez au moins une série de débit.")
            for g in (self.g_hq, self.g_t, self.g_s, self.g_sig):
                g.dessiner(plots._vide, "Aucun résultat de fusion.")
            self.modele.definir(None)
            return
        if res.h0_utilise is not None and self.h0_auto.isChecked():
            self.h0.setValue(res.h0_utilise)
        t = res.table
        q = t["Q_global"]
        notes = "".join(f"<br>• {n}" for n in res.notes)
        self.resume.setText(
            f"<b>{q.notna().sum()}</b> pas de temps, {t.index.min():%Y} – {t.index.max():%Y}<br>"
            f"Q̄ moyen <b>{formater(q.mean(), 2)}</b> m³/s (min {formater(q.min(), 2)} ; "
            f"max {formater(q.max(), 2)})<br>Incertitude moyenne ±{formater(t['incertitude'].mean(), 1)} m³/s"
            f"{notes}")
        self.g_hq.dessiner(plots.fusion_hq, res)
        self.g_t.dessiner(plots.fusion_temps, res)
        self.g_s.dessiner(plots.saisonnalite, hps.saisonnalite(res))
        self.g_sig.dessiner(plots.sigma, res)
        cols = ["H", "H_origine"] + res.colonnes_sources + ["Q_ref", "hors_domaine", "n_dispo", "sigma",
                                                            "Q_global", "incertitude", "saison"]
        self.modele.definir(t[cols])
        self.vue.resizeColumnsToContents()

    def exporter(self):
        res = self.f.resultat_hps()
        if res is None:
            return
        chemin, filtre = QFileDialog.getSaveFileName(self, "Exporter Q̄", "Q_global.xlsx",
                                                     "Excel (*.xlsx);;CSV (*.csv)")
        if not chemin:
            return
        try:
            if chemin.lower().endswith(".csv"):
                res.table.to_csv(chemin, sep=";", decimal=",")
            else:
                if not chemin.lower().endswith(".xlsx"):
                    chemin += ".xlsx"
                res.table.to_excel(chemin)
        except Exception as exc:
            message(self, "Export", str(exc), erreur=True)
            return
        self.f.statut(f"Résultats exportés : {chemin}")


# ======================================================================= Validation
class PageValidation(Page):
    titre_nav = "Validation"

    def __init__(self, fenetre):
        super().__init__(fenetre)
        lay = QVBoxLayout(self)
        lay.addWidget(entete("Validation",
                             "Contrôles de cohérence des données et des modèles, performance des sources et "
                             "validation croisée « une source exclue »."))
        barre = QHBoxLayout()
        barre.addWidget(bouton("Lancer la validation", self.lancer))
        self.compteurs = {}
        for n, lib in validation.LIBELLE_NIVEAU.items():
            l = QLabel()
            l.setObjectName("pastille")
            l.setStyleSheet(f"background:{COULEURS_NIVEAU[n]};")
            self.compteurs[n] = (l, lib)
            barre.addWidget(l)
        barre.addStretch()
        lay.addLayout(barre)
        self.onglets = QTabWidget()
        lay.addWidget(self.onglets, 1)

        # Contrôles
        sp = QSplitter(Qt.Horizontal)
        self.liste = QTableWidget(0, 3)
        self.liste.setHorizontalHeaderLabels(["Niveau", "Catégorie", "Contrôle"])
        self.liste.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.liste.verticalHeader().setVisible(False)
        self.liste.setSelectionBehavior(QTableWidget.SelectRows)
        self.liste.setEditTriggers(QTableWidget.NoEditTriggers)
        self.liste.itemSelectionChanged.connect(self.detail)
        sp.addWidget(self.liste)
        droite = QWidget()
        dl = QVBoxLayout(droite)
        self.texte = QLabel()
        self.texte.setWordWrap(True)
        self.texte.setTextFormat(Qt.RichText)
        self.texte.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.texte.setAlignment(Qt.AlignTop)
        self.texte.setObjectName("detail")
        dl.addWidget(self.texte)
        self.vue_l, self.mod_l = vue_tableau(decimales=3)
        dl.addWidget(self.vue_l, 1)
        sp.addWidget(droite)
        sp.setSizes([520, 600])
        self.onglets.addTab(sp, "Contrôles de cohérence")

        # Performance
        w = QWidget()
        wl = QVBoxLayout(w)
        wl.addWidget(_label_info("Comparaison de chaque source à Q̄ (présentation habituelle). Q̄ étant construit "
                                 "à partir des sources, cette comparaison n'est pas indépendante."))
        self.vue_p, self.mod_p = vue_tableau(decimales=3, index=True)
        wl.addWidget(self.vue_p)
        wl.addWidget(_label_info("<b>Modèle de référence contre les mesures in situ</b> (comparaison indépendante)"))
        self.vue_r, self.mod_r = vue_tableau(decimales=3, index=True)
        self.vue_r.setMaximumHeight(80)
        wl.addWidget(self.vue_r)
        self.onglets.addTab(w, "Performance par rapport à Q̄")

        # Une source exclue
        w2 = QWidget()
        w2l = QVBoxLayout(w2)
        w2l.addWidget(_label_info("Chaque source est comparée au débit fusionné recalculé <b>sans elle</b> : "
                                  "c'est la mesure de performance indépendante à présenter au jury."))
        self.vue_x, self.mod_x = vue_tableau(decimales=3, index=True)
        self.vue_x.setMaximumHeight(130)
        w2l.addWidget(self.vue_x)
        ligne = QHBoxLayout()
        ligne.addWidget(QLabel("Source :"))
        self.src = QComboBox()
        self.src.currentIndexChanged.connect(self.dessiner_x)
        ligne.addWidget(self.src)
        ligne.addStretch()
        w2l.addLayout(ligne)
        self.graph_x = Graphique()
        w2l.addWidget(self.graph_x, 1)
        self.onglets.addTab(w2, "Validation « une source exclue »")
        self.constats = []
        self.series_x = {}

    def rafraichir(self):
        if not self.constats:
            self.lancer()

    def lancer(self):
        with self.f.attente("Contrôles en cours…"):
            res = self.f.resultat_hps(silencieux=True)
            self.constats = validation.tout_controler(self.projet, res)
            b = validation.bilan(self.constats)
            pluriels = {"erreur": "Erreurs", "attention": "Attention", "info": "Informations", "ok": "Conformes"}
            for n, (l, lib) in self.compteurs.items():
                l.setText(f"  {pluriels[n] if b[n] > 1 else lib} : {b[n]}  ")
            self.liste.setRowCount(0)
            for c in self.constats:
                i = self.liste.rowCount()
                self.liste.insertRow(i)
                for j, v in enumerate((validation.LIBELLE_NIVEAU[c.niveau], c.categorie, c.titre)):
                    it = QTableWidgetItem(v)
                    it.setBackground(QColor(COULEURS_NIVEAU[c.niveau]))
                    self.liste.setItem(i, j, it)
            self.liste.resizeColumnsToContents()
            self.liste.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
            if self.constats:
                self.liste.selectRow(0)
            if res is not None:
                self.mod_p.definir(hps.performance(res))
                self.vue_p.resizeColumnsToContents()
                tab, self.series_x = hps.validation_source_exclue(self.projet)
                self.mod_x.definir(tab)
                self.vue_x.resizeColumnsToContents()
                self.src.blockSignals(True)
                self.src.clear()
                for s in self.series_x:
                    self.src.addItem(SOURCES_COURT[s], s)
                self.src.blockSignals(False)
                self.dessiner_x()
            m = hps.reference_contre_mesures(self.projet)
            self.mod_r.definir(metrics.tableau({self.projet.reference.nom: m}) if m else None)
            self.vue_r.resizeColumnsToContents()

    def detail(self):
        rows = self.liste.selectionModel().selectedRows()
        if not rows:
            return
        c = self.constats[rows[0].row()]
        self.texte.setText(f"<b>{c.categorie} — {c.titre}</b><br><br>{c.detail}")
        self.mod_l.definir(c.lignes)
        self.vue_l.setVisible(c.lignes is not None and not c.lignes.empty)
        self.vue_l.resizeColumnsToContents()

    def dessiner_x(self):
        s = self.src.currentData()
        if s is None or s not in self.series_x:
            self.graph_x.dessiner(plots._vide, "Lancez la validation.")
            return
        d = self.series_x[s]
        self.graph_x.dessiner(plots.comparaison, d["Q_global_sans_source"], d["Q_source"],
                              f"{SOURCES_COURT[s]} contre Q̄ calculé sans {SOURCES_COURT[s]}",
                              f"Q̄ sans {SOURCES_COURT[s]} (m³/s)", f"{SOURCES_COURT[s]} (m³/s)",
                              plots.COULEURS[s])


# ======================================================================= Rapport
class PageRapport(Page):
    titre_nav = "Rapport"

    def __init__(self, fenetre):
        super().__init__(fenetre)
        lay = QVBoxLayout(self)
        lay.addWidget(entete("Rapport de validation",
                             "Document Word reprenant les données, les méthodes (avec équations), les "
                             "figures, les tableaux de performance et l'ensemble des contrôles."))
        g, f = groupe("Rapport Word")
        ligne = QHBoxLayout()
        self.logo = QLineEdit()
        self.logo.setPlaceholderText("Facultatif : logo de l'université ou de l'institution (PNG, JPG)")
        ligne.addWidget(self.logo)
        ligne.addWidget(bouton("Parcourir…", self.choisir_logo, True))
        f.addRow("Logo", ligne)
        f.addRow(bouton("Générer le rapport Word…", self.generer))
        lay.addWidget(g)
        g2, f2 = groupe("Données et résultats")
        f2.addRow(bouton("Exporter tous les résultats (Excel)…", self.exporter_excel, True))
        f2.addRow(_label_info("Un classeur avec : Q̄ et ses composantes, performances, validation "
                              "« une source exclue », contrôles et séries de chaque source."))
        lay.addWidget(g2)
        self.etat = _label_info()
        lay.addWidget(self.etat)
        self.bt_ouvrir = bouton("Ouvrir le dernier fichier", self.ouvrir, True)
        self.bt_ouvrir.setEnabled(False)
        lay.addWidget(self.bt_ouvrir, alignment=Qt.AlignLeft)
        lay.addStretch()
        self.dernier = None

    def choisir_logo(self):
        c, _ = QFileDialog.getOpenFileName(self, "Logo", "", "Images (*.png *.jpg *.jpeg)")
        if c:
            self.logo.setText(c)

    def _nom(self, ext):
        base = (self.projet.chemin.stem if self.projet.chemin else "rapport_hps_hydro")
        dossier = self.projet.chemin.parent if self.projet.chemin else Path.home()
        return str(dossier / f"{base}_validation{ext}")

    def generer(self):
        res = self.f.resultat_hps()
        if res is None:
            return
        chemin, _ = QFileDialog.getSaveFileName(self, "Enregistrer le rapport", self._nom(".docx"), "Word (*.docx)")
        if not chemin:
            return
        if not chemin.lower().endswith(".docx"):
            chemin += ".docx"
        with self.f.attente("Génération du rapport…"):
            try:
                report.generer(self.projet, res, chemin, logo=self.logo.text().strip() or None,
                               resultat_ml=self.f.resultat_ml)
            except PermissionError:
                message(self, "Rapport", "Impossible d'écrire le fichier : est-il ouvert dans Word ?", erreur=True)
                return
            except Exception as exc:
                message(self, "Rapport", str(exc), erreur=True)
                return
        self._fait(chemin)

    def exporter_excel(self):
        res = self.f.resultat_hps()
        if res is None:
            return
        chemin, _ = QFileDialog.getSaveFileName(self, "Exporter", self._nom(".xlsx"), "Excel (*.xlsx)")
        if not chemin:
            return
        if not chemin.lower().endswith(".xlsx"):
            chemin += ".xlsx"
        with self.f.attente("Export…"):
            try:
                constats = validation.tout_controler(self.projet, res)
                loso, _ = hps.validation_source_exclue(self.projet)
                with pd.ExcelWriter(chemin) as xw:
                    res.table.to_excel(xw, sheet_name="Q_global")
                    hps.performance(res).to_excel(xw, sheet_name="Performance")
                    loso.to_excel(xw, sheet_name="Source exclue")
                    pd.DataFrame([{"Niveau": validation.LIBELLE_NIVEAU[c.niveau], "Catégorie": c.categorie,
                                   "Contrôle": c.titre, "Constat": c.detail} for c in constats]
                                 ).to_excel(xw, sheet_name="Contrôles", index=False)
                    for s in SOURCES:
                        if not self.projet.series[s].vide():
                            self.projet.serie(s).to_excel(xw, sheet_name=SOURCES_COURT[s], index=False)
                    if not self.projet.jaugeages.empty:
                        self.projet.jaugeages.to_excel(xw, sheet_name="Jaugeages", index=False)
            except PermissionError:
                message(self, "Export", "Impossible d'écrire le fichier : est-il ouvert dans Excel ?", erreur=True)
                return
        self._fait(chemin)

    def _fait(self, chemin):
        self.dernier = chemin
        self.bt_ouvrir.setEnabled(True)
        self.etat.setText(f"Fichier enregistré : <b>{chemin}</b>")
        self.f.statut(f"Enregistré : {chemin}")

    def ouvrir(self):
        if self.dernier:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.dernier))
