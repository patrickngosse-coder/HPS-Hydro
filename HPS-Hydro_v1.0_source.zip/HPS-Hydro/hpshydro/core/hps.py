"""Modèle HPS-Hydro : fusion hybride à pondération sigmoïdale.

Formulation (mode « H », pondération selon la hauteur d'eau) :

    Q̄(t) = σ(H(t)) · [Q_hist(t) + Q_ML(t) + Q_SWOT(t)] / n_dispo(t)
           + (1 − σ(H(t))) · Q_Thys(t)

    σ(H) = 1 / (1 + exp(−α (H − H₀)))

En étiage (H faible) σ → 0 et Q̄ → Q_Thys (référence physique) ; en crue
(H élevé) σ → 1 et Q̄ → moyenne des sources disponibles.

Formulation (mode « écart », pondération par source) :

    σᵢ(t) = 1 / (1 + exp(−α (Qᵢ(t) − Q_Thys(t))))
    Q̄(t)  = (1/n_dispo) Σᵢ [σᵢ(t) · Qᵢ(t) + (1 − σᵢ(t)) · Q_Thys(t)]

Pour une période où une seule source est disponible, on retrouve
Q̄ = σ · Qᵢ + (1 − σ) · Q_Thys (tableau de calage par période).

L'incertitude ±1σ est l'écart-type des estimations disponibles au pas de temps
(sources et modèle de référence).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.special import expit

from . import metrics
from .projet import Projet, ParametresHPS, SOURCES, SOURCES_COURT


@dataclass
class ResultatHPS:
    table: pd.DataFrame
    parametres: ParametresHPS
    sources_actives: list
    h0_utilise: float | None
    domaine: tuple
    domaine_origine: str
    notes: list = field(default_factory=list)

    @property
    def colonnes_sources(self) -> list:
        return [f"Q_{s}" for s in self.sources_actives]


def domaine_reference(projet: Projet, h_defaut=None) -> tuple[tuple, str]:
    """Domaine de hauteurs (m) où le modèle de référence est considéré valide."""
    ref = projet.reference
    if ref.domaine_defini():
        return (float(ref.h_min), float(ref.h_max)), "renseigné par l'utilisateur"
    if not projet.series["hist"].vide() and projet.serie("hist")["H"].notna().any():
        hh = projet.serie("hist")["H"].dropna()
        origine = "étendue des hauteurs in situ (domaine du modèle non renseigné)"
    elif h_defaut is not None:
        hh = pd.Series(h_defaut).dropna()
        origine = "étendue des hauteurs disponibles (domaine du modèle non renseigné)"
    else:
        return (np.nan, np.nan), "indéterminé"
    if hh.empty:
        return (np.nan, np.nan), "indéterminé"
    return (float(hh.min()), float(hh.max())), origine


def _assembler(projet: Projet, actives: list, priorite: list) -> pd.DataFrame:
    tables = []
    for s in actives:
        df = projet.serie(s)[["date", "H", "Q"]].dropna(subset=["date"]).copy()
        df["date"] = pd.to_datetime(df["date"])
        df = df.groupby("date", as_index=True).mean()
        df.columns = [f"H_{s}", f"Q_{s}"]
        tables.append(df)
    if not tables:
        return pd.DataFrame()
    t = pd.concat(tables, axis=1, join="outer").sort_index()
    h = pd.Series(np.nan, index=t.index)
    ordre = [s for s in priorite if s in actives] + [s for s in actives if s not in priorite]
    origine = pd.Series("", index=t.index, dtype=object)
    for s in ordre:
        manque = h.isna() & t[f"H_{s}"].notna()
        h[manque] = t.loc[manque, f"H_{s}"]
        origine[manque] = SOURCES_COURT[s]
    t["H"] = h
    t["H_origine"] = origine
    return t


def fusionner(projet: Projet, params: ParametresHPS | None = None,
              exclure: str | None = None) -> ResultatHPS:
    p = params or projet.hps
    actives = [s for s in SOURCES
               if p.sources.get(s, True) and not projet.series[s].vide() and s != exclure]
    notes = []
    t = _assembler(projet, actives, p.priorite_h)
    if t.empty:
        raise ValueError("Aucune série de débit disponible pour la fusion.")

    ref = projet.reference
    H = t["H"]
    t["Q_ref"] = ref.predire(H)

    # Domaine de validité du modèle de référence
    dom, origine = domaine_reference(projet, H)
    t["hors_domaine"] = (H < dom[0]) | (H > dom[1])

    cols = [f"Q_{s}" for s in actives]
    Qs = t[cols]
    n = Qs.notna().sum(axis=1)
    t["n_dispo"] = n
    moy = Qs.mean(axis=1)

    h0 = None
    if p.mode == "H":
        h0 = p.h0 if p.h0 is not None else float(H.median())
        sig = pd.Series(expit(p.alpha_h * (H - h0)), index=t.index)
        qg = sig * moy + (1 - sig) * t["Q_ref"]
        qg = qg.where(n > 0, t["Q_ref"])
        t["sigma"] = sig
    elif p.mode == "ecart":
        comps, sigs = [], []
        for c in cols:
            sg = pd.Series(expit(p.alpha_q * (t[c] - t["Q_ref"])), index=t.index)
            sigs.append(sg.where(t[c].notna()))
            comps.append(sg * t[c] + (1 - sg) * t["Q_ref"])
        comp = pd.concat(comps, axis=1)
        comp = comp.where(Qs.notna().to_numpy())
        qg = comp.mean(axis=1).where(n > 0, t["Q_ref"])
        t["sigma"] = pd.concat(sigs, axis=1).mean(axis=1)
    else:
        raise ValueError(f"Mode inconnu : {p.mode}")

    ref_absent = t["Q_ref"].isna()
    if ref_absent.any():
        qg = qg.where(~ref_absent, moy)
        notes.append(f"{int(ref_absent.sum())} pas de temps sans hauteur : Q̄ = moyenne des sources.")
    if p.hors_domaine == "exclure":
        hd = t["hors_domaine"] & (n > 0)
        qg = qg.where(~hd, moy)
        qg = qg.where(~(t["hors_domaine"] & (n == 0)))
        if hd.any():
            notes.append(f"{int(hd.sum())} pas de temps hors du domaine du modèle de référence : "
                         f"Q_ref exclu, Q̄ = moyenne des sources.")
    elif t["hors_domaine"].any():
        notes.append(f"{int(t['hors_domaine'].sum())} pas de temps hors du domaine du modèle de "
                     f"référence ({dom[0]:.2f}–{dom[1]:.2f} m) : Q_ref extrapolé.")

    t["Q_global"] = qg
    est = Qs.copy()
    est["Q_ref"] = t["Q_ref"].where(~(t["hors_domaine"] & (p.hors_domaine == "exclure")))
    t["incertitude"] = est.std(axis=1, ddof=0)
    saisons = projet.saison(t.index).to_numpy().astype(object)
    for s in actives:  # une moyenne annuelle ne représente aucune saison
        if projet.series[s].pas_de_temps() == "annuel":
            saisons[(t["H_origine"] == SOURCES_COURT[s]).to_numpy()] = "Moyenne annuelle"
    t["saison"] = saisons
    t.index.name = "date"

    return ResultatHPS(table=t, parametres=p, sources_actives=actives, h0_utilise=h0,
                       domaine=dom, domaine_origine=origine, notes=notes)


def performance(res: ResultatHPS) -> pd.DataFrame:
    """Performance de chaque source par rapport à Q̄_global (comme dans la recherche).

    Attention : Q̄_global est construit à partir des sources ; cette comparaison
    n'est donc pas indépendante (voir validation_source_exclue).
    """
    t = res.table
    out = {}
    for s in res.sources_actives:
        c = f"Q_{s}"
        m = t[c].notna()
        out[SOURCES_COURT[s]] = metrics.tous(t.loc[m, c], t.loc[m, "Q_global"])
    dans = ~t["hors_domaine"]
    out["Q_ref (dans son domaine)"] = metrics.tous(t.loc[dans, "Q_ref"], t.loc[dans, "Q_global"])
    return metrics.tableau(out)


def validation_source_exclue(projet: Projet, params: ParametresHPS | None = None) -> tuple[pd.DataFrame, dict]:
    """Validation croisée « une source exclue ».

    Pour chaque source i, Q̄ est recalculé sans elle (Q̄₋ᵢ) puis comparé à Qᵢ sur
    ses propres dates : la source n'a pas servi à construire la valeur à laquelle
    on la compare. Retourne le tableau des critères et les séries comparées.
    """
    p = params or projet.hps
    actives = [s for s in SOURCES if p.sources.get(s, True) and not projet.series[s].vide()]
    out, series = {}, {}
    for s in actives:
        obs = projet.serie(s)[["date", "Q"]].dropna().groupby("date")["Q"].mean()
        if obs.empty:
            continue
        try:
            r = fusionner(projet, p, exclure=s)
            sans = r.table["Q_global"].reindex(obs.index)
        except ValueError:  # aucune autre source : seule la référence reste
            sans = pd.Series(np.nan, index=obs.index)
        # Aux dates où aucune autre source n'existe, Q̄ sans la source i = Q_ref
        manque = sans.isna()
        if manque.any():
            hs = projet.serie(s).dropna(subset=["date"]).groupby("date")["H"].mean().reindex(obs.index)
            q_ref = pd.Series(projet.reference.predire(hs), index=obs.index)
            if p.hors_domaine == "exclure":
                dom, _ = domaine_reference(projet, hs)
                q_ref = q_ref.where((hs >= dom[0]) & (hs <= dom[1]))
            sans = sans.where(~manque, q_ref)
        out[SOURCES_COURT[s]] = metrics.tous(sans, obs)
        series[s] = pd.DataFrame({"Q_source": obs, "Q_global_sans_source": sans})
    return metrics.tableau(out), series


def reference_contre_mesures(projet: Projet) -> dict | None:
    """Confronte le modèle de référence aux débits mesurés in situ (comparaison indépendante)."""
    if projet.series["hist"].vide():
        return None
    d = projet.serie("hist").dropna(subset=["H", "Q"])
    if len(d) < 3:
        return None
    return metrics.tous(projet.reference.predire(d["H"]), d["Q"])


def saisonnalite(res: ResultatHPS, fraction: float = 0.15) -> pd.DataFrame | None:
    """Moyenne par jour de l'année de Q̄ (séries infra-annuelles uniquement) + lissage LOESS."""
    from .lowess import lowess
    t = res.table.copy()
    if len(t) < 3:
        return None
    pas = pd.Series(t.index).diff().dt.days
    t["pas"] = pas.bfill().to_numpy()
    t = t[t["pas"] <= 45]
    if len(t) < 12:
        return None
    journalier = (t["pas"] <= 2).mean() > 0.5
    if journalier:
        t["jour"] = t.index.dayofyear
    else:  # données mensuelles : regroupement par mois, placé au milieu du mois
        t["jour"] = np.round(15 + 30.44 * (t.index.month - 1)).astype(int)
        fraction = max(fraction, 0.4)
    g = t.groupby("jour").agg(Q=("Q_global", "mean"), sd=("Q_global", "std"),
                              n=("Q_global", "count"))
    g["sd"] = g["sd"].fillna(0)
    g["Q_lisse"] = lowess(g.index.to_numpy(float), g["Q"].to_numpy(float), fraction=max(fraction, 3 / len(g)))
    g.attrs["regroupement"] = "jour de l'année" if journalier else "mois"
    return g
