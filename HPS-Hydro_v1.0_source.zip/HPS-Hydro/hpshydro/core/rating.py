"""Courbes de tarage H-Q : ajustement et modèle de référence.

Formes disponibles :
- puissance  : Q = a (H - H0)^b      (forme classique d'une section de contrôle)
- puissance0 : Q = a H^b             (H0 = 0, utilisée pour le tarage SWOT)
- polynome2  : Q = a0 + a1 H + a2 H² (forme du modèle de Thys)
- lineaire   : Q = a0 + a1 H
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import curve_fit

from . import metrics

FORMES = {
    "puissance": "Puissance Q = a·(H − H₀)^b",
    "puissance0": "Puissance Q = a·H^b",
    "polynome2": "Polynôme Q = a₀ + a₁·H + a₂·H²",
    "lineaire": "Linéaire Q = a₀ + a₁·H",
}


@dataclass
class Ajustement:
    forme: str
    params: dict
    criteres: dict = field(default_factory=dict)
    h_min: float = float("nan")
    h_max: float = float("nan")

    def predire(self, h) -> np.ndarray:
        h = np.asarray(h, dtype=float)
        p = self.params
        if self.forme == "puissance":
            base = np.clip(h - p["H0"], 0, None)
            return p["a"] * base ** p["b"]
        if self.forme == "puissance0":
            return p["a"] * np.clip(h, 0, None) ** p["b"]
        if self.forme == "polynome2":
            return p["a0"] + p["a1"] * h + p["a2"] * h ** 2
        if self.forme == "lineaire":
            return p["a0"] + p["a1"] * h
        raise ValueError(self.forme)

    def formule(self, decimales: int = 3) -> str:
        p, d = self.params, decimales
        if self.forme == "puissance":
            return f"Q = {p['a']:.{d}f} · (H − {p['H0']:.{d}f})^{p['b']:.{d}f}"
        if self.forme == "puissance0":
            return f"Q = {p['a']:.{d}f} · H^{p['b']:.{d}f}"
        if self.forme == "polynome2":
            return (f"Q = {p['a0']:.{d}f} {_signe(p['a1'])} {abs(p['a1']):.{d}f}·H "
                    f"{_signe(p['a2'])} {abs(p['a2']):.{d}f}·H²")
        if self.forme == "lineaire":
            return f"Q = {p['a0']:.{d}f} {_signe(p['a1'])} {abs(p['a1']):.{d}f}·H"
        return self.forme


def _signe(x: float) -> str:
    return "−" if x < 0 else "+"


def ajuster(h, q, forme: str = "puissance") -> Ajustement:
    """Ajuste une courbe de tarage par moindres carrés."""
    h = np.asarray(h, dtype=float)
    q = np.asarray(q, dtype=float)
    ok = np.isfinite(h) & np.isfinite(q)
    h, q = h[ok], q[ok]
    if len(h) < 3:
        raise ValueError("Au moins 3 couples (H, Q) sont nécessaires pour ajuster une courbe.")

    if forme in ("polynome2", "lineaire"):
        deg = 2 if forme == "polynome2" else 1
        c = np.polyfit(h, q, deg)[::-1]
        params = {"a0": float(c[0]), "a1": float(c[1])}
        if deg == 2:
            params["a2"] = float(c[2])
    elif forme == "puissance0":
        pos = (h > 0) & (q > 0)
        if pos.sum() < 3:
            raise ValueError("La forme puissance exige des H et Q strictement positifs.")
        b, ln_a = np.polyfit(np.log(h[pos]), np.log(q[pos]), 1)
        p0 = [float(np.exp(ln_a)), float(b)]
        try:
            popt, _ = curve_fit(lambda x, a, b: a * np.clip(x, 0, None) ** b, h, q, p0=p0, maxfev=20000)
        except RuntimeError:
            popt = p0
        params = {"a": float(popt[0]), "b": float(popt[1])}
    elif forme == "puissance":
        h0_init = float(h.min() - 0.1 * (h.max() - h.min()) - 1e-3)
        base = np.clip(h - h0_init, 1e-6, None)
        pos = q > 0
        b0, ln_a0 = np.polyfit(np.log(base[pos]), np.log(q[pos]), 1)

        def f(x, a, b, h0):
            return a * np.clip(x - h0, 0, None) ** b

        try:
            popt, _ = curve_fit(
                f, h, q, p0=[float(np.exp(ln_a0)), float(b0), h0_init],
                bounds=([0, 0.1, -np.inf], [np.inf, 10.0, float(h.min()) - 1e-6]),
                maxfev=50000,
            )
        except (RuntimeError, ValueError):
            popt = [float(np.exp(ln_a0)), float(b0), h0_init]
        params = {"a": float(popt[0]), "b": float(popt[1]), "H0": float(popt[2])}
    else:
        raise ValueError(f"Forme inconnue : {forme}")

    aj = Ajustement(forme=forme, params=params, h_min=float(h.min()), h_max=float(h.max()))
    aj.criteres = metrics.tous(aj.predire(h), q)
    return aj


@dataclass
class ModeleReference:
    """Modèle empirique de référence (par défaut : modèle de Thys, polynôme d'ordre 2)."""

    nom: str = "Modèle de Thys"
    a0: float = 94.510
    a1: float = -78.571
    a2: float = 15.624
    h_min: float | None = None
    h_max: float | None = None
    description: str = "R. Thys — modèle obtenu après 19 jaugeages (1910-1911)"

    def predire(self, h) -> np.ndarray:
        h = np.asarray(h, dtype=float)
        return self.a0 + self.a1 * h + self.a2 * h ** 2

    def formule(self) -> str:
        return (f"Q = {self.a0:.3f} {_signe(self.a1)} {abs(self.a1):.3f}·H "
                f"{_signe(self.a2)} {abs(self.a2):.3f}·H²")

    def domaine_defini(self) -> bool:
        return self.h_min is not None and self.h_max is not None

    def analyse(self) -> dict:
        """Propriétés physiques du polynôme : monotonie et zones de débit négatif."""
        res = {"h_sommet": None, "q_sommet": None, "racines": []}
        if self.a2 != 0:
            hs = -self.a1 / (2 * self.a2)
            res["h_sommet"] = float(hs)
            res["q_sommet"] = float(self.predire(hs))
            disc = self.a1 ** 2 - 4 * self.a2 * self.a0
            if disc >= 0:
                r1 = (-self.a1 - np.sqrt(disc)) / (2 * self.a2)
                r2 = (-self.a1 + np.sqrt(disc)) / (2 * self.a2)
                res["racines"] = sorted([float(r1), float(r2)])
        return res

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in ("nom", "a0", "a1", "a2", "h_min", "h_max", "description")}

    @classmethod
    def from_dict(cls, d: dict) -> "ModeleReference":
        return cls(**{k: d[k] for k in ("nom", "a0", "a1", "a2", "h_min", "h_max", "description") if k in d})
