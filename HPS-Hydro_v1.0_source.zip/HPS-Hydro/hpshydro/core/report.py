"""Rapport de validation au format Word (.docx)."""

from __future__ import annotations

import tempfile
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from matplotlib.figure import Figure

from .. import __version__
from . import hps, metrics, plots, validation
from .hps import ResultatHPS
from .manning import MODES_PROFONDEUR
from .projet import Projet, SOURCES, SOURCES_COURT

BLEU = RGBColor(0x1F, 0x4E, 0x79)
COUL_NIVEAU = {"erreur": "F4CCCC", "attention": "FCE5CD", "info": "DDEBF7", "ok": "D9EAD3"}

REFERENCES = [
    "Cleveland, W. S. (1979). Robust locally weighted regression and smoothing scatterplots. "
    "Journal of the American Statistical Association, 74(368), 829-836.",
    "Gupta, H. V., Kling, H., Yilmaz, K. K. & Martinez, G. F. (2009). Decomposition of the mean "
    "squared error and NSE performance criteria. Journal of Hydrology, 377(1-2), 80-91.",
    "Manning, R. (1891). On the flow of water in open channels and pipes. Transactions of the "
    "Institution of Civil Engineers of Ireland, 20, 161-207.",
    "Nash, J. E. & Sutcliffe, J. V. (1970). River flow forecasting through conceptual models, "
    "part I. Journal of Hydrology, 10(3), 282-290.",
    "Chen, T. & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings of the "
    "22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, 785-794.",
]


def _fmt(x, d=2):
    if x is None:
        return "—"
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not np.isfinite(xf):
        return "—"
    if abs(xf - round(xf)) < 1e-9 and abs(xf) >= 1:
        return f"{int(round(xf)):,}".replace(",", " ")
    return f"{xf:,.{d}f}".replace(",", " ").replace(".", ",")


def _ombrer(cellule, couleur_hex: str):
    tcPr = cellule._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), couleur_hex)
    tcPr.append(shd)


def _tableau(doc, df: pd.DataFrame, decimales=2, largeur_premiere=None, index=True, taille=8):
    d = df.reset_index() if index else df
    t = doc.add_table(rows=1, cols=len(d.columns))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, c in enumerate(d.columns):
        cel = t.rows[0].cells[j]
        cel.text = "" if (index and j == 0 and str(c) == "index") else str(c)
        _ombrer(cel, "1F4E79")
        for r in cel.paragraphs[0].runs:
            r.font.bold = True
            r.font.size = Pt(taille)
            r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    for _, ligne in d.iterrows():
        cells = t.add_row().cells
        for j, v in enumerate(ligne):
            if isinstance(v, pd.Timestamp):
                txt = v.strftime("%Y-%m-%d")
            elif isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool):
                txt = _fmt(v, decimales)
            else:
                txt = "" if v is None or (isinstance(v, float) and np.isnan(v)) else str(v)
            cells[j].text = txt
            for r in cells[j].paragraphs[0].runs:
                r.font.size = Pt(taille)
    if largeur_premiere:
        for row in t.rows:
            row.cells[0].width = Cm(largeur_premiere)
    doc.add_paragraph()
    return t


def _figure(doc, fn, *args, largeur_cm=16, hauteur=4.6, legende=None, dossier=None):
    f = Figure(figsize=(8.5, hauteur), dpi=150)
    fn(f, *args)
    chemin = Path(dossier) / f"fig_{len(list(Path(dossier).glob('*.png'))):02d}.png"
    f.savefig(chemin, dpi=150)
    doc.add_picture(str(chemin), width=Cm(largeur_cm))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if legende:
        p = doc.add_paragraph(legende)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:
            r.font.size = Pt(8.5)
            r.font.italic = True


def _equation(doc, texte):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(texte)
    r.font.name = "Cambria Math"
    r.font.size = Pt(11)
    return p


def _para(doc, texte, gras=False, italique=False, taille=None):
    p = doc.add_paragraph()
    r = p.add_run(texte)
    r.bold, r.italic = gras, italique
    if taille:
        r.font.size = Pt(taille)
    return p


def generer(projet: Projet, res: ResultatHPS, chemin: str | Path, logo: str | None = None,
            resultat_ml=None) -> Path:
    chemin = Path(chemin)
    constats = validation.tout_controler(projet, res)
    bil = validation.bilan(constats)
    perf = hps.performance(res)
    loso, loso_series = hps.validation_source_exclue(projet)
    t = res.table
    p = res.parametres

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10.5)
    for s in ("Heading 1", "Heading 2", "Title"):
        doc.styles[s].font.color.rgb = BLEU
        doc.styles[s].font.name = "Calibri"
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.2)
    sec.top_margin = sec.bottom_margin = Cm(2.0)

    # ---------------------------------------------------------- page de garde
    if logo and Path(logo).exists():
        doc.add_picture(logo, width=Cm(3.2))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if projet.institution:
        x = _para(doc, projet.institution, gras=True, taille=12)
        x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for _ in range(3):
        doc.add_paragraph()
    titre = doc.add_paragraph(style="Title")
    titre.add_run("Rapport de validation hydrologique")
    titre.alignment = WD_ALIGN_PARAGRAPH.CENTER
    x = _para(doc, projet.titre, taille=14)
    x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    x = _para(doc, "Calage multi-source de la courbe de tarage par le modèle HPS-Hydro "
                   "(Hybride à Pondération Sigmoïdale)", italique=True, taille=11)
    x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for _ in range(6):
        doc.add_paragraph()
    for ligne in ([f"Auteur : {projet.auteur}"] if projet.auteur else []) + [
            f"Date du rapport : {date.today():%d/%m/%Y}",
            f"Généré par HPS-Hydro {__version__}"]:
        x = _para(doc, ligne, taille=10)
        x.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_page_break()

    with tempfile.TemporaryDirectory() as dossier:
        # ------------------------------------------------------------ synthèse
        doc.add_heading("1. Synthèse", level=1)
        qg = t["Q_global"].dropna()
        _para(doc, (f"Le débit fusionné Q̄ couvre la période {t.index.min():%Y} – {t.index.max():%Y} "
                    f"({len(qg)} pas de temps) à partir de {len(res.sources_actives)} source(s) : "
                    f"{', '.join(SOURCES_COURT[s] for s in res.sources_actives)}, pondérées avec "
                    f"{projet.reference.nom}. Débit moyen Q̄ = {_fmt(qg.mean())} m³/s "
                    f"(min {_fmt(qg.min())} ; max {_fmt(qg.max())} m³/s)."))
        _para(doc, (f"Contrôles de validation : {bil['erreur']} erreur(s), {bil['attention']} point(s) "
                    f"d'attention, {bil['info']} information(s), {bil['ok']} contrôle(s) conforme(s)."),
              gras=True)
        graves = [c for c in constats if c.niveau in ("erreur", "attention")]
        for c in graves:
            doc.add_paragraph(f"[{validation.LIBELLE_NIVEAU[c.niveau]}] {c.categorie} — {c.titre}",
                              style="List Bullet")
        if projet.notes:
            _para(doc, projet.notes, italique=True, taille=9)

        # ------------------------------------------------------------- bassin
        doc.add_heading("2. Bassin versant et stations", level=1)
        b = projet.bassin
        car = pd.DataFrame({
            "Paramètre": ["Rivière", "Superficie totale", "Longueur du cours d'eau principal",
                          "Pente moyenne", "Altitude minimale", "Altitude maximale", "Exutoire"],
            "Valeur": [b.riviere, f"{_fmt(b.superficie_km2)} km²", f"{_fmt(b.longueur_m)} m",
                       f"{_fmt(b.pente_pct)} %", f"{_fmt(b.alt_min_m)} m", f"{_fmt(b.alt_max_m)} m",
                       f"{_fmt(b.exutoire_lat, 3)} ; {_fmt(b.exutoire_lon, 3)}"],
        })
        _tableau(doc, car, index=False, taille=9)
        if not projet.pays.empty:
            _tableau(doc, projet.pays.rename(columns={"pays": "Pays", "superficie_km2": "Superficie (km²)",
                                                      "pourcentage": "Part du bassin (%)"}),
                     index=False, taille=9)
        if not projet.stations.empty:
            _tableau(doc, projet.stations.rename(columns={"nom": "Station", "latitude": "Latitude",
                                                          "longitude": "Longitude", "nature": "Nature",
                                                          "etat": "État actuel"}), index=False, taille=8)

        # -------------------------------------------------------------- données
        doc.add_heading("3. Données mobilisées", level=1)
        lignes = []
        for s in SOURCES:
            se = projet.series[s]
            if se.vide():
                continue
            q = se.donnees["Q"]
            lignes.append({"Source": SOURCES_COURT[s], "Station": se.station, "Période": se.periode(),
                           "Pas de temps": se.pas_de_temps(), "n": int(q.notna().sum()),
                           "Q min": q.min(), "Q moyen": q.mean(), "Q max": q.max(),
                           "Description": se.description})
        if lignes:
            _tableau(doc, pd.DataFrame(lignes), index=False, taille=8)
        if not projet.jaugeages.empty:
            g = projet.jaugeages.groupby("station").agg(n=("Q", "count"), Q_min=("Q", "min"),
                                                       Q_max=("Q", "max"), niveau_min=("niveau", "min"),
                                                       niveau_max=("niveau", "max"))
            _para(doc, "Jaugeages historiques disponibles :", gras=True)
            _tableau(doc, g.rename(columns={"n": "Nombre", "Q_min": "Q min (m³/s)", "Q_max": "Q max (m³/s)",
                                            "niveau_min": "Niveau min (m)", "niveau_max": "Niveau max (m)"}),
                     decimales=3, taille=8)

        # ------------------------------------------------------------- méthodes
        doc.add_heading("4. Méthodes", level=1)
        doc.add_heading("4.1 Débit des stations virtuelles SWOT (Manning)", level=2)
        _equation(doc, "Q = (1/n) · A · R^(2/3) · S^(1/2)")
        m = projet.manning
        _para(doc, (f"A : section mouillée (m²) ; R = A/P : rayon hydraulique (m) ; S : pente de la ligne "
                    f"d'eau ; n : coefficient de Manning. Paramètres du projet : n = {m.n}, pente exprimée en "
                    f"{m.unite_pente}, {MODES_PROFONDEUR[m.mode_profondeur]}, section {m.section}. "
                    f"Débit retenu pour la fusion : "
                    f"{'débit importé' if m.utiliser == 'fourni' else 'débit recalculé par le logiciel'}."))
        doc.add_heading("4.2 Modèle de référence", level=2)
        _equation(doc, projet.reference.formule())
        _para(doc, projet.reference.description)
        doc.add_heading("4.3 Reconstitution par apprentissage automatique", level=2)
        if resultat_ml is not None:
            _para(doc, (f"Moteur : {resultat_ml.moteur}. Variables explicatives : "
                        f"{', '.join(resultat_ml.variables)}. {resultat_ml.n_entrainement} observations "
                        f"d'entraînement. Validation croisée par blocs chronologiques et validation sur la "
                        f"dernière période."))
            _tableau(doc, resultat_ml.resume(), decimales=3, taille=7.5)
            _para(doc, resultat_ml.message, italique=True, taille=9)
        else:
            se = projet.series["ml"]
            _para(doc, f"Série Q_ML importée : {se.description or 'sans description'}.")
        doc.add_heading("4.4 Fusion HPS-Hydro", level=2)
        if p.mode == "H":
            _equation(doc, "Q̄(t) = σ(H(t)) · [Q_hist(t) + Q_ML(t) + Q_SWOT(t)] / n_dispo(t) "
                           "+ (1 − σ(H(t))) · Q_ref(t)")
            _equation(doc, "σ(H) = 1 / (1 + exp(−α · (H − H₀)))")
            _para(doc, (f"α = {p.alpha_h:g} m⁻¹ ; H₀ = {_fmt(res.h0_utilise)} m"
                        f"{' (médiane des hauteurs)' if p.h0 is None else ''}. En étiage σ → 0 et Q̄ tend vers "
                        f"le modèle de référence ; en crue σ → 1 et Q̄ tend vers la moyenne des sources."))
        else:
            _equation(doc, "σᵢ(t) = 1 / (1 + exp(−α · (Qᵢ(t) − Q_ref(t))))")
            _equation(doc, "Q̄(t) = (1/n_dispo) · Σᵢ [σᵢ(t) · Qᵢ(t) + (1 − σᵢ(t)) · Q_ref(t)]")
            _para(doc, f"α = {p.alpha_q:g} (m³/s)⁻¹.")
        _para(doc, (f"Domaine de validité du modèle de référence : {_fmt(res.domaine[0])} – "
                    f"{_fmt(res.domaine[1])} m ({res.domaine_origine}). Hors domaine : "
                    f"{'Q_ref extrapolé' if p.hors_domaine == 'extrapoler' else 'Q_ref exclu, Q̄ = moyenne des sources'}. "
                    f"L'incertitude ±1σ est l'écart-type des estimations disponibles à chaque pas de temps."))
        doc.add_heading("4.5 Critères de performance", level=2)
        _para(doc, ("Erreur = estimation − valeur de comparaison. NSE (Nash & Sutcliffe, 1970) : 1 = parfait, "
                    "0 = pas mieux que la moyenne. KGE (Gupta et al., 2009) combine corrélation, rapport des "
                    "variabilités et rapport des moyennes. PBIAS : biais relatif en %."))

        # ------------------------------------------------------------ résultats
        doc.add_heading("5. Résultats", level=1)
        _figure(doc, plots.fusion_hq, res, dossier=dossier,
                legende="Figure 1 — Courbe Q̄_global(H) pondérée et incertitude ±1σ")
        _figure(doc, plots.fusion_temps, res, dossier=dossier,
                legende="Figure 2 — Hydrogramme global Q̄, coloration par saison hydrologique")
        _figure(doc, plots.sigma, res, dossier=dossier, hauteur=3.8,
                legende="Figure 3 — Pondération sigmoïdale appliquée")
        g = hps.saisonnalite(res)
        if g is not None:
            _figure(doc, plots.saisonnalite, g, dossier=dossier,
                    legende="Figure 4 — Saisonnalité de Q̄ et lissage LOESS")
        ps = t.groupby("saison")["Q_global"].agg(["count", "mean", "min", "max"])
        ps.columns = ["Pas de temps", "Q̄ moyen (m³/s)", "Q̄ min (m³/s)", "Q̄ max (m³/s)"]
        _para(doc, "Débit fusionné par saison :", gras=True)
        _tableau(doc, ps, taille=8.5)

        # ----------------------------------------------------------- validation
        doc.add_heading("6. Validation", level=1)
        doc.add_heading("6.1 Performance des sources par rapport à Q̄", level=2)
        _para(doc, ("Ce tableau reprend la présentation habituelle. Q̄ étant construit à partir des sources, "
                    "la comparaison n'est pas indépendante : une corrélation proche de 1 ne démontre pas la "
                    "qualité d'une source."), italique=True, taille=9)
        _tableau(doc, perf, decimales=3, taille=7.5)
        doc.add_heading("6.2 Validation croisée « une source exclue »", level=2)
        _para(doc, ("Chaque source est comparée au débit fusionné recalculé sans elle (aux dates où aucune "
                    "autre source n'existe, ce débit se réduit au modèle de référence). C'est la mesure "
                    "indépendante à présenter."), italique=True, taille=9)
        if not loso.empty:
            _tableau(doc, loso, decimales=3, taille=7.5)
        ref_m = hps.reference_contre_mesures(projet)
        if ref_m:
            doc.add_heading("6.3 Modèle de référence contre les mesures in situ", level=2)
            _tableau(doc, metrics.tableau({projet.reference.nom: ref_m}), decimales=3, taille=7.5)
        doc.add_heading("6.4 Contrôles de cohérence", level=2)
        tab = pd.DataFrame([{"Niveau": validation.LIBELLE_NIVEAU[c.niveau], "Catégorie": c.categorie,
                             "Contrôle": c.titre, "Constat": c.detail} for c in constats])
        tt = _tableau(doc, tab, index=False, taille=7.5)
        for i, c in enumerate(constats, start=1):
            _ombrer(tt.rows[i].cells[0], COUL_NIVEAU[c.niveau])
        detailles = [c for c in constats if c.lignes is not None and not c.lignes.empty
                     and c.niveau in ("erreur", "attention")]
        if detailles:
            doc.add_heading("6.5 Lignes concernées", level=2)
            for c in detailles:
                _para(doc, f"{c.categorie} — {c.titre}", gras=True, taille=9.5)
                _tableau(doc, c.lignes.head(30), index=False, decimales=3, taille=7.5)

        # ----------------------------------------------------------- références
        doc.add_heading("7. Références des méthodes", level=1)
        for r in REFERENCES:
            doc.add_paragraph(r, style="List Bullet")

    doc.save(chemin)
    return chemin
