"""Débit des stations virtuelles SWOT par l'équation de Manning.

    Q = (1/n) · A · R^(2/3) · S^(1/2)

avec A la section mouillée (m²), R = A / P le rayon hydraulique (m),
P le périmètre mouillé (m), S la pente de la ligne d'eau (m/m) et n le
coefficient de rugosité de Manning.

La section est approchée par un rectangle de largeur W (largeur SWOT) et de
profondeur y. La profondeur y peut être obtenue de trois façons :
- "H"            : y = H (hauteur fournie)
- "niveau-zf"    : y = Niveau − Z_fond (cote du fond à renseigner)
- "surface"      : y = (Surface du tronçon / Longueur du tronçon) / W
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd

UNITES_PENTE = {"fraction": 1.0, "pourcent": 0.01, "m/km": 0.001, "cm/km": 1e-5}
MODES_PROFONDEUR = {
    "H": "Profondeur = H",
    "niveau-zf": "Profondeur = Niveau − cote du fond",
    "surface": "Profondeur = Surface / (Longueur × Largeur)",
}


@dataclass
class ParametresManning:
    n: float = 0.035
    unite_pente: str = "fraction"
    mode_profondeur: str = "H"
    z_fond: float = 0.0
    longueur_troncon: float = 10000.0
    section: str = "rectangulaire"  # ou "large" (R ≈ y)
    utiliser: str = "fourni"  # "fourni" : garder Q importé ; "calcule" : Q de Manning

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ParametresManning":
        champs = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in champs})


def profondeur(df: pd.DataFrame, p: ParametresManning) -> pd.Series:
    if p.mode_profondeur == "H":
        y = df["H"]
    elif p.mode_profondeur == "niveau-zf":
        y = df["niveau"] - p.z_fond
    elif p.mode_profondeur == "surface":
        y = (df["surface"] / p.longueur_troncon) / df["largeur"]
    else:
        raise ValueError(p.mode_profondeur)
    return y.astype(float)


def debit(df: pd.DataFrame, p: ParametresManning) -> pd.Series:
    """Calcule Q de Manning ligne par ligne (NaN si une grandeur manque ou est ≤ 0)."""
    for col in ("largeur", "pente"):
        if col not in df.columns:
            raise ValueError(f"Colonne « {col} » absente : impossible d'appliquer Manning.")
    w = df["largeur"].astype(float)
    s = df["pente"].astype(float) * UNITES_PENTE[p.unite_pente]
    y = profondeur(df, p)
    a = w * y
    if p.section == "large":
        r = y
    else:
        r = a / (w + 2 * y)
    q = (1.0 / p.n) * a * np.power(r.clip(lower=0), 2.0 / 3.0) * np.sqrt(s.clip(lower=0))
    invalide = (w <= 0) | (y <= 0) | (s <= 0) | w.isna() | y.isna() | s.isna()
    return q.where(~invalide)


def elasticites(df: pd.DataFrame) -> dict | None:
    """Régression log Q = c + e_W log W + e_S log S + e_D log D (D : surface ou H).

    Avec Manning (section large), on attend e_S ≈ 0,5. Retourne les élasticités
    estimées et l'intervalle de confiance à 95 % de e_S.
    """
    cols = ["Q", "largeur", "pente"]
    proxy = "surface" if "surface" in df.columns and df["surface"].notna().sum() > 0 else "H"
    cols.append(proxy)
    if not all(c in df.columns for c in cols):
        return None
    d = df[cols].astype(float)
    d = d[(d > 0).all(axis=1)].dropna()
    if len(d) < 8:
        return None
    y = np.log(d["Q"].to_numpy())
    X = np.column_stack([np.ones(len(d))] + [np.log(d[c].to_numpy()) for c in cols[1:]])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    dof = len(d) - X.shape[1]
    if dof <= 0:
        return None
    s2 = resid @ resid / dof
    cov = s2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    from scipy import stats
    t = stats.t.ppf(0.975, dof)
    return {
        "n": len(d),
        "proxy": proxy,
        "e_largeur": float(beta[1]),
        "e_pente": float(beta[2]),
        "e_pente_ic": (float(beta[2] - t * se[2]), float(beta[2] + t * se[2])),
        "e_proxy": float(beta[3]),
    }
