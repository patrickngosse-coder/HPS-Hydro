"""Lissage LOWESS (régression locale linéaire pondérée, noyau tricube).

Cleveland, W. S. (1979). Robust locally weighted regression and smoothing
scatterplots. Journal of the American Statistical Association, 74(368), 829-836.
"""

from __future__ import annotations

import numpy as np


def lowess(x, y, fraction: float = 0.2, iterations: int = 2) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(x)
    if n < 3:
        return y.copy()
    k = int(np.clip(np.ceil(fraction * n), 3, n))
    ordre = np.argsort(x)
    xs, ys = x[ordre], y[ordre]
    robustesse = np.ones(n)
    lisse = np.zeros(n)
    for _ in range(iterations + 1):
        for i in range(n):
            d = np.abs(xs - xs[i])
            h = np.partition(d, k - 1)[k - 1]
            h = h if h > 0 else 1e-12
            w = np.clip(1 - (d / h) ** 3, 0, None) ** 3 * robustesse
            sw = w.sum()
            if sw <= 0:
                lisse[i] = ys[i]
                continue
            mx, my = (w * xs).sum() / sw, (w * ys).sum() / sw
            vx = (w * (xs - mx) ** 2).sum()
            pente = (w * (xs - mx) * (ys - my)).sum() / vx if vx > 0 else 0.0
            lisse[i] = my + pente * (xs[i] - mx)
        res = ys - lisse
        s = np.median(np.abs(res))
        if s == 0:
            break
        u = np.clip(res / (6 * s), -1, 1)
        robustesse = (1 - u ** 2) ** 2
    out = np.empty(n)
    out[ordre] = lisse
    return out
