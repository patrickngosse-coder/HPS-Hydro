"""Critères de performance utilisés en hydrologie.

Références :
- Nash, J. E. & Sutcliffe, J. V. (1970). River flow forecasting through
  conceptual models. Journal of Hydrology, 10(3), 282-290.
- Gupta, H. V., Kling, H., Yilmaz, K. K. & Martinez, G. F. (2009).
  Decomposition of the mean squared error and NSE performance criteria.
  Journal of Hydrology, 377(1-2), 80-91.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# Libellés français des critères, dans l'ordre d'affichage
LIBELLES = {
    "n": "Nombre de couples",
    "biais": "Erreur moyenne (m³/s)",
    "mae": "Erreur absolue moyenne (m³/s)",
    "sd_err": "Écart-type des erreurs (m³/s)",
    "rmse": "RMSE (m³/s)",
    "r": "Corrélation r",
    "r2": "R²",
    "nse": "NSE",
    "kge": "KGE",
    "pbias": "PBIAS (%)",
}


def _paires(sim, obs):
    sim = np.asarray(sim, dtype=float)
    obs = np.asarray(obs, dtype=float)
    ok = np.isfinite(sim) & np.isfinite(obs)
    return sim[ok], obs[ok]


def nse(sim, obs) -> float:
    s, o = _paires(sim, obs)
    if len(o) < 2:
        return float("nan")
    den = np.sum((o - o.mean()) ** 2)
    if den == 0:
        return float("nan")
    return float(1.0 - np.sum((s - o) ** 2) / den)


def kge(sim, obs) -> float:
    s, o = _paires(sim, obs)
    if len(o) < 2 or o.std() == 0 or o.mean() == 0:
        return float("nan")
    r = np.corrcoef(s, o)[0, 1] if s.std() > 0 else 0.0
    alpha = s.std() / o.std()
    beta = s.mean() / o.mean()
    return float(1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def rmse(sim, obs) -> float:
    s, o = _paires(sim, obs)
    if len(o) == 0:
        return float("nan")
    return float(np.sqrt(np.mean((s - o) ** 2)))


def pbias(sim, obs) -> float:
    s, o = _paires(sim, obs)
    if len(o) == 0 or o.sum() == 0:
        return float("nan")
    return float(100.0 * np.sum(s - o) / np.sum(o))


def correlation(sim, obs) -> float:
    s, o = _paires(sim, obs)
    if len(o) < 2 or s.std() == 0 or o.std() == 0:
        return float("nan")
    return float(np.corrcoef(s, o)[0, 1])


def r2_determination(sim, obs) -> float:
    """R² au sens du coefficient de détermination (1 - SSres/SStot)."""
    return nse(sim, obs)


def tous(sim, obs) -> dict:
    """Calcule l'ensemble des critères ; l'erreur est définie comme sim - obs."""
    s, o = _paires(sim, obs)
    n = len(o)
    if n == 0:
        return {k: float("nan") for k in LIBELLES} | {"n": 0}
    e = s - o
    return {
        "n": n,
        "biais": float(e.mean()),
        "mae": float(np.abs(e).mean()),
        "sd_err": float(e.std(ddof=1)) if n > 1 else float("nan"),
        "rmse": rmse(s, o),
        "r": correlation(s, o),
        "r2": r2_determination(s, o),
        "nse": nse(s, o),
        "kge": kge(s, o),
        "pbias": pbias(s, o),
    }


def tableau(resultats: dict[str, dict]) -> pd.DataFrame:
    """Met en forme un dictionnaire {nom: tous(...)} en tableau lisible."""
    df = pd.DataFrame(resultats).T
    cols = [c for c in LIBELLES if c in df.columns]
    df = df[cols].rename(columns=LIBELLES)
    return df
