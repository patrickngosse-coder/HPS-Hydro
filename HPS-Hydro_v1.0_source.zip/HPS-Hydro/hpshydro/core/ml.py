"""Reconstitution des débits par apprentissage automatique (Q_ML).

Le modèle (XGBoost, ou à défaut le Gradient Boosting de scikit-learn) apprend
la relation entre les variables explicatives (niveau, hauteur, mois…) et le
débit mesuré sur la période de référence, puis prédit le débit sur la période
sans mesures de débit.

La validation distingue :
- l'ajustement (calculé sur les données d'entraînement : toujours optimiste) ;
- la validation croisée par blocs chronologiques (hors échantillon) ;
- la validation sur la dernière période (split temporel).
Seules les deux dernières mesurent la capacité de prédiction réelle.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field

import numpy as np
import pandas as pd

from . import metrics

VARIABLES = {
    "niveau": "Niveau (m)",
    "H": "Hauteur H (m)",
    "mois": "Mois (1-12)",
    "jour_annee": "Jour de l'année",
}


def moteur_disponible() -> str:
    try:
        import xgboost  # noqa: F401
        return "XGBoost"
    except Exception:
        return "Gradient Boosting (scikit-learn)"


@dataclass
class ParametresML:
    variables: list = field(default_factory=lambda: ["niveau", "H"])
    n_estimators: int = 300
    max_depth: int = 3
    learning_rate: float = 0.05
    n_blocs: int = 5
    part_test: float = 0.25
    graine: int = 42

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ParametresML":
        champs = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in champs})


def preparer(df: pd.DataFrame, variables: list) -> pd.DataFrame:
    X = pd.DataFrame(index=df.index)
    for v in variables:
        if v == "mois":
            X[v] = pd.to_datetime(df["date"]).dt.month
        elif v == "jour_annee":
            X[v] = pd.to_datetime(df["date"]).dt.dayofyear
        else:
            X[v] = df[v].astype(float)
    return X


def _nouveau_modele(p: ParametresML):
    try:
        from xgboost import XGBRegressor
        return XGBRegressor(n_estimators=p.n_estimators, max_depth=p.max_depth,
                            learning_rate=p.learning_rate, random_state=p.graine,
                            n_jobs=1, verbosity=0)
    except Exception:
        from sklearn.ensemble import GradientBoostingRegressor
        return GradientBoostingRegressor(n_estimators=p.n_estimators, max_depth=p.max_depth,
                                         learning_rate=p.learning_rate, random_state=p.graine)


@dataclass
class ResultatML:
    moteur: str
    variables: list
    n_entrainement: int
    ajustement: dict
    validation_croisee: dict
    validation_temporelle: dict
    importance: dict
    oof: pd.DataFrame
    sur_apprentissage: bool
    message: str
    modele: object = None

    def resume(self) -> pd.DataFrame:
        return metrics.tableau({
            "Ajustement (données d'entraînement)": self.ajustement,
            "Validation croisée par blocs": self.validation_croisee,
            "Validation sur la dernière période": self.validation_temporelle,
        })


def entrainer(train: pd.DataFrame, p: ParametresML) -> ResultatML:
    """Entraîne et valide le modèle sur les données de référence (date, variables, Q)."""
    d = train.dropna(subset=["Q"]).copy()
    d = d.sort_values("date").reset_index(drop=True)
    X = preparer(d, p.variables)
    ok = X.notna().all(axis=1)
    d, X = d[ok].reset_index(drop=True), X[ok].reset_index(drop=True)
    y = d["Q"].astype(float).to_numpy()
    n = len(d)
    if n < 10:
        raise ValueError(f"Seulement {n} observations utilisables : au moins 10 sont nécessaires.")

    # Validation croisée par blocs chronologiques contigus
    k = max(2, min(p.n_blocs, n // 4))
    blocs = np.array_split(np.arange(n), k)
    oof = np.full(n, np.nan)
    for idx in blocs:
        masque = np.ones(n, bool)
        masque[idx] = False
        m = _nouveau_modele(p)
        m.fit(X[masque], y[masque])
        oof[idx] = m.predict(X.iloc[idx])
    vc = metrics.tous(oof, y)

    # Validation temporelle : entraînement sur le début, test sur la fin
    n_test = max(2, int(round(n * p.part_test)))
    m = _nouveau_modele(p)
    m.fit(X.iloc[: n - n_test], y[: n - n_test])
    vt = metrics.tous(m.predict(X.iloc[n - n_test:]), y[n - n_test:])

    # Modèle final sur toutes les données
    modele = _nouveau_modele(p)
    modele.fit(X, y)
    aj = metrics.tous(modele.predict(X), y)

    imp = getattr(modele, "feature_importances_", None)
    importance = {v: float(i) for v, i in zip(p.variables, imp)} if imp is not None else {}

    ecart = (aj["nse"] - vc["nse"]) if np.isfinite(vc["nse"]) else np.inf
    sur = bool(ecart > 0.10 or aj["r"] > 0.9999)
    if sur:
        msg = (f"Sur-apprentissage probable : NSE = {aj['nse']:.3f} sur les données d'entraînement "
               f"contre {vc['nse']:.3f} en validation croisée. Ce sont les scores de validation "
               f"qu'il faut présenter, pas ceux de l'ajustement.")
    else:
        msg = (f"Écart modéré entre ajustement (NSE = {aj['nse']:.3f}) et validation croisée "
               f"(NSE = {vc['nse']:.3f}) : la capacité de prédiction est cohérente.")

    return ResultatML(
        moteur=moteur_disponible(), variables=list(p.variables), n_entrainement=n,
        ajustement=aj, validation_croisee=vc, validation_temporelle=vt,
        importance=importance,
        oof=pd.DataFrame({"date": d["date"], "Q_obs": y, "Q_oof": oof}),
        sur_apprentissage=sur, message=msg, modele=modele,
    )


def predire(res: ResultatML, df: pd.DataFrame, train: pd.DataFrame) -> tuple[pd.Series, int]:
    """Prédit Q sur df ; retourne aussi le nombre de lignes hors du domaine d'entraînement."""
    X = preparer(df, res.variables)
    Xt = preparer(train.dropna(subset=["Q"]), res.variables)
    hors = pd.Series(False, index=df.index)
    for v in res.variables:
        if v in ("mois", "jour_annee"):
            continue
        hors |= (X[v] < Xt[v].min()) | (X[v] > Xt[v].max())
    q = pd.Series(np.nan, index=df.index)
    ok = X.notna().all(axis=1)
    if ok.any():
        q[ok] = res.modele.predict(X[ok])
    return q, int(hors.sum())
