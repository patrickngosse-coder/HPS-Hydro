"""Moteur de calcul de HPS-Hydro (indépendant de l'interface)."""
