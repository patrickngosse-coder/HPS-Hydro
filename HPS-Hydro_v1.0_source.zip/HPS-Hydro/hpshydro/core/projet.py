"""Modèle de données d'un projet HPS-Hydro et enregistrement (.hpsh, JSON)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

from .rating import ModeleReference
from .manning import ParametresManning
from .ml import ParametresML

FORMAT_VERSION = 1

SOURCES = {
    "hist": "Q_hist — mesures in situ",
    "ml": "Q_ML — apprentissage automatique",
    "swot": "Q_SWOT — altimétrie SWOT (Manning)",
}
SOURCES_COURT = {"hist": "Q_hist", "ml": "Q_ML", "swot": "Q_SWOT"}

COLONNES_SERIE = ["date", "niveau", "H", "Q"]
COLONNES_SWOT = ["pente", "largeur", "surface"]

SAISONS_DEFAUT = {
    1: "Petite saison sèche", 2: "Petite saison sèche",
    3: "Saison des pluies", 4: "Saison des pluies", 5: "Saison des pluies",
    6: "Saison sèche", 7: "Saison sèche", 8: "Saison sèche", 9: "Saison sèche",
    10: "Saison des pluies", 11: "Saison des pluies", 12: "Saison des pluies",
}


@dataclass
class Bassin:
    riviere: str = ""
    superficie_km2: float | None = None
    longueur_m: float | None = None
    pente_pct: float | None = None
    alt_min_m: float | None = None
    alt_max_m: float | None = None
    exutoire_lat: float | None = None
    exutoire_lon: float | None = None
    description: str = ""


@dataclass
class ParametresHPS:
    """Paramètres de la fusion HPS-Hydro.

    mode "H"     : σ(H) = 1 / (1 + exp(−α (H − H₀)))       (pondération selon la hauteur)
    mode "ecart" : σᵢ  = 1 / (1 + exp(−α (Qᵢ − Q_ref)))     (pondération selon l'écart)
    """

    mode: str = "H"
    alpha_h: float = 2.0
    h0: float | None = None  # None : médiane des hauteurs disponibles
    alpha_q: float = 0.05
    hors_domaine: str = "extrapoler"  # ou "exclure" (Q_ref ignoré hors domaine)
    sources: dict = field(default_factory=lambda: {"hist": True, "ml": True, "swot": True})
    priorite_h: list = field(default_factory=lambda: ["hist", "ml", "swot"])

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ParametresHPS":
        champs = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in champs})


@dataclass
class Serie:
    source: str
    station: str = ""
    description: str = ""
    donnees: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=COLONNES_SERIE))

    def vide(self) -> bool:
        return self.donnees is None or self.donnees.empty

    def pas_de_temps(self) -> str:
        if self.vide() or len(self.donnees) < 2:
            return "—"
        d = pd.to_datetime(self.donnees["date"]).sort_values().diff().dt.days.median()
        if d <= 1.5:
            return "journalier"
        if d <= 10:
            return "hebdomadaire"
        if d <= 45:
            return "mensuel"
        if d <= 200:
            return "saisonnier"
        return "annuel"

    def periode(self) -> str:
        if self.vide():
            return "—"
        d = pd.to_datetime(self.donnees["date"])
        return f"{d.min():%Y-%m} → {d.max():%Y-%m}"


def dms_vers_decimal(texte: str) -> tuple[float | None, str | None]:
    """Convertit « 5°08'38''S » en degrés décimaux ; signale minutes/secondes ≥ 60."""
    if texte is None:
        return None, None
    t = str(texte).strip().replace("’", "'").replace("''", '"').replace("″", '"').replace("′", "'")
    if t == "" or t.lower() == "nan":
        return None, None
    try:
        return float(t.replace(",", ".")), None
    except ValueError:
        pass
    m = re.match(r"^\s*(-?\d+(?:[.,]\d+)?)\s*°\s*(?:(\d+(?:[.,]\d+)?)\s*')?\s*(?:(\d+(?:[.,]\d+)?)\s*\")?\s*([NSEOW])?\s*$", t, re.I)
    if not m:
        return None, f"format non reconnu : « {texte} »"
    deg = float(m.group(1).replace(",", "."))
    mn = float((m.group(2) or "0").replace(",", "."))
    sc = float((m.group(3) or "0").replace(",", "."))
    alerte = None
    if mn >= 60 or sc >= 60:
        alerte = f"« {texte} » : minutes ou secondes ≥ 60 (coordonnée invalide)"
    val = abs(deg) + mn / 60 + sc / 3600
    h = (m.group(4) or "").upper()
    if h in ("S", "O", "W") or deg < 0:
        val = -val
    return val, alerte


class Projet:
    def __init__(self):
        self.titre = "Nouveau projet"
        self.auteur = ""
        self.institution = ""
        self.date_creation = date.today().isoformat()
        self.bassin = Bassin()
        self.pays = pd.DataFrame(columns=["pays", "superficie_km2", "pourcentage"])
        self.stations = pd.DataFrame(columns=["nom", "latitude", "longitude", "nature", "etat"])
        self.jaugeages = pd.DataFrame(columns=["station", "date", "niveau", "H", "Q", "remarque"])
        self.series = {s: Serie(source=s) for s in SOURCES}
        self.reference = ModeleReference()
        self.hps = ParametresHPS()
        self.manning = ParametresManning()
        self.ml = ParametresML()
        self.saisons = dict(SAISONS_DEFAUT)
        self.notes = ""
        self.chemin: Path | None = None

    # ------------------------------------------------------------------ séries
    def serie(self, source: str) -> pd.DataFrame:
        return self.series[source].donnees

    def definir_serie(self, source: str, df: pd.DataFrame):
        df = df.copy()
        df["date"] = pd.to_datetime(df["date"])
        for c in COLONNES_SERIE:
            if c not in df.columns:
                df[c] = np.nan
        autres = [c for c in df.columns if c not in COLONNES_SERIE]
        df = df[COLONNES_SERIE + autres].sort_values("date").reset_index(drop=True)
        for c in df.columns:
            if c != "date":
                df[c] = pd.to_numeric(df[c], errors="coerce")
        self.series[source].donnees = df

    def saison(self, dates) -> pd.Series:
        d = pd.to_datetime(pd.Series(dates))
        return d.dt.month.map(lambda m: self.saisons.get(int(m), "—"))

    # ------------------------------------------------------------ persistance
    @staticmethod
    def _df_vers_json(df: pd.DataFrame) -> dict:
        d = df.copy()
        for c in d.columns:
            if pd.api.types.is_datetime64_any_dtype(d[c]):
                d[c] = d[c].dt.strftime("%Y-%m-%d")
        d = d.astype(object).where(pd.notna(d), None)
        return {"colonnes": list(d.columns), "lignes": d.values.tolist()}

    @staticmethod
    def _json_vers_df(obj: dict, dates=("date",)) -> pd.DataFrame:
        df = pd.DataFrame(obj.get("lignes", []), columns=obj.get("colonnes", []))
        for c in dates:
            if c in df.columns:
                df[c] = pd.to_datetime(df[c], errors="coerce")
        return df

    def to_dict(self) -> dict:
        return {
            "format": "HPS-Hydro", "version": FORMAT_VERSION,
            "titre": self.titre, "auteur": self.auteur, "institution": self.institution,
            "date_creation": self.date_creation, "notes": self.notes,
            "bassin": asdict(self.bassin),
            "pays": self._df_vers_json(self.pays),
            "stations": self._df_vers_json(self.stations),
            "jaugeages": self._df_vers_json(self.jaugeages),
            "series": {
                s: {"station": v.station, "description": v.description,
                    "donnees": self._df_vers_json(v.donnees)}
                for s, v in self.series.items()
            },
            "reference": self.reference.to_dict(),
            "hps": self.hps.to_dict(),
            "manning": self.manning.to_dict(),
            "ml": self.ml.to_dict(),
            "saisons": {str(k): v for k, v in self.saisons.items()},
        }

    def enregistrer(self, chemin: str | Path):
        chemin = Path(chemin)
        chemin.write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=1), encoding="utf-8")
        self.chemin = chemin

    @classmethod
    def ouvrir(cls, chemin: str | Path) -> "Projet":
        chemin = Path(chemin)
        d = json.loads(chemin.read_text(encoding="utf-8"))
        if d.get("format") != "HPS-Hydro":
            raise ValueError("Ce fichier n'est pas un projet HPS-Hydro.")
        p = cls()
        p.titre = d.get("titre", p.titre)
        p.auteur = d.get("auteur", "")
        p.institution = d.get("institution", "")
        p.date_creation = d.get("date_creation", p.date_creation)
        p.notes = d.get("notes", "")
        p.bassin = Bassin(**{k: v for k, v in d.get("bassin", {}).items() if k in Bassin.__dataclass_fields__})
        p.pays = cls._json_vers_df(d.get("pays", {}), dates=())
        p.stations = cls._json_vers_df(d.get("stations", {}), dates=())
        p.jaugeages = cls._json_vers_df(d.get("jaugeages", {}))
        for s, v in d.get("series", {}).items():
            if s in p.series:
                p.series[s].station = v.get("station", "")
                p.series[s].description = v.get("description", "")
                df = cls._json_vers_df(v.get("donnees", {}))
                if not df.empty:
                    p.definir_serie(s, df)
        p.reference = ModeleReference.from_dict(d.get("reference", {}))
        p.hps = ParametresHPS.from_dict(d.get("hps", {}))
        p.manning = ParametresManning.from_dict(d.get("manning", {}))
        p.ml = ParametresML.from_dict(d.get("ml", {}))
        if "saisons" in d:
            p.saisons = {int(k): v for k, v in d["saisons"].items()}
        p.chemin = chemin
        return p


# ---------------------------------------------------------------------------
# Projet de démonstration : rivière Inkisi (RDC), données de la présentation
# « Élaboration d'une courbe de tarage par calage multi-station à l'aide de la
# relation de Manning et d'Apprentissage Automatique appliqué à la rivière Inkisi »
# ---------------------------------------------------------------------------

_KISANTU = """1950 516.07 6.14 232.85
1951 515.87 5.93 210.40
1952 515.95 6.01 217.09
1953 515.99 6.05 219.98
1954 515.73 5.79 188.42
1955 516.00 6.06 224.56
1956 515.49 5.55 164.55
1957 515.45 5.51 163.66
1958 515.02 5.08 118.63
1959 515.36 5.42 152.44
1960 515.56 5.62 175.18
1961 515.82 5.88 199.71
1962 515.32 5.38 148.23
1963 515.25 5.31 141.67
1964 515.50 5.56 171.82
1965 515.36 5.42 151.64
1966 515.77 5.83 200.50
1967 515.70 5.76 189.28
1968 515.40 5.46 155.46
1969 515.44 5.50 161.13"""

_XGB = """1970 515.54 5.55 181.26
1971 515.53 5.70 182.63
1972 515.57 5.67 187.35
1973 515.63 5.70 193.84
1974 515.63 5.63 191.41
1975 515.65 5.66 193.98
1976 515.58 5.63 184.93
1977 515.59 5.72 189.52
1978 515.54 5.57 181.85
1979 515.55 5.59 180.64
1980 515.58 5.61 186.07
1981 515.63 5.59 193.45
1982 515.67 5.67 195.06
1983 515.65 5.59 195.75
1984 515.60 5.65 187.40
1985 515.54 5.71 182.77
1986 515.56 5.63 183.12
1987 515.57 5.58 183.98
1988 515.68 5.71 197.92
1989 515.56 5.67 184.54
1990 515.63 5.69 189.99
1991 515.62 5.66 190.03
1992 515.66 5.68 193.79
1993 515.61 5.54 189.44
1994 515.58 5.65 187.00
1995 515.67 5.68 198.41
1996 515.70 5.70 199.29
1997 515.56 5.64 182.27
1998 515.62 5.70 189.52
1999 515.58 5.70 185.70
2000 515.69 5.64 201.17
2001 515.58 5.64 185.86
2002 515.62 5.76 190.83
2003 515.58 5.74 187.25
2004 515.53 5.66 181.50
2005 515.62 4.23 188.26
2006 515.67 5.63 195.20
2007 515.58 5.59 185.51
2008 515.60 5.60 187.93
2009 515.62 5.64 189.90
2010 515.61 5.59 189.01
2011 515.66 4.20 194.12
2012 515.57 5.67 184.24
2013 515.64 5.71 194.40
2014 515.59 5.71 187.81
2015 515.59 5.73 186.97
2016 515.52 5.66 181.19
2017 515.49 5.61 177.18
2018 515.57 5.67 185.77
2019 515.63 5.71 191.18
2020 515.63 5.73 192.28
2021 515.63 5.73 193.11
2022 515.65 5.83 194.59"""

_SWOT = """2023 8 496.95 12.05 0.006903 140.4347 1727908 202.80
2023 9 522.45 13.45 0.003803 94.72792 1114974 96.37
2023 10 517.56 8.56 0.004324 101.9875 1329963 123.44
2023 11 521.35 12.35 0.004652 157.471 2020706 219.25
2023 12 528.50 19.50 0.003773 139.8204 1944597 225.19
2024 1 530.42 21.42 0.003107 130.1054 1806473 214.65
2024 2 524.91 15.91 0.003159 151.6986 2027551 241.87
2024 3 525.02 16.02 0.003832 122.9426 1585080 170.83
2024 4 524.76 15.76 0.002221 167.3439 2325603 306.99
2024 5 510.82 1.82 0.006243 174.5173 2317925 286.04
2024 6 528.42 19.42 0.003101 98.23216 1167672 105.48
2024 7 523.72 14.72 0.004012 103.6331 1284566 132.59
2024 8 523.71 14.71 0.002504 109.3481 1358010 135.52
2024 9 518.45 9.45 0.00489 122.4157 1484394 139.22
2024 10 527.78 18.78 0.001852 100.5436 1354413 124.23
2024 11 542.87 33.87 0.003415 86.11376 1237572 115.99
2024 12 534.96 25.96 0.002534 172.1436 2404510 304.08
2025 1 522.18 13.18 0.003061 120.4063 1617352 183.63
2025 2 542.70 33.70 0.002254 148.4841 2135962 255.14
2025 3 539.08 30.08 0.002534 146.0384 2125542 281.70
2025 4 541.62 32.62 0.00267 180.5031 2522778 329.02
2025 5 539.97 30.97 0.002201 85.88274 1241229 109.10"""

_ZONGO2 = [(422.140, 225.7), (422.470, 272.8), (422.023, 209.8), (421.885, 191.5),
           (421.760, 176.6), (421.278, 125.1), (421.395, 137.1), (421.515, 149.5),
           (421.618, 160.7), (421.715, 172.3), (421.810, 184.1), (422.310, 249.3),
           (422.408, 264.0), (421.510, 148.5)]
_SANGA = [(421.950, 961.6), (421.568, 886.9), (421.350, 848.6), (421.478, 875.2),
          (421.535, 882.5), (421.598, 895.0), (421.658, 907.2), (421.723, 918.9),
          (421.798, 930.5), (421.843, 939.4), (421.895, 950.9)]


def _lire(bloc: str, colonnes: list) -> pd.DataFrame:
    lignes = [l.split() for l in bloc.strip().splitlines()]
    return pd.DataFrame(lignes, columns=colonnes).apply(pd.to_numeric)


def projet_demo_inkisi() -> Projet:
    p = Projet()
    p.titre = "Rivière Inkisi (RDC) — courbe de tarage multi-station 1950-2025"
    p.auteur = "Patrick Ngosse"
    p.institution = "Université Pédagogique Nationale (UPN), Département de Physique et Sciences Appliquées"
    p.notes = ("Projet de démonstration construit à partir des tableaux de la présentation des "
               "résultats (valeurs annuelles et mensuelles). Remplacez-les par les séries "
               "journalières complètes pour reproduire les résultats de la recherche.")
    p.bassin = Bassin(
        riviere="Inkisi", superficie_km2=14400, longueur_m=249967, pente_pct=0.40,
        alt_min_m=200, alt_max_m=1200, exutoire_lat=-4.767, exutoire_lon=14.874,
        description="Longueur depuis la frontière angolaise jusqu'à l'exutoire.",
    )
    p.pays = pd.DataFrame({"pays": ["Angola", "République Démocratique du Congo"],
                           "superficie_km2": [8650, 5760], "pourcentage": [60, 40]})
    p.stations = pd.DataFrame({
        "nom": ["Kisantu", "Sanga", "Zongo I", "Zongo II",
                "R_CONGO_INKISI/RDC_KM0490", "R_CONGO_INKISI/RDC_KM0560"],
        "latitude": ["5°08'38\"S", "5°06'00\"S", "4°47'00\"S", "4°46'00\"S", "5°22'01\"S", "5°55'69\"S"],
        "longitude": ["15°05'07\"E", "15°08'00\"E", "14°52'00\"E", "14°51'00\"E", "15°13'14\"E", "15°17'91\"E"],
        "nature": ["Physique", "Physique", "Physique", "Physique", "Virtuelle", "Virtuelle"],
        "etat": ["Hors service", "Hors service", "Vétuste", "Vétuste", "Opérationnelle", "Opérationnelle"],
    })
    jz = pd.DataFrame(_ZONGO2, columns=["niveau", "Q"])
    jz["station"], jz["remarque"] = "Zongo II", "Lab. Recherches Hydrauliques Borgerhout (1950-1951) — niveau amont Pr XII"
    js = pd.DataFrame(_SANGA, columns=["niveau", "Q"])
    js["station"], js["remarque"] = "Sanga", "Lab. Recherches Hydrauliques Borgerhout (1948) — niveau amont Pr XII"
    j = pd.concat([js, jz], ignore_index=True)
    j["date"], j["H"] = pd.NaT, np.nan
    p.jaugeages = j[["station", "date", "niveau", "H", "Q", "remarque"]]

    k = _lire(_KISANTU, ["annee", "niveau", "H", "Q"])
    k["date"] = pd.to_datetime(k["annee"].astype(int).astype(str) + "-07-01")
    p.definir_serie("hist", k[["date", "niveau", "H", "Q"]])
    p.series["hist"].station = "Kisantu"
    p.series["hist"].description = "Moyennes annuelles mesurées par la SNEL (1950-1969)"

    x = _lire(_XGB, ["annee", "niveau", "H", "Q"])
    x["date"] = pd.to_datetime(x["annee"].astype(int).astype(str) + "-07-01")
    x["Q_importe"] = x["Q"]
    p.definir_serie("ml", x[["date", "niveau", "H", "Q", "Q_importe"]])
    p.series["ml"].station = "Kisantu"
    p.series["ml"].description = "Débits prédits par XGBoost (R² = 0,98 ; RMSE = 13,22 m³/s), moyennes annuelles"

    s = _lire(_SWOT, ["annee", "mois", "niveau", "H", "pente", "largeur", "surface", "Q"])
    s["date"] = pd.to_datetime(dict(year=s["annee"].astype(int), month=s["mois"].astype(int), day=15))
    s["Q_importe"] = s["Q"]
    p.definir_serie("swot", s[["date", "niveau", "H", "Q", "pente", "largeur", "surface", "Q_importe"]])
    p.series["swot"].station = "R_CONGO_INKISI/RDC_KM0490"
    p.series["swot"].description = "Stations virtuelles SWOT, débit estimé par la formule de Manning (2023-2025)"

    p.reference = ModeleReference()
    return p
