"""Contrôles de validation : cohérence des données, des modèles et de la fusion.

Chaque contrôle produit un Constat (niveau, catégorie, titre, détail, lignes
concernées). Les niveaux : « erreur » (résultat faussé), « attention »
(à justifier devant un jury), « info » (à connaître), « ok » (contrôle passé).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import metrics, manning
from .hps import ResultatHPS, performance, reference_contre_mesures, domaine_reference
from .projet import Projet, SOURCES, SOURCES_COURT, dms_vers_decimal

NIVEAUX = {"erreur": 0, "attention": 1, "info": 2, "ok": 3}
LIBELLE_NIVEAU = {"erreur": "Erreur", "attention": "Attention", "info": "Information", "ok": "Conforme"}


@dataclass
class Constat:
    niveau: str
    categorie: str
    titre: str
    detail: str = ""
    lignes: pd.DataFrame | None = field(default=None, repr=False)


@dataclass
class Seuils:
    tolerance_zero_m: float = 0.25        # écart toléré sur Niveau − H (m)
    saut_niveau_m: float = 3.0            # variation plausible entre deux observations (m)
    z_robuste: float = 3.5                # seuil du score z robuste (MAD)
    ecart_superficie_pct: float = 0.5


def _fmt(x, d=2):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "—"
    return f"{x:,.{d}f}".replace(",", " ").replace(".", ",")


# --------------------------------------------------------------------- bassin
def controle_bassin(p: Projet, s: Seuils) -> list[Constat]:
    out = []
    b = p.bassin
    if b.superficie_km2 and not p.pays.empty:
        somme = pd.to_numeric(p.pays["superficie_km2"], errors="coerce").sum()
        ecart = 100 * (somme - b.superficie_km2) / b.superficie_km2
        if abs(ecart) > s.ecart_superficie_pct:
            out.append(Constat("attention", "Bassin versant", "Superficies incohérentes",
                               f"La somme des superficies par pays ({_fmt(somme, 0)} km²) diffère de la "
                               f"superficie totale ({_fmt(b.superficie_km2, 0)} km²) de {_fmt(ecart)} %."))
        elif somme != b.superficie_km2:
            out.append(Constat("info", "Bassin versant", "Léger écart de superficie",
                               f"Somme par pays : {_fmt(somme, 0)} km² ; superficie totale : "
                               f"{_fmt(b.superficie_km2, 0)} km² (écart {_fmt(ecart)} %, "
                               f"sous le seuil de {_fmt(s.ecart_superficie_pct, 1)} %). "
                               f"À harmoniser dans le texte."))
        else:
            out.append(Constat("ok", "Bassin versant", "Superficies cohérentes"))
    if b.alt_max_m is not None and b.alt_min_m is not None and b.longueur_m and b.pente_pct is not None:
        pente = 100 * (b.alt_max_m - b.alt_min_m) / b.longueur_m
        if abs(pente - b.pente_pct) > 0.05:
            out.append(Constat("attention", "Bassin versant", "Pente moyenne à vérifier",
                               f"(Alt. max − Alt. min) / Longueur = {_fmt(pente, 3)} % "
                               f"contre {_fmt(b.pente_pct, 3)} % déclarés."))
        else:
            out.append(Constat("ok", "Bassin versant", "Pente moyenne cohérente",
                               f"(Alt. max − Alt. min) / Longueur = {_fmt(pente, 3)} %."))
    return out


def controle_stations(p: Projet) -> list[Constat]:
    out, mauvaises = [], []
    for _, r in p.stations.iterrows():
        for axe in ("latitude", "longitude"):
            val, alerte = dms_vers_decimal(r.get(axe))
            if alerte:
                mauvaises.append({"station": r.get("nom"), "axe": axe, "valeur": r.get(axe), "problème": alerte})
            elif val is not None:
                lim = 90 if axe == "latitude" else 180
                if abs(val) > lim:
                    mauvaises.append({"station": r.get("nom"), "axe": axe, "valeur": r.get(axe),
                                      "problème": "hors des bornes géographiques"})
    if mauvaises:
        out.append(Constat("erreur", "Stations", f"{len(mauvaises)} coordonnée(s) invalide(s)",
                           "Des minutes ou secondes d'arc dépassent 59 : la position de la station "
                           "ne peut pas être reportée correctement sur une carte.",
                           pd.DataFrame(mauvaises)))
    elif not p.stations.empty:
        out.append(Constat("ok", "Stations", "Coordonnées des stations valides"))
    return out


# --------------------------------------------------------------------- séries
def _zero_echelle(df: pd.DataFrame, src: str, s: Seuils) -> list[Constat]:
    d = df.dropna(subset=["niveau", "H"])
    if len(d) < 3:
        return []
    off = d["niveau"] - d["H"]
    m = off.median()
    ecarts = (off - m).abs() > s.tolerance_zero_m
    if not ecarts.any():
        return [Constat("ok", SOURCES_COURT[src], "Zéro de l'échelle constant",
                        f"Niveau − H = {_fmt(m)} m sur toutes les lignes (± {_fmt(s.tolerance_zero_m)} m).")]
    lignes = d.loc[ecarts, ["date", "niveau", "H"]].copy()
    lignes["Niveau − H"] = off[ecarts]
    inv = (d.loc[ecarts, "niveau"] + d.loc[ecarts, "H"] - m).abs() <= s.tolerance_zero_m
    lignes["H attendu"] = d.loc[ecarts, "niveau"] - m
    out = []
    if inv.any():
        out.append(Constat("erreur", SOURCES_COURT[src], "Hauteur calculée en valeur absolue",
                           f"Pour {int(inv.sum())} ligne(s), H = Z₀ − Niveau avec Z₀ = {_fmt(m)} m : "
                           f"le niveau est sous le zéro de l'échelle mais H a été rendu positif "
                           f"(H = |Niveau − Z₀|). La hauteur réelle est négative ou le zéro est mal choisi.",
                           lignes[inv.to_numpy()]))
    autres = ~inv
    if autres.any():
        out.append(Constat("erreur", SOURCES_COURT[src], "Hauteur incohérente avec le niveau",
                           f"{int(autres.sum())} ligne(s) où Niveau − H s'écarte de plus de "
                           f"{_fmt(s.tolerance_zero_m)} m de la valeur habituelle ({_fmt(m)} m). "
                           f"Erreur de saisie probable : la colonne « H attendu » donne la valeur "
                           f"cohérente avec le niveau.",
                           lignes[autres.to_numpy()]))
    return out


def _sauts(df: pd.DataFrame, src: str, s: Seuils, amplitude_ref: float | None) -> list[Constat]:
    d = df.dropna(subset=["niveau"]).sort_values("date")
    if len(d) < 3:
        return []
    out = []
    saut = d["niveau"].diff().abs()
    gros = saut > s.saut_niveau_m
    amp = d["niveau"].max() - d["niveau"].min()
    if gros.any():
        l = d.loc[gros, ["date", "niveau"]].copy()
        l["variation (m)"] = saut[gros]
        out.append(Constat("attention", SOURCES_COURT[src], "Variations de niveau peu plausibles",
                           f"{int(gros.sum())} variation(s) supérieure(s) à {_fmt(s.saut_niveau_m, 1)} m entre "
                           f"deux observations consécutives ; amplitude totale {_fmt(amp)} m. "
                           f"Vérifier le filtrage qualité (indicateurs de qualité SWOT, nœuds hors chenal, "
                           f"végétation, faible pente).", l))
    if amplitude_ref and amplitude_ref > 0 and src != "hist" and amp > 3 * amplitude_ref:
        out.append(Constat("attention", SOURCES_COURT[src], "Amplitude des niveaux très supérieure aux mesures in situ",
                           f"Amplitude {_fmt(amp)} m contre {_fmt(amplitude_ref)} m pour Q_hist "
                           f"(comparaison indicative si les pas de temps diffèrent)."))
    return out


def _valeurs(df: pd.DataFrame, src: str, s: Seuils) -> list[Constat]:
    out = []
    q = df["Q"]
    neg = q <= 0
    if neg.any():
        out.append(Constat("erreur", SOURCES_COURT[src], "Débits nuls ou négatifs",
                           f"{int(neg.sum())} valeur(s) de Q ≤ 0.", df.loc[neg, ["date", "H", "Q"]]))
    dup = df["date"].duplicated(keep=False)
    if dup.any():
        out.append(Constat("attention", SOURCES_COURT[src], "Dates en double",
                           f"{int(dup.sum())} ligne(s) partagent la même date (elles seront moyennées).",
                           df.loc[dup, ["date", "H", "Q"]]))
    qq = q.dropna()
    if len(qq) >= 8:
        mad = (qq - qq.median()).abs().median()
        if mad > 0:
            z = 0.6745 * (q - qq.median()) / mad
            ab = z.abs() > s.z_robuste
            if ab.any():
                l = df.loc[ab, ["date", "H", "Q"]].copy()
                l["score z robuste"] = z[ab]
                out.append(Constat("info", SOURCES_COURT[src], "Débits atypiques",
                                   f"{int(ab.sum())} valeur(s) avec |z| > {_fmt(s.z_robuste, 1)} "
                                   f"(score robuste fondé sur la médiane).", l))
    return out


def controle_series(p: Projet, s: Seuils) -> list[Constat]:
    out = []
    amp_ref = None
    if not p.series["hist"].vide():
        n = p.serie("hist")["niveau"].dropna()
        amp_ref = float(n.max() - n.min()) if len(n) > 1 else None
    for src in SOURCES:
        if p.series[src].vide():
            continue
        df = p.serie(src)
        out += _valeurs(df, src, s)
        out += _zero_echelle(df, src, s)
        out += _sauts(df, src, s, amp_ref)
    return out


# ----------------------------------------------------------- modèle référence
def controle_reference(p: Projet) -> list[Constat]:
    out = []
    ref = p.reference
    a = ref.analyse()
    toutes_h = pd.concat([p.serie(s)["H"] for s in SOURCES if not p.series[s].vide()]).dropna()
    if ref.a2 > 0 and a["h_sommet"] is not None and a["h_sommet"] > 0:
        detail = (f"{ref.nom} : {ref.formule()}. Le débit décroît quand H augmente pour "
                  f"H < {_fmt(a['h_sommet'])} m (minimum {_fmt(a['q_sommet'])} m³/s), ce qui est "
                  f"physiquement impossible pour une courbe de tarage.")
        niveau = "attention"
        if a["racines"] and a["q_sommet"] < 0:
            r1, r2 = a["racines"]
            detail += f" Le débit est négatif entre H = {_fmt(r1)} m et H = {_fmt(r2)} m."
            dans = ((toutes_h > r1) & (toutes_h < r2)).sum()
            if dans:
                niveau = "erreur"
                detail += f" {int(dans)} hauteur(s) des données tombent dans cette zone."
        dec = (toutes_h < a["h_sommet"]).sum()
        if dec:
            niveau = "erreur"
            detail += f" {int(dec)} hauteur(s) des données sont dans la branche décroissante."
        out.append(Constat(niveau, "Modèle de référence", "Courbe non monotone", detail))
    else:
        out.append(Constat("ok", "Modèle de référence", "Courbe croissante sur le domaine positif"))

    dom, origine = domaine_reference(p, toutes_h)
    if not ref.domaine_defini():
        out.append(Constat("info", "Modèle de référence", "Domaine de validité non renseigné",
                           f"Le logiciel utilise par défaut l'{origine.split(' (')[0]} : "
                           f"{_fmt(dom[0])}–{_fmt(dom[1])} m. Renseignez l'étendue des hauteurs des "
                           f"jaugeages ayant servi à établir {ref.nom}."))
    lignes = []
    for src in SOURCES:
        if p.series[src].vide():
            continue
        h = p.serie(src)["H"]
        hors = (h < dom[0]) | (h > dom[1])
        if hors.any():
            l = p.serie(src).loc[hors, ["date", "H"]].copy()
            l["source"] = SOURCES_COURT[src]
            l["Q_ref extrapolé"] = ref.predire(l["H"])
            lignes.append(l)
    if lignes:
        l = pd.concat(lignes, ignore_index=True)
        out.append(Constat("attention", "Modèle de référence", "Extrapolation hors du domaine",
                           f"{len(l)} hauteur(s) hors de {_fmt(dom[0])}–{_fmt(dom[1])} m : Q_ref y est "
                           f"extrapolé (jusqu'à {_fmt(l['Q_ref extrapolé'].max(), 0)} m³/s). Vérifier que les "
                           f"hauteurs des différentes sources sont rapportées au même zéro.", l))

    m = reference_contre_mesures(p)
    if m:
        niveau = "attention" if (not np.isfinite(m["nse"]) or m["nse"] < 0) else "ok"
        out.append(Constat(niveau, "Modèle de référence", "Confrontation aux mesures in situ (indépendante)",
                           f"{ref.nom} contre Q_hist : NSE = {_fmt(m['nse'])}, KGE = {_fmt(m['kge'])}, "
                           f"biais = {_fmt(m['biais'])} m³/s, r = {_fmt(m['r'], 3)} (n = {m['n']})."
                           + (" Un NSE négatif signifie que le modèle prédit moins bien que la moyenne des mesures."
                              if niveau == "attention" else "")))
    return out


# --------------------------------------------------------------------- SWOT
def controle_swot(p: Projet) -> list[Constat]:
    out = []
    if p.series["swot"].vide():
        return out
    df = p.serie("swot")
    q_src = "Q_importe" if "Q_importe" in df.columns and df["Q_importe"].notna().any() else "Q"
    d = df.copy()
    d["Q"] = df[q_src]
    e = manning.elasticites(d)
    if e:
        lo, hi = e["e_pente_ic"]
        if not (lo <= 0.5 <= hi):
            out.append(Constat("attention", "Q_SWOT", "Le débit fourni ne suit pas la loi de Manning",
                               f"Régression log Q sur log(largeur), log(pente), log({e['proxy']}) (n = {e['n']}) : "
                               f"élasticité à la pente = {_fmt(e['e_pente'], 3)} "
                               f"(IC 95 % : {_fmt(lo, 3)} à {_fmt(hi, 3)}), alors que Manning impose 0,5. "
                               f"Élasticité à {e['proxy']} = {_fmt(e['e_proxy'], 2)}. Documenter la formule "
                               f"exacte utilisée (section, profondeur, unité de pente)."))
        else:
            out.append(Constat("ok", "Q_SWOT", "Dépendance à la pente conforme à Manning",
                               f"Élasticité estimée {_fmt(e['e_pente'], 3)} (IC 95 % contenant 0,5)."))
    try:
        qm = manning.debit(df, p.manning)
        if qm.notna().sum() >= 3 and df[q_src].notna().sum() >= 3:
            m = metrics.tous(qm, df[q_src])
            out.append(Constat("info", "Q_SWOT", "Manning recalculé avec les paramètres du projet",
                               f"n = {p.manning.n}, pente en {p.manning.unite_pente}, "
                               f"{manning.MODES_PROFONDEUR[p.manning.mode_profondeur]} : "
                               f"biais = {_fmt(m['biais'])} m³/s, r = {_fmt(m['r'], 3)} par rapport au Q fourni."))
    except Exception as exc:  # colonnes manquantes
        out.append(Constat("info", "Q_SWOT", "Manning non recalculé", str(exc)))
    return out


# --------------------------------------------------------------------- fusion
def controle_fusion(res: ResultatHPS) -> list[Constat]:
    out = []
    t = res.table
    if (t["Q_global"] < 0).any():
        n = int((t["Q_global"] < 0).sum())
        out.append(Constat("erreur", "Fusion HPS-Hydro", "Débits fusionnés négatifs",
                           f"{n} valeur(s) de Q̄ < 0, héritées du modèle de référence.",
                           t.loc[t["Q_global"] < 0, ["H", "Q_ref", "Q_global"]].reset_index()))
    sig = t["sigma"].dropna()
    if len(sig):
        if sig.mean() < 0.05 or sig.mean() > 0.95:
            cote = "modèle de référence" if sig.mean() < 0.05 else "sources"
            out.append(Constat("attention", "Fusion HPS-Hydro", "Pondération quasi constante",
                               f"σ moyen = {_fmt(sig.mean(), 3)} : Q̄ dépend presque uniquement du {cote}. "
                               f"Revoir α et H₀ pour que la transition étiage/crue ait lieu dans la "
                               f"gamme des hauteurs observées."))
        else:
            out.append(Constat("ok", "Fusion HPS-Hydro", "Pondération active",
                               f"σ varie de {_fmt(sig.min(), 3)} à {_fmt(sig.max(), 3)} "
                               f"(moyenne {_fmt(sig.mean(), 3)})."))
    perf = performance(res)
    col_r = metrics.LIBELLES["r"]
    parfaits = [i for i in perf.index if perf.loc[i, col_r] > 0.9999]
    if parfaits:
        out.append(Constat("info", "Validation", "Comparaisons non indépendantes",
                           f"{', '.join(parfaits)} : corrélation ≈ 1 avec Q̄. Q̄ est construit à partir de "
                           f"ces sources ; une corrélation parfaite ne prouve pas la qualité de la source. "
                           f"Présenter plutôt la validation « une source exclue »."))
    for n in res.notes:
        out.append(Constat("info", "Fusion HPS-Hydro", "Remarque de calcul", n))
    return out


def tout_controler(p: Projet, res: ResultatHPS | None, s: Seuils | None = None) -> list[Constat]:
    s = s or Seuils()
    c = []
    c += controle_bassin(p, s)
    c += controle_stations(p)
    c += controle_series(p, s)
    c += controle_reference(p)
    c += controle_swot(p)
    if res is not None:
        c += controle_fusion(res)
    c.sort(key=lambda x: NIVEAUX[x.niveau])
    return c


def bilan(constats: list[Constat]) -> dict:
    return {n: sum(1 for c in constats if c.niveau == n) for n in NIVEAUX}
