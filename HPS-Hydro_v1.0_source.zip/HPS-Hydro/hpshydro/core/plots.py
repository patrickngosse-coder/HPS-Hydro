"""Graphiques de HPS-Hydro (matplotlib), communs à l'interface et au rapport."""

from __future__ import annotations

import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from matplotlib.lines import Line2D

from .projet import SOURCES_COURT

COULEURS = {
    "hist": "#1f4e79",
    "ml": "#d9822b",
    "swot": "#0f9d8a",
    "ref": "#8c8c8c",
    "global": "#6a3d9a",
    "bande": "#cab2d6",
    "erreur": "#c0392b",
}
COULEURS_SAISON = {
    "Saison des pluies": "#1f77b4",
    "Petite saison sèche": "#2ca02c",
    "Saison sèche": "#ff9f1c",
    "Moyenne annuelle": "#7f7f7f",
}


def _style(ax, titre=None, xl=None, yl=None):
    if titre:
        ax.set_title(titre, fontsize=10, loc="left", fontweight="bold", color="#222222")
    if xl:
        ax.set_xlabel(xl, fontsize=9)
    if yl:
        ax.set_ylabel(yl, fontsize=9)
    ax.grid(True, color="#e6e6e6", linewidth=0.7)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#9a9a9a")
    ax.tick_params(labelsize=8, colors="#444444")


def _vide(fig: Figure, message: str):
    fig.clear()
    ax = fig.add_subplot(111)
    ax.axis("off")
    ax.text(0.5, 0.5, message, ha="center", va="center", fontsize=10, color="#666666", wrap=True)


def _ylim_robuste(ax, valeurs, marge=1.25):
    v = pd.Series(valeurs).replace([np.inf, -np.inf], np.nan).dropna()
    if v.empty:
        return
    haut = float(np.nanpercentile(v, 98)) * marge
    bas = min(0.0, float(v.min()))
    if haut > bas:
        ax.set_ylim(bas, haut)


# ------------------------------------------------------------------ tarage
def tarage(fig: Figure, h, q, ajustements=(), titre="Courbe de tarage", xl="Hauteur H (m)",
           etiquette="Jaugeages"):
    fig.clear()
    ax = fig.add_subplot(111)
    h = np.asarray(h, float)
    q = np.asarray(q, float)
    ax.scatter(h, q, s=28, color=COULEURS["hist"], alpha=0.85, label=etiquette, zorder=3)
    if len(h):
        hx = np.linspace(np.nanmin(h), np.nanmax(h), 200)
        styles = ["-", "--", ":", "-."]
        for i, aj in enumerate(ajustements):
            ax.plot(hx, aj.predire(hx), styles[i % 4], color=COULEURS["erreur"] if i == 0 else "#555555",
                    linewidth=1.6, label=f"{aj.formule(3)}  (NSE {aj.criteres.get('nse', np.nan):.3f})")
    _style(ax, titre, xl, "Débit Q (m³/s)")
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


def serie(fig: Figure, df: pd.DataFrame, source: str, titre=None):
    fig.clear()
    if df is None or df.empty:
        return _vide(fig, "Aucune donnée importée pour cette source.")
    ax = fig.add_subplot(211)
    c = COULEURS.get(source, "#333333")
    d = df.sort_values("date")
    ax.plot(d["date"], d["Q"], "-o", color=c, markersize=3, linewidth=1.2, label="Q")
    if "Q_importe" in d.columns and not np.allclose(d["Q_importe"].fillna(0), d["Q"].fillna(0)):
        ax.plot(d["date"], d["Q_importe"], "--", color="#999999", linewidth=1, label="Q importé")
        ax.legend(fontsize=7.5, frameon=False)
    _style(ax, titre or f"Hydrogramme {SOURCES_COURT.get(source, source)}", None, "Q (m³/s)")
    ax2 = fig.add_subplot(212)
    ax2.scatter(d["H"], d["Q"], s=18, color=c, alpha=0.85)
    _style(ax2, "Relation H–Q", "Hauteur H (m)", "Q (m³/s)")
    fig.tight_layout()


def reference(fig: Figure, ref, domaine, points: pd.DataFrame | None = None):
    fig.clear()
    ax = fig.add_subplot(111)
    a = ref.analyse()
    hmax = 10.0
    if points is not None and not points.empty:
        hmax = max(hmax, float(points["H"].quantile(0.98)) * 1.1)
    if np.isfinite(domaine[1]):
        hmax = max(hmax, domaine[1] * 1.2)
    hx = np.linspace(0, hmax, 400)
    qx = ref.predire(hx)
    ax.plot(hx, qx, color=COULEURS["ref"], linewidth=2, label=f"{ref.nom} : {ref.formule()}")
    if np.isfinite(domaine[0]) and np.isfinite(domaine[1]):
        ax.axvspan(domaine[0], domaine[1], color="#dff0d8", alpha=0.7, label="Domaine de validité")
    if a["h_sommet"] is not None and a["h_sommet"] > 0 and ref.a2 > 0:
        ax.axvspan(0, a["h_sommet"], color="#f9e0dc", alpha=0.6, label="Branche décroissante (non physique)")
    ax.axhline(0, color="#999999", linewidth=0.8)
    if points is not None and not points.empty:
        for src, g in points.groupby("source"):
            ax.scatter(g["H"], g["Q"], s=16, color=COULEURS.get(src, "#333333"), alpha=0.8,
                       label=f"{SOURCES_COURT.get(src, src)} (données)", zorder=3)
    _style(ax, "Modèle de référence", "Hauteur H (m)", "Débit Q (m³/s)")
    ax.set_xlim(0, hmax)
    haut = float(np.nanmax(qx)) * 1.05
    if points is not None and not points.empty:
        haut = min(haut, max(float(points["Q"].quantile(0.98)) * 2.5,
                             float(ref.predire(domaine[1])) * 1.5 if np.isfinite(domaine[1]) else 0))
    ax.set_ylim(min(-20, float(qx.min()) * 1.1), haut)
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


# ------------------------------------------------------------------ fusion
def fusion_hq(fig: Figure, res):
    fig.clear()
    t = res.table.dropna(subset=["H", "Q_global"])
    if t.empty:
        return _vide(fig, "Aucun résultat de fusion.")
    ax = fig.add_subplot(111)
    for s in res.sources_actives:
        g = t[t["H_origine"] == SOURCES_COURT[s]]
        if g.empty:
            continue
        ax.errorbar(g["H"], g["Q_global"], yerr=g["incertitude"].clip(upper=g["Q_global"].abs().max()),
                    fmt="o", markersize=4, color=COULEURS[s], ecolor=COULEURS["bande"], elinewidth=1,
                    alpha=0.9, label=f"Q̄ (H issu de {SOURCES_COURT[s]})")
    _style(ax, "Courbe Q̄_global(H) pondérée, incertitude ±1σ", "Hauteur H (m)", "Débit Q̄_global (m³/s)")
    _ylim_robuste(ax, t["Q_global"] + t["incertitude"].clip(upper=t["Q_global"].abs().max()))
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


def fusion_temps(fig: Figure, res, montrer_sources=True):
    fig.clear()
    t = res.table.dropna(subset=["Q_global"])
    if t.empty:
        return _vide(fig, "Aucun résultat de fusion.")
    ax = fig.add_subplot(111)
    borne = t["Q_global"].abs().max()
    inc = t["incertitude"].clip(upper=borne)
    ax.fill_between(t.index, (t["Q_global"] - inc).clip(lower=0), t["Q_global"] + inc,
                    color=COULEURS["bande"], alpha=0.45, linewidth=0, label="±1σ")
    ax.plot(t.index, t["Q_global"], color=COULEURS["global"], linewidth=0.9, alpha=0.6)
    poignees = [Line2D([0], [0], color=COULEURS["bande"], linewidth=6, alpha=0.6, label="±1σ")]
    for saison, g in t.groupby("saison"):
        c = COULEURS_SAISON.get(saison, "#555555")
        ax.scatter(g.index, g["Q_global"], s=12, color=c, zorder=3)
        poignees.append(Line2D([0], [0], marker="o", color="w", markerfacecolor=c, markersize=6, label=saison))
    if montrer_sources:
        for s in res.sources_actives:
            c = f"Q_{s}"
            if c in t:
                ax.plot(t.index, t[c], ":", color=COULEURS[s], linewidth=0.8, alpha=0.8)
                poignees.append(Line2D([0], [0], linestyle=":", color=COULEURS[s], label=SOURCES_COURT[s]))
    _style(ax, "Hydrogramme global Q̄ — coloration par saison hydrologique", "Date", "Débit Q̄ (m³/s)")
    _ylim_robuste(ax, t["Q_global"] + inc)
    ax.legend(handles=poignees, fontsize=7.5, frameon=False, ncol=3, loc="upper left")
    fig.tight_layout()


def saisonnalite(fig: Figure, g: pd.DataFrame | None):
    fig.clear()
    if g is None or g.empty:
        return _vide(fig, "Saisonnalité indisponible : elle nécessite des séries journalières ou "
                          "mensuelles (les séries annuelles ne décrivent pas le cycle saisonnier).")
    ax = fig.add_subplot(111)
    ax.fill_between(g.index, (g["Q"] - g["sd"]).clip(lower=0), g["Q"] + g["sd"],
                    color="#e6e6e6", linewidth=0, label="±1σ")
    ax.plot(g.index, g["Q"], color="#9a9a9a", linewidth=0.8, label="Moyenne par jour")
    ax.plot(g.index, g["Q_lisse"], color=COULEURS["global"], linewidth=2.2, label="Lissage LOESS")
    _style(ax, "Saisonnalité du débit Q̄ — moyenne par jour de l'année", "Jour de l'année (1-366)",
           "Débit Q̄ (m³/s)")
    ax.set_xlim(1, 366)
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


def sigma(fig: Figure, res):
    fig.clear()
    t = res.table.dropna(subset=["H", "sigma"])
    if t.empty:
        return _vide(fig, "Aucun résultat de fusion.")
    ax = fig.add_subplot(111)
    p = res.parametres
    if p.mode == "H":
        hx = np.linspace(t["H"].min(), t["H"].max(), 300)
        from scipy.special import expit
        ax.plot(hx, expit(p.alpha_h * (hx - res.h0_utilise)), color=COULEURS["global"], linewidth=2,
                label=f"σ(H), α = {p.alpha_h:g} m⁻¹, H₀ = {res.h0_utilise:.2f} m")
        titre = "Fonction de pondération σ(H)"
    else:
        titre = "Pondération moyenne σ selon l'écart à Q_ref"
    ax.scatter(t["H"], t["sigma"], s=12, color="#555555", alpha=0.7, label="Pas de temps", zorder=3)
    _style(ax, titre, "Hauteur H (m)", "σ (0 = référence, 1 = sources)")
    ax.set_ylim(-0.05, 1.05)
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


def comparaison(fig: Figure, x, y, titre, xl, yl, couleur="#1f4e79"):
    fig.clear()
    ax = fig.add_subplot(111)
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() == 0:
        return _vide(fig, "Pas de couples à comparer.")
    ax.scatter(x[ok], y[ok], s=22, color=couleur, alpha=0.85, zorder=3)
    lo = float(min(x[ok].min(), y[ok].min()))
    hi = float(max(np.percentile(x[ok], 99), np.percentile(y[ok], 99)))
    ax.plot([lo, hi], [lo, hi], "--", color="#999999", linewidth=1, label="1:1")
    ax.set_xlim(lo - 0.05 * (hi - lo), hi + 0.05 * (hi - lo))
    ax.set_ylim(lo - 0.05 * (hi - lo), hi + 0.05 * (hi - lo))
    _style(ax, titre, xl, yl)
    ax.legend(fontsize=7.5, frameon=False, loc="upper left")
    fig.tight_layout()


def ml_validation(fig: Figure, res):
    fig.clear()
    d = res.oof
    ax = fig.add_subplot(121)
    ax.scatter(d["Q_obs"], d["Q_oof"], s=18, color=COULEURS["ml"], alpha=0.85, zorder=3)
    lo = float(min(d["Q_obs"].min(), d["Q_oof"].min()))
    hi = float(max(d["Q_obs"].max(), d["Q_oof"].max()))
    ax.plot([lo, hi], [lo, hi], "--", color="#999999", linewidth=1)
    _style(ax, "Validation croisée (hors échantillon)", "Q mesuré (m³/s)", "Q prédit (m³/s)")
    ax2 = fig.add_subplot(122)
    ax2.plot(d["date"], d["Q_obs"], "-o", color=COULEURS["hist"], markersize=3, linewidth=1, label="Mesuré")
    ax2.plot(d["date"], d["Q_oof"], "-o", color=COULEURS["ml"], markersize=3, linewidth=1, label="Prédit hors échantillon")
    _style(ax2, "Chronologie", "Date", "Q (m³/s)")
    import matplotlib.dates as mdates
    loc = mdates.AutoDateLocator(maxticks=6)
    ax2.xaxis.set_major_locator(loc)
    ax2.xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
    ax2.legend(fontsize=7.5, frameon=False)
    fig.tight_layout()
