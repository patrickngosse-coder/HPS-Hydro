"""Point d'entrée : python -m hpshydro"""

import sys


def main() -> int:
    from hpshydro.ui.main_window import run
    return run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
