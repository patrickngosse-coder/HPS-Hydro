"""HPS-Hydro — calage multi-source et validation hydrologique.

Logiciel fondé sur le modèle Hybride à Pondération Sigmoïdale (HPS-Hydro)
développé pour l'élaboration d'une courbe de tarage multi-station de la
rivière Inkisi (RDC) à partir de mesures historiques, d'apprentissage
automatique, de l'altimétrie SWOT (équation de Manning) et du modèle de Thys.
"""

__version__ = "1.0.0"
APP_NAME = "HPS-Hydro"
APP_TITLE = "HPS-Hydro — Calage multi-source et validation hydrologique"

AUTEUR = "Patrick Ngosse"
INSTITUTION = "Université Pédagogique Nationale (UPN), Département de Physique et Sciences Appliquées"
COURRIEL = "patrick.ngosse@upn.ac.cd"
TELEPHONE = "+243 810 905 156"
