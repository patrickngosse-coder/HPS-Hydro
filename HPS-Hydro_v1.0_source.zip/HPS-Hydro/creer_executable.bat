@echo off
chcp 65001 >nul
title HPS-Hydro - creation de l'executable Windows
cd /d "%~dp0"
rem Versions eprouvees pour l'executable (voir requirements-windows.txt)
python -m pip install -r requirements-windows.txt
if errorlevel 1 goto erreur
python -m PyInstaller --noconfirm --clean --windowed --name HPS-Hydro ^
  --icon hpshydro\resources\icone.ico ^
  --version-file version_windows.txt ^
  --add-data "hpshydro\resources;hpshydro\resources" ^
  --add-data "donnees_demo;donnees_demo" ^
  --collect-binaries xgboost ^
  --collect-data xgboost ^
  --exclude-module tkinter --exclude-module pytest --exclude-module IPython ^
  lancer_hps_hydro.py
if errorlevel 1 goto erreur
copy /y LISEZMOI_Windows.txt dist\HPS-Hydro\LISEZMOI.txt >nul
echo.
echo Executable cree : dist\HPS-Hydro\HPS-Hydro.exe
echo Verification de l'executable...
start "" /wait dist\HPS-Hydro\HPS-Hydro.exe --autotest
type "%USERPROFILE%\HPS-Hydro_autotest.txt"
echo.
echo Pour le distribuer, compressez le dossier dist\HPS-Hydro en .zip.
pause
exit /b 0
:erreur
echo.
echo ECHEC de la creation de l'executable. Lisez les messages ci-dessus.
pause
exit /b 1
