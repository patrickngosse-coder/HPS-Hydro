"""Démarrage de HPS-Hydro (fichier de démarrage du projet Visual Studio et de PyInstaller)."""

import sys

from hpshydro.__main__ import main

if __name__ == "__main__":
    sys.exit(main())
