"""Tests du moteur de calcul : chaque formule est vérifiée sur un cas connu.

Lancer :  python -m pytest -q
"""

import math

import numpy as np
import pandas as pd
import pytest

from hpshydro.core import hps, manning, metrics, ml, rating, validation
from hpshydro.core.lowess import lowess
from hpshydro.core.projet import Projet, ParametresHPS, dms_vers_decimal, projet_demo_inkisi


# ------------------------------------------------------------------ critères
def test_criteres_parfaits():
    obs = np.array([10.0, 20.0, 30.0, 40.0])
    m = metrics.tous(obs, obs)
    assert m["nse"] == pytest.approx(1.0)
    assert m["kge"] == pytest.approx(1.0)
    assert m["rmse"] == pytest.approx(0.0)
    assert m["pbias"] == pytest.approx(0.0)


def test_nse_moyenne_vaut_zero():
    obs = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    assert metrics.nse(np.full(5, obs.mean()), obs) == pytest.approx(0.0)


def test_kge_decomposition():
    obs = np.array([1.0, 2.0, 3.0, 4.0])
    sim = 2 * obs  # r = 1, alpha = 2, beta = 2
    assert metrics.kge(sim, obs) == pytest.approx(1 - math.sqrt(0 + 1 + 1))


def test_pbias_signe():
    assert metrics.pbias([110, 110], [100, 100]) == pytest.approx(10.0)


# ------------------------------------------------------- modèle de référence
def test_thys_valeurs_et_racines():
    ref = rating.ModeleReference()
    # Q_Thys(H) = 94,510 − 78,571 H + 15,624 H²
    assert ref.predire(0.0) == pytest.approx(94.510)
    assert ref.predire(6.14) == pytest.approx(94.510 - 78.571 * 6.14 + 15.624 * 6.14 ** 2)
    a = ref.analyse()
    assert a["h_sommet"] == pytest.approx(78.571 / (2 * 15.624))
    r1, r2 = a["racines"]
    assert ref.predire(r1) == pytest.approx(0, abs=1e-9)
    assert ref.predire(r2) == pytest.approx(0, abs=1e-9)
    assert a["q_sommet"] < 0


# -------------------------------------------------------- courbes de tarage
def test_ajustement_puissance_retrouve_les_parametres():
    h = np.linspace(1.0, 6.0, 25)
    q = 13.08 * h ** 1.45
    aj = rating.ajuster(h, q, "puissance0")
    assert aj.params["a"] == pytest.approx(13.08, rel=1e-4)
    assert aj.params["b"] == pytest.approx(1.45, rel=1e-4)


def test_ajustement_puissance_avec_h0():
    h = np.linspace(421.3, 422.5, 20)
    q = 9.5 * (h - 418.3) ** 2.3
    aj = rating.ajuster(h, q, "puissance")
    assert aj.criteres["nse"] > 0.9999


def test_ajustement_polynome():
    h = np.linspace(3, 7, 15)
    q = 94.51 - 78.571 * h + 15.624 * h ** 2
    aj = rating.ajuster(h, q, "polynome2")
    assert aj.params["a2"] == pytest.approx(15.624, rel=1e-6)


# ------------------------------------------------------------------ Manning
def test_manning_section_rectangulaire():
    # W = 10 m, y = 2 m, S = 0,001, n = 0,03 → A = 20, P = 14, R = 1,4286
    df = pd.DataFrame({"largeur": [10.0], "pente": [0.001], "H": [2.0]})
    p = manning.ParametresManning(n=0.03, unite_pente="fraction", mode_profondeur="H")
    attendu = (1 / 0.03) * 20 * (20 / 14) ** (2 / 3) * math.sqrt(0.001)
    assert manning.debit(df, p).iloc[0] == pytest.approx(attendu)


def test_manning_unite_pente_et_section_large():
    df = pd.DataFrame({"largeur": [100.0], "pente": [0.1], "H": [3.0]})  # 0,1 % = 0,001
    p = manning.ParametresManning(n=0.035, unite_pente="pourcent", section="large")
    attendu = (1 / 0.035) * 300 * 3 ** (2 / 3) * math.sqrt(0.001)
    assert manning.debit(df, p).iloc[0] == pytest.approx(attendu)


def test_elasticite_pente_detectee():
    rng = np.random.default_rng(0)
    n = 40
    w = rng.uniform(80, 180, n)
    s = rng.uniform(0.001, 0.007, n)
    y = rng.uniform(1, 4, n)
    q = (1 / 0.035) * w * y ** (5 / 3) * np.sqrt(s)
    e = manning.elasticites(pd.DataFrame({"Q": q, "largeur": w, "pente": s, "H": y}))
    assert e["e_pente"] == pytest.approx(0.5, abs=1e-6)


# ------------------------------------------------------------- HPS-Hydro
def _projet_simple():
    p = Projet()
    dates = pd.date_range("2000-01-01", periods=5, freq="D")
    p.definir_serie("hist", pd.DataFrame({"date": dates, "niveau": np.nan,
                                          "H": [4.0, 5.0, 6.0, 7.0, 8.0],
                                          "Q": [100.0, 150.0, 200.0, 260.0, 330.0]}))
    p.definir_serie("swot", pd.DataFrame({"date": dates, "niveau": np.nan,
                                          "H": [4.0, 5.0, 6.0, 7.0, 8.0],
                                          "Q": [120.0, 170.0, 220.0, 280.0, 350.0]}))
    p.reference.h_min, p.reference.h_max = 0.0, 20.0
    return p


def test_hps_formule_mode_h():
    p = _projet_simple()
    par = ParametresHPS(mode="H", alpha_h=1.5, h0=6.0)
    r = hps.fusionner(p, par)
    t = r.table
    for d, row in t.iterrows():
        sig = 1 / (1 + math.exp(-1.5 * (row["H"] - 6.0)))
        attendu = sig * (row["Q_hist"] + row["Q_swot"]) / 2 + (1 - sig) * p.reference.predire(row["H"])
        assert row["Q_global"] == pytest.approx(attendu)


def test_hps_limites_sigmoide():
    p = _projet_simple()
    r_crue = hps.fusionner(p, ParametresHPS(mode="H", alpha_h=50, h0=-100))  # σ → 1
    t = r_crue.table
    assert np.allclose(t["Q_global"], (t["Q_hist"] + t["Q_swot"]) / 2)
    r_etiage = hps.fusionner(p, ParametresHPS(mode="H", alpha_h=50, h0=100))  # σ → 0
    assert np.allclose(r_etiage.table["Q_global"], r_etiage.table["Q_ref"])


def test_hps_mode_ecart():
    p = _projet_simple()
    r = hps.fusionner(p, ParametresHPS(mode="ecart", alpha_q=0.05))
    row = r.table.iloc[2]
    qref = row["Q_ref"]
    comp = []
    for q in (row["Q_hist"], row["Q_swot"]):
        s = 1 / (1 + math.exp(-0.05 * (q - qref)))
        comp.append(s * q + (1 - s) * qref)
    assert row["Q_global"] == pytest.approx(np.mean(comp))


def test_hps_exclusion_hors_domaine():
    p = _projet_simple()
    p.reference.h_min, p.reference.h_max = 4.5, 7.5
    r = hps.fusionner(p, ParametresHPS(mode="H", alpha_h=1, h0=6, hors_domaine="exclure"))
    t = r.table
    hors = t["hors_domaine"]
    assert hors.sum() == 2
    assert np.allclose(t.loc[hors, "Q_global"], (t.loc[hors, "Q_hist"] + t.loc[hors, "Q_swot"]) / 2)


def test_source_exclue_independante():
    p = _projet_simple()
    tab, series = hps.validation_source_exclue(p, ParametresHPS(mode="H", alpha_h=50, h0=-100))
    # σ = 1 : sans Q_hist, Q̄ = Q_swot ; la comparaison donne exactement l'écart entre sources
    assert np.allclose(series["hist"]["Q_global_sans_source"], p.serie("swot")["Q"].to_numpy())


# ------------------------------------------------------- apprentissage auto
def test_ml_detecte_sur_apprentissage_et_valide():
    p = projet_demo_inkisi()
    res = ml.entrainer(p.serie("hist"), p.ml)
    assert res.ajustement["nse"] > res.validation_croisee["nse"]
    assert res.oof["Q_oof"].notna().all()
    q, hors = ml.predire(res, p.serie("ml"), p.serie("hist"))
    assert q.notna().sum() == len(p.serie("ml"))


# --------------------------------------------------- contrôles de validation
def test_controles_sur_donnees_inkisi():
    p = projet_demo_inkisi()
    r = hps.fusionner(p)
    c = validation.tout_controler(p, r)
    titres = {(x.categorie, x.titre) for x in c}
    assert ("Q_ML", "Hauteur incohérente avec le niveau") in titres
    assert ("Q_SWOT", "Hauteur calculée en valeur absolue") in titres
    assert ("Modèle de référence", "Courbe non monotone") in titres
    assert ("Q_SWOT", "Le débit fourni ne suit pas la loi de Manning") in titres
    ml_inc = next(x for x in c if x.titre == "Hauteur incohérente avec le niveau")
    assert set(ml_inc.lignes["date"].dt.year) == {2005, 2011}


def test_moyenne_kisantu():
    p = projet_demo_inkisi()
    assert p.serie("hist")["Q"].mean() == pytest.approx(179.36, abs=0.01)


def test_dms():
    v, a = dms_vers_decimal("5°08'38\"S")
    assert v == pytest.approx(-(5 + 8 / 60 + 38 / 3600))
    assert a is None
    v, a = dms_vers_decimal("5°55'69\"S")
    assert a is not None


def test_enregistrement_aller_retour(tmp_path):
    p = projet_demo_inkisi()
    f = tmp_path / "inkisi.hpsh"
    p.enregistrer(f)
    q = Projet.ouvrir(f)
    pd.testing.assert_frame_equal(p.serie("swot"), q.serie("swot"), check_dtype=False)
    assert q.reference.a2 == pytest.approx(15.624)
    r1, r2 = hps.fusionner(p), hps.fusionner(q)
    assert np.allclose(r1.table["Q_global"], r2.table["Q_global"], equal_nan=True)


def test_lowess_droite():
    x = np.arange(50.0)
    assert np.allclose(lowess(x, 2 * x + 1, fraction=0.3), 2 * x + 1)
